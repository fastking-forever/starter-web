package fotmob

import (
	"encoding/json"
	"testing"
)

func TestWCGroupLetter(t *testing.T) {
	tests := []struct {
		in   string
		want string
	}{
		{"Grp. A", "A"},
		{"Grp. B", "B"},
		{"Grp. L", "L"},
		{"Group A", "A"},
		{"Group Z", "Z"},
		{"A", "A"},
		{"  Grp. C  ", "C"},
	}
	for _, tt := range tests {
		t.Run(tt.in, func(t *testing.T) {
			got := wcGroupLetter(tt.in)
			if got != tt.want {
				t.Errorf("wcGroupLetter(%q) = %q, want %q", tt.in, got, tt.want)
			}
		})
	}
}

func TestParseWCGroups_Empty(t *testing.T) {
	groups := parseWCGroups(wcPageResponse{})
	if groups != nil {
		t.Errorf("expected nil for empty response, got %v", groups)
	}
}

func TestParseWCGroups_EightGroups(t *testing.T) {
	resp := buildMockWCPageResponse(8)
	groups := parseWCGroups(resp)

	if len(groups) != 8 {
		t.Fatalf("len(groups) = %d, want 8", len(groups))
	}
	for i, g := range groups {
		if len(g.Teams) != 4 {
			t.Errorf("groups[%d] has %d teams, want 4", i, len(g.Teams))
		}
		if g.Letter == "" {
			t.Errorf("groups[%d].Letter is empty", i)
		}
		if g.Name == "" {
			t.Errorf("groups[%d].Name is empty", i)
		}
	}
}

func TestParseWCGroups_TwelveGroups(t *testing.T) {
	resp := buildMockWCPageResponse(12)
	groups := parseWCGroups(resp)

	if len(groups) != 12 {
		t.Fatalf("len(groups) = %d, want 12", len(groups))
	}
}

// TestParseWCGroups_FiltersNonLetterTables locks in the fix for #158: FotMob
// sometimes ships pseudo-tables alongside the real groups (e.g. a "Qualified
// teams" pot table). Those must be dropped so the grid stays symmetric.
func TestParseWCGroups_FiltersNonLetterTables(t *testing.T) {
	resp := buildMockWCPageResponse(12)

	// Inject two pseudo-tables: one whose name yields a word ("teams"), one
	// whose name yields the empty string. Both must be filtered out.
	pseudo := resp.Table[0].Data.Tables[0]
	pseudo.LeagueID = 999001
	pseudo.LeagueName = "Qualified teams"
	resp.Table[0].Data.Tables = append(resp.Table[0].Data.Tables, pseudo)

	empty := resp.Table[0].Data.Tables[0]
	empty.LeagueID = 999002
	empty.LeagueName = ""
	resp.Table[0].Data.Tables = append(resp.Table[0].Data.Tables, empty)

	groups := parseWCGroups(resp)
	if len(groups) != 12 {
		t.Fatalf("len(groups) = %d, want 12 (pseudo-tables not filtered)", len(groups))
	}
	for i, g := range groups {
		if !isWCGroupLetter(g.Letter) {
			t.Errorf("groups[%d].Letter = %q, want single uppercase letter", i, g.Letter)
		}
		if g.Name == "Group teams" {
			t.Errorf("groups[%d] is the pseudo-table that should have been filtered", i)
		}
	}
}

func TestIsWCGroupLetter(t *testing.T) {
	tests := []struct {
		in   string
		want bool
	}{
		{"A", true},
		{"L", true},
		{"Z", true},
		{"", false},
		{"AA", false},
		{"teams", false},
		{"a", false}, // lowercase rejected; wcGroupLetter uppercases via FotMob input
		{"1", false},
	}
	for _, tt := range tests {
		if got := isWCGroupLetter(tt.in); got != tt.want {
			t.Errorf("isWCGroupLetter(%q) = %v, want %v", tt.in, got, tt.want)
		}
	}
}

// TestParseWCGroups_DropsEmptyTeamRows covers the row-4 gap reported on
// macOS Terminal under #158: FotMob occasionally interleaves placeholder
// rows (empty name + empty shortName) inside a group's standings. Those
// would inflate the rendered cell height and push the grid layout out of
// alignment, so the parser drops them.
func TestParseWCGroups_DropsEmptyTeamRows(t *testing.T) {
	resp := buildMockWCPageResponse(1)
	// Inject an empty-name placeholder between real teams.
	resp.Table[0].Data.Tables[0].Table.All = []fotmobTableRow{
		{ID: 1, Name: "Team1", ShortName: "TM1", Idx: 1, Pts: 9},
		{ID: 2, Name: "Team2", ShortName: "TM2", Idx: 2, Pts: 6},
		{ID: 0, Name: "", ShortName: "", Idx: 3, Pts: 0}, // pseudo-row
		{ID: 3, Name: "Team3", ShortName: "TM3", Idx: 3, Pts: 4},
		{ID: 4, Name: "Team4", ShortName: "TM4", Idx: 4, Pts: 1},
	}

	groups := parseWCGroups(resp)
	if len(groups) != 1 {
		t.Fatalf("len(groups) = %d, want 1", len(groups))
	}
	if got := len(groups[0].Teams); got != 4 {
		t.Errorf("len(teams) = %d, want 4 (empty pseudo-row not filtered)", got)
	}
	for i, te := range groups[0].Teams {
		if te.Team.Name == "" && te.Team.ShortName == "" {
			t.Errorf("teams[%d] retained empty placeholder row", i)
		}
	}
}

func TestParseWCBracket_Empty(t *testing.T) {
	rounds, bronze := parseWCBracket(wcPlayoff{})
	if len(rounds) != 0 {
		t.Errorf("expected 0 rounds, got %d", len(rounds))
	}
	if bronze != nil {
		t.Errorf("expected nil bronze, got %v", bronze)
	}
}

func TestParseWCBracket_StandardRounds(t *testing.T) {
	playoff := wcPlayoff{
		Rounds: []wcPlayoffRound{
			{Stage: "1/2", Matchups: []wcMatchupRaw{makeMockMatchup(1, 2, 2, 0, 1, false)}},
			{Stage: "1/8", Matchups: []wcMatchupRaw{
				makeMockMatchup(10, 20, 3, 1, 10, false),
				makeMockMatchup(30, 40, 1, 0, 30, false),
			}},
			{Stage: "1/4", Matchups: []wcMatchupRaw{makeMockMatchup(5, 6, 1, 1, 5, true)}},
			{Stage: "final", Matchups: []wcMatchupRaw{makeMockMatchup(1, 5, 3, 3, 1, true)}},
		},
		Special: []wcPlayoffRound{
			{Stage: "bronze", Matchups: []wcMatchupRaw{makeMockMatchup(2, 6, 2, 1, 2, false)}},
		},
	}

	rounds, bronze := parseWCBracket(playoff)

	if len(rounds) != 4 {
		t.Fatalf("len(rounds) = %d, want 4", len(rounds))
	}

	// Rounds must be sorted: 1/8 → 1/4 → 1/2 → final
	wantOrder := []string{"1/8", "1/4", "1/2", "final"}
	for i, want := range wantOrder {
		if rounds[i].Stage != want {
			t.Errorf("rounds[%d].Stage = %q, want %q", i, rounds[i].Stage, want)
		}
	}

	// Verify R16 has 2 matchups as supplied
	if len(rounds[0].Matchups) != 2 {
		t.Errorf("R16 matchups = %d, want 2", len(rounds[0].Matchups))
	}

	if bronze == nil {
		t.Fatal("bronze is nil")
	}
	if bronze.HomeTeamID != 2 {
		t.Errorf("bronze.HomeTeamID = %d, want 2", bronze.HomeTeamID)
	}
}

func TestParseWCBracket_Labels(t *testing.T) {
	stageTests := []struct {
		stage string
		label string
	}{
		{"1/16", "Round of 32"},
		{"1/8", "Round of 16"},
		{"1/4", "Quarterfinals"},
		{"1/2", "Semifinals"},
		{"final", "Final"},
	}

	for _, tt := range stageTests {
		playoff := wcPlayoff{
			Rounds: []wcPlayoffRound{
				{Stage: tt.stage, Matchups: []wcMatchupRaw{makeMockMatchup(1, 2, 1, 0, 1, false)}},
			},
		}
		rounds, _ := parseWCBracket(playoff)
		if len(rounds) != 1 {
			t.Fatalf("stage %q: expected 1 round, got %d", tt.stage, len(rounds))
		}
		if rounds[0].Label != tt.label {
			t.Errorf("stage %q: Label = %q, want %q", tt.stage, rounds[0].Label, tt.label)
		}
	}
}

func TestConvertMatchup_Penalties(t *testing.T) {
	mu := makeMockMatchup(10, 20, 2, 2, 10, true)
	out := convertMatchup(mu)

	if !out.IsPenalties {
		t.Error("IsPenalties = false, want true")
	}
	if out.WinnerID == nil || *out.WinnerID != 10 {
		t.Errorf("WinnerID = %v, want 10", out.WinnerID)
	}
	if out.HomeScore == nil || *out.HomeScore != 2 {
		t.Errorf("HomeScore = %v, want 2", out.HomeScore)
	}
}

func TestConvertMatchup_PenaltyWinnerFallback(t *testing.T) {
	// Simulates the actual FotMob bracket shape for GER 1-1 PAR (Paraguay wins on pens):
	// both team-level winner flags are false; the matchup-level "winner" field carries the winner;
	// status.reason.shortKey = "penalties_short" signals it was a penalty shootout.
	raw := wcMatchupRaw{
		HomeTeam:   "Germany",
		HomeTeamID: 100,
		AwayTeam:   "Paraguay",
		AwayTeamID: 200,
		Winner:     200,
	}
	var entry struct {
		Home struct {
			Score  int  `json:"score"`
			Winner bool `json:"winner"`
		} `json:"home"`
		Away struct {
			Score  int  `json:"score"`
			Winner bool `json:"winner"`
		} `json:"away"`
		Status struct {
			Finished bool `json:"finished"`
			Reason   struct {
				ShortKey string `json:"shortKey"`
			} `json:"reason"`
		} `json:"status"`
	}
	entry.Home.Score = 1
	entry.Away.Score = 1
	entry.Status.Finished = true
	entry.Status.Reason.ShortKey = "penalties_short"
	raw.Matches = append(raw.Matches, entry)
	out := convertMatchup(raw)

	if out.WinnerID == nil || *out.WinnerID != 200 {
		t.Errorf("WinnerID = %v, want 200", out.WinnerID)
	}
	if !out.IsPenalties {
		t.Error("IsPenalties = false, want true")
	}
}

func TestConvertMatchup_NotYetPlayed(t *testing.T) {
	raw := wcMatchupRaw{
		HomeTeam:   "Team A",
		HomeTeamID: 1,
		AwayTeam:   "Team B",
		AwayTeamID: 2,
		// No matches — not yet played
	}
	out := convertMatchup(raw)

	if out.HomeScore != nil {
		t.Errorf("HomeScore should be nil for unplayed match, got %v", out.HomeScore)
	}
	if out.AwayScore != nil {
		t.Errorf("AwayScore should be nil for unplayed match, got %v", out.AwayScore)
	}
	if out.WinnerID != nil {
		t.Errorf("WinnerID should be nil for unplayed match, got %v", out.WinnerID)
	}
}

func TestParseWCTopScorers_Empty(t *testing.T) {
	got := parseWCTopScorers(wcStatList{})
	if got != nil {
		t.Errorf("expected nil for empty stat list, got %v", got)
	}
}

func TestParseWCTopScorers_RoundTrip(t *testing.T) {
	fixture := wcStatList{
		TopLists: []struct {
			StatList []struct {
				ParticipantName string  `json:"ParticipantName"`
				TeamName        string  `json:"TeamName"`
				StatValue       float64 `json:"StatValue"`
				Rank            int     `json:"Rank"`
			} `json:"StatList"`
		}{
			{
				StatList: []struct {
					ParticipantName string  `json:"ParticipantName"`
					TeamName        string  `json:"TeamName"`
					StatValue       float64 `json:"StatValue"`
					Rank            int     `json:"Rank"`
				}{
					{ParticipantName: "Lionel Messi", TeamName: "Argentina", StatValue: 6, Rank: 1},
					{ParticipantName: "Kylian Mbappé", TeamName: "France", StatValue: 4, Rank: 2},
				},
			},
		},
	}

	got := parseWCTopScorers(fixture)
	if len(got) != 2 {
		t.Fatalf("len(scorers) = %d, want 2", len(got))
	}
	if got[0].PlayerName != "Lionel Messi" {
		t.Errorf("scorers[0].PlayerName = %q, want %q", got[0].PlayerName, "Lionel Messi")
	}
	if got[0].Goals != 6 {
		t.Errorf("scorers[0].Goals = %d, want 6", got[0].Goals)
	}
	if got[1].Team != "France" {
		t.Errorf("scorers[1].Team = %q, want %q", got[1].Team, "France")
	}
}

// --- helpers ---

// buildMockWCPageResponse builds a wcPageResponse with n groups, each having 4 teams.
func buildMockWCPageResponse(numGroups int) wcPageResponse {
	letters := []string{"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"}
	tables := make([]struct {
		LeagueID   int    `json:"leagueId"`
		LeagueName string `json:"leagueName"`
		Table      struct {
			All []fotmobTableRow `json:"all"`
		} `json:"table"`
	}, numGroups)

	for i := 0; i < numGroups; i++ {
		tables[i].LeagueID = 900000 + i
		tables[i].LeagueName = "Grp. " + letters[i]
		tables[i].Table.All = []fotmobTableRow{
			{ID: i*100 + 1, Name: "Team1", ShortName: "TM1", Idx: 1, Played: 3, Wins: 2, Draws: 1, Losses: 0, ScoresStr: "5-1", GoalConDiff: 4, Pts: 7},
			{ID: i*100 + 2, Name: "Team2", ShortName: "TM2", Idx: 2, Played: 3, Wins: 1, Draws: 1, Losses: 1, ScoresStr: "3-3", GoalConDiff: 0, Pts: 4},
			{ID: i*100 + 3, Name: "Team3", ShortName: "TM3", Idx: 3, Played: 3, Wins: 1, Draws: 0, Losses: 2, ScoresStr: "2-4", GoalConDiff: -2, Pts: 3},
			{ID: i*100 + 4, Name: "Team4", ShortName: "TM4", Idx: 4, Played: 3, Wins: 0, Draws: 0, Losses: 3, ScoresStr: "1-3", GoalConDiff: -2, Pts: 0},
		}
	}

	// Marshal/unmarshal to get the right nested type via JSON
	type dataBlock struct {
		Composite bool        `json:"composite"`
		Tables    interface{} `json:"tables"`
	}
	type tableBlock struct {
		Data dataBlock `json:"data"`
	}

	raw, _ := json.Marshal(tables)
	var tablesJSON json.RawMessage = raw

	_ = tablesJSON

	resp := wcPageResponse{}
	resp.Table = []struct {
		Data struct {
			Composite bool `json:"composite"`
			Tables    []struct {
				LeagueID   int    `json:"leagueId"`
				LeagueName string `json:"leagueName"`
				Table      struct {
					All []fotmobTableRow `json:"all"`
				} `json:"table"`
			} `json:"tables"`
		} `json:"data"`
	}{
		{Data: struct {
			Composite bool `json:"composite"`
			Tables    []struct {
				LeagueID   int    `json:"leagueId"`
				LeagueName string `json:"leagueName"`
				Table      struct {
					All []fotmobTableRow `json:"all"`
				} `json:"table"`
			} `json:"tables"`
		}{Composite: true, Tables: tables}},
	}

	return resp
}

// makeMockMatchup creates a finished wcMatchupRaw.
func makeMockMatchup(homeID, awayID, homeScore, awayScore, winnerID int, _ bool) wcMatchupRaw {
	r := wcMatchupRaw{
		HomeTeam:   "Home",
		HomeTeamID: homeID,
		AwayTeam:   "Away",
		AwayTeamID: awayID,
		Winner:     winnerID,
	}
	var entry struct {
		Home struct {
			Score  int  `json:"score"`
			Winner bool `json:"winner"`
		} `json:"home"`
		Away struct {
			Score  int  `json:"score"`
			Winner bool `json:"winner"`
		} `json:"away"`
		Status struct {
			Finished bool `json:"finished"`
			Reason   struct {
				ShortKey string `json:"shortKey"`
			} `json:"reason"`
		} `json:"status"`
	}
	entry.Home.Score = homeScore
	entry.Home.Winner = homeID == winnerID && homeScore != awayScore
	entry.Away.Score = awayScore
	entry.Away.Winner = awayID == winnerID && homeScore != awayScore
	entry.Status.Finished = true
	if homeScore == awayScore && winnerID != 0 {
		entry.Status.Reason.ShortKey = "penalties_short"
	}
	r.Matches = append(r.Matches, entry)
	return r
}
