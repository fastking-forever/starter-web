/* ========== تحدي الأبطال — إدارة اللعبة والشاشات ========== */
(function () {
  'use strict';

  var KEY = 'challenge-heroes-state-v2';
  var app = document.getElementById('app');
  var toastEl = document.getElementById('toast');
  var activeCleanup = null;
  var toastTimer = null;
  var modalEl = null;

  var COLORS = ['#a855f7', '#22d3ee', '#fbbf24', '#f472b6', '#34d399', '#fb7185', '#60a5fa', '#f97316', '#2dd4bf', '#c084fc'];

  function defaultState() {
    return {
      players: window.Characters.slice(0, 5).map(function (c, i) {
        return { id: 'p' + (i + 1), char: c.id, name: c.name, color: c.color, total: 0 };
      }),
      gameIndex: 0,
      turnIndex: 0,
      phase: 'setup',
      roundResults: [],
      history: [],
      last: null,
      sound: true
    };
  }

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (!raw) return defaultState();
      var s = JSON.parse(raw);
      if (!s || !Array.isArray(s.players) || !window.Games) return defaultState();
      s.players.forEach(function (p, i) {
        var valid = window.Characters.some(function (c) { return c.id === p.char; });
        if (!valid) p.char = window.Characters[i % window.Characters.length].id;
        var ch = window.charOf(p);
        p.color = ch.color;
        if (!p.name || /^لاعب \d+$/.test(p.name)) p.name = ch.name;
        p.total = p.total || 0;
      });
      s.gameIndex = Math.min(Math.max(0, s.gameIndex || 0), window.Games.length);
      s.roundResults = s.roundResults || [];
      s.history = s.history || [];
      s.sound = s.sound !== false;
      if (s.phase === 'play') s.phase = 'pass';
      if (['setup', 'hub', 'pass', 'score', 'gameResults', 'final', 'ranking'].indexOf(s.phase) === -1) s.phase = 'hub';
      return s;
    } catch (e) { return defaultState(); }
  }

  var S = load();

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {}
  }

  function esc(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, 1800);
  }

  function mount(html) {
    app.innerHTML = html;
    window.scrollTo(0, 0);
  }

  function on(sel, evt, fn) {
    var node = app.querySelector(sel);
    if (node) node.addEventListener(evt, fn);
  }

  function avatar(p, size) {
    var s = size || 40;
    var ch = window.charOf(p);
    return '<div class="avatar" style="width:' + s + 'px;height:' + s + 'px;font-size:' + Math.round(s * .52) +
      'px;background:linear-gradient(135deg,' + ch.color + ',' + shade(ch.color) + ')">' + ch.emoji + '</div>';
  }

  function shade(hex) {
    try {
      var r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
      return '#' + [r, g, b].map(function (v) { return Math.round(v * .55).toString(16).padStart(2, '0'); }).join('');
    } catch (e) { return '#4c1d95'; }
  }

  function clearConfetti() {
    var c = document.querySelector('.confetti');
    if (c) c.remove();
  }

  function render() {
    if (activeCleanup) { try { activeCleanup(); } catch (e) {} activeCleanup = null; }
    closeModal();
    clearConfetti();
    window.GameSound.enabled = S.sound;
    switch (S.phase) {
      case 'setup': setupScreen(); break;
      case 'hub': hubScreen(); break;
      case 'pass': passScreen(); break;
      case 'play': playScreen(); break;
      case 'score': scoreScreen(); break;
      case 'gameResults': gameResultsScreen(); break;
      case 'final': finalScreen(); break;
      case 'ranking': rankingScreen(); break;
      default: hubScreen();
    }
    save();
  }

  /* ---------- 1. الإعداد ---------- */
  function setupScreen() {
    function rows() {
      return S.players.map(function (p, i) {
        return '<div class="player-row"><span class="num">' + (i + 1) + '</span>' +
          '<button class="char-pick" data-pick="' + i + '" title="غيّر الشخصية">' + window.charOf(p).emoji + '</button>' +
          '<input type="text" maxlength="14" data-name="' + i + '" value="' + esc(p.name) + '" placeholder="اسم اللاعب">' +
          (S.players.length > 2 ? '<button class="del" data-del="' + i + '" aria-label="حذف">✕</button>' : '') + '</div>';
      }).join('');
    }

    mount('<div class="screen">' +
      '<div class="brand"><div class="brand-logo">🏆</div><div><h1>تحدي الأبطال</h1><p>5 تحديات — لعب بالتناوب على نفس الجهاز</p></div></div>' +
      '<h2 class="title">جهّز اللاعبين</h2>' +
      '<p class="subtitle">اكتب أسماء اللاعبين (2 إلى 10). كل واحد هياخد دوره في كل تحدي، والنقاط بتتراكم لحد النهاية.</p>' +
      '<div class="card" id="players-box">' + rows() + '</div>' +
      '<button class="add-player" id="add-player">＋ أضف لاعب</button>' +
      '<p class="hint" id="status">عدد اللاعبين: ' + S.players.length + ' — النقاط تتراكم عبر التحديات الخمسة.</p>' +
      '<button class="btn primary wide" id="start" style="margin-top:18px">ابدأ التحدي 🚀</button>' +
      '</div>');

    on('#players-box', 'click', function (e) {
      var b = e.target.closest('[data-pick]');
      if (b) openCharPicker(+b.dataset.pick);
    });

    on('#players-box', 'input', function (e) {
      var i = e.target.dataset.name;
      if (i === undefined) return;
      S.players[+i].name = e.target.value;
      save();
    });

    on('#players-box', 'click', function (e) {
      var b = e.target.closest('[data-del]');
      if (!b) return;
      S.players.splice(+b.dataset.del, 1);
      playRerenderSetup();
    });

    on('#add-player', 'click', function () {
      if (S.players.length >= 10) { toast('الحد الأقصى 10 لاعبين'); return; }
      S.players.push({ id: 'p' + Date.now(), name: 'لاعب ' + (S.players.length + 1), color: COLORS[S.players.length % COLORS.length], total: 0 });
      playRerenderSetup();
    });

    on('#start', 'click', function () {
      var names = S.players.map(function (p) { return p.name.trim(); });
      if (names.some(function (n) { return !n; })) { toast('اكتب اسم لكل لاعب أولاً'); return; }
      if (names.length !== new Set(names).size) { toast('الأسماء لازم تكون مختلفة'); return; }
      S.players.forEach(function (p, i) { p.name = names[i]; p.total = 0; });
      S.gameIndex = 0; S.turnIndex = 0; S.roundResults = []; S.history = []; S.last = null;
      S.phase = 'hub';
      render();
    });
  }

  function playRerenderSetup() {
    var focusIndex = document.activeElement && document.activeElement.dataset.name;
    setupScreen();
    if (focusIndex !== undefined) {
      var input = app.querySelector('[data-name="' + focusIndex + '"]');
      if (input) input.focus();
    }
  }

  function closeModal() {
    if (modalEl) { modalEl.remove(); modalEl = null; }
  }

  function openCharPicker(index) {
    var me = S.players[index];
    var grid = window.Characters.map(function (c) {
      var takenBy = -1;
      S.players.forEach(function (p, j) { if (j !== index && p.char === c.id) takenBy = j; });
      var cls = (me.char === c.id ? 'active ' : '') + (takenBy >= 0 ? 'taken' : '');
      return '<button data-c="' + c.id + '" class="' + cls + '" title="' + esc(c.name) + '">' + c.emoji + '</button>';
    }).join('');

    modalEl = document.createElement('div');
    modalEl.className = 'modal';
    modalEl.innerHTML = '<div class="modal-card"><h3>اختار شخصية ' + esc(me.name) + '</h3>' +
      '<p>لو الشخصية مستخدمة من لاعب تاني، هتتبادلوا الشخصيات تلقائياً.</p>' +
      '<div class="char-grid">' + grid + '</div>' +
      '<button class="btn wide" id="modal-close" style="margin-top:16px">تم ✓</button></div>';
    document.body.appendChild(modalEl);

    modalEl.addEventListener('click', function (e) {
      if (e.target === modalEl || e.target.id === 'modal-close') { closeModal(); return; }
      var b = e.target.closest('[data-c]');
      if (!b) return;
      var id = b.dataset.c;
      if (id === me.char) { closeModal(); return; }
      var other = -1;
      S.players.forEach(function (p, j) { if (j !== index && p.char === id) other = j; });
      var oldId = me.char;
      var oldChar = window.charOf(me);
      var otherOldChar = other >= 0 ? window.charOf(S.players[other]) : null;
      if (other >= 0) S.players[other].char = oldId;
      me.char = id;
      var newChar = window.charOf(me);
      if (/^لاعب \d+$/.test(me.name) || me.name === oldChar.name) me.name = newChar.name;
      me.color = newChar.color;
      if (other >= 0) {
        var otherNewChar = window.charOf(S.players[other]);
        if (/^لاعب \d+$/.test(S.players[other].name) || S.players[other].name === otherOldChar.name) S.players[other].name = otherNewChar.name;
        S.players[other].color = otherNewChar.color;
      }
      save(); closeModal(); setupScreen();
    });
  }

  /* ---------- 2. القائمة الرئيسية ---------- */
  function hubScreen() {
    var doneCount = S.history.length;
    var leader = S.players.slice().sort(function (a, b) { return b.total - a.total; })[0];
    var cards = window.Games.map(function (g, i) {
      var state = i < S.gameIndex ? '✓ تم' : (i === S.gameIndex ? 'جاري' : 'مقفل');
      var cls = i < S.gameIndex ? 'done' : (i === S.gameIndex ? 'current' : '');
      return '<div class="game-card ' + cls + '">' +
        '<div class="gicon" style="background:' + g.color + '22">' + g.emoji + '</div>' +
        '<div class="ginfo"><b>' + esc(g.name) + '</b><span>' + esc(g.desc) + '</span></div>' +
        '<div class="state">' + state + '</div></div>';
    }).join('');

    mount('<div class="screen">' +
      '<div class="topbar"><div class="brand" style="margin:0"><div class="brand-logo" style="width:42px;height:42px;font-size:22px">🏆</div>' +
      '<div><h1 style="font-size:17px">تحدي الأبطال</h1><p>الجولة ' + Math.min(S.gameIndex + 1, window.Games.length) + ' من ' + window.Games.length + '</p></div></div>' +
      '<div style="display:flex;gap:8px"><button class="icon-btn" id="sound-btn" aria-label="الصوت">' + (S.sound ? '🔊' : '🔇') + '</button>' +
      '<button class="icon-btn" id="rank-btn" aria-label="الترتيب">🥇</button></div></div>' +

      '<div class="hero"><small>المتصدر حالياً</small><h2>' + window.charOf(leader).emoji + ' ' + esc(leader.name) + ' 👑</h2>' +
      '<div class="hero-stats"><div><b>' + S.players.length + '</b><span>لاعبين</span></div>' +
      '<div><b>' + doneCount + ' / ' + window.Games.length + '</b><span>تحديات منتهية</span></div>' +
      '<div><b>' + leader.total + '</b><span>نقاط المتصدر</span></div></div></div>' +

      '<div class="section-label">التحديات الخمسة</div>' +
      '<div class="game-grid">' + cards + '</div>' +

      '<button class="btn primary wide" id="play-btn" style="margin-top:18px">' +
      (S.gameIndex < window.Games.length ? 'ابدأ: ' + esc(window.Games[S.gameIndex].name) + ' ▶' : 'عرض النتائج 🏁') + '</button>' +
      '<div class="btn-row" style="margin-top:10px">' +
      '<button class="btn small ghost" id="reset-btn">إعادة ضبط اللعبة</button>' +
      '<button class="btn small ghost" id="edit-btn">تعديل اللاعبين</button></div>' +
      '</div>');

    on('#sound-btn', 'click', function () {
      S.sound = !S.sound;
      window.GameSound.enabled = S.sound;
      toast(S.sound ? 'الصوت مفعّل' : 'الصوت مقفول');
      render();
    });
    on('#rank-btn', 'click', function () { S.phase = 'ranking'; render(); });
    on('#play-btn', 'click', function () {
      if (S.gameIndex >= window.Games.length) { S.phase = 'final'; render(); return; }
      S.turnIndex = 0; S.roundResults = []; S.phase = 'pass'; render();
    });
    on('#reset-btn', 'click', function () {
      if (confirm('هتمسح كل النقاط وتبدأ من الأول؟')) {
        S.players.forEach(function (p) { p.total = 0; });
        S.gameIndex = 0; S.turnIndex = 0; S.roundResults = []; S.history = []; S.last = null;
        S.phase = 'hub'; render(); toast('تمت إعادة الضبط');
      }
    });
    on('#edit-btn', 'click', function () {
      if (confirm('تعديل الأسماء هيوقف النقاط الحالية ويرجع للإعداد. متابعة؟')) {
        S.players.forEach(function (p) { p.total = 0; });
        S.gameIndex = 0; S.turnIndex = 0; S.roundResults = []; S.history = []; S.last = null;
        S.phase = 'setup'; render();
      }
    });
  }

  /* ---------- 3. تمرير الجهاز ---------- */
  function passScreen() {
    var p = S.players[S.turnIndex];
    var game = window.Games[S.gameIndex];
    var dots = S.players.map(function (_, i) { return '<i class="' + (i <= S.turnIndex ? 'on' : '') + '"></i>'; }).join('');

    mount('<div class="screen pass-screen">' +
      '<div class="eye">👀</div>' +
      '<h2 class="title" style="margin-top:18px">مرّر الجوال لـ</h2>' +
      '<p class="subtitle">التحدي: ' + esc(game.name) + ' — دور ' + (S.turnIndex + 1) + ' من ' + S.players.length + '</p>' +
      '<div class="pass-avatar" style="background:linear-gradient(135deg,' + window.charOf(p).color + ',' + shade(window.charOf(p).color) + ')">' +
      window.charOf(p).emoji + '</div>' +
      '<h2 style="margin:0 0 8px">' + esc(p.name) + '</h2>' +
      '<p class="subtitle" style="margin-bottom:26px">تأكد إن مفيش حد شايف الشاشة قبل ما تبدأ 👈</p>' +
      '<button class="btn primary wide" id="ready">أنا جاهز — ابدأ اللعبة ⚡</button>' +
      '<div class="progress-dots">' + dots + '</div>' +
      '</div>');

    on('#ready', 'click', function () { S.phase = 'play'; render(); });
  }

  /* ---------- 4. اللعب ---------- */
  function playScreen() {
    var game = window.Games[S.gameIndex];
    var p = S.players[S.turnIndex];
    mount('<div class="screen"><div id="game-area"></div>' +
      '<p class="hint" style="text-align:center">دور ' + esc(p.name) + ' — ' + esc(game.name) + '</p></div>');

    activeCleanup = game.mount(app.querySelector('#game-area'), function (score, note) {
      finishTurn(score, note);
    }, window.charOf(p));
  }

  function finishTurn(score, note) {
    score = Math.max(0, Math.min(100, Math.round(score || 0)));
    var p = S.players[S.turnIndex];
    p.total += score;
    S.roundResults.push({ id: p.id, name: p.name, color: p.color, score: score, note: note || '' });
    S.last = { player: p, score: score, note: note || '' };
    S.phase = 'score';
    render();
  }

  /* ---------- 5. نتيجة الدور ---------- */
  function scoreScreen() {
    var l = S.last;
    var medal = l.score >= 90 ? '🏆' : l.score >= 70 ? '🥇' : l.score >= 40 ? '🥈' : '🥉';
    var isLast = S.turnIndex >= S.players.length - 1;

    mount('<div class="screen score-pop">' +
      '<div class="medal">' + medal + '</div>' +
      '<h2>' + window.charOf(l.player).emoji + ' ' + esc(l.player.name) + '</h2>' +
      '<div class="pts">+' + l.score + ' <small>نقطة</small></div>' +
      '<div class="breakdown">' + (l.note ? esc(l.note) + ' • ' : '') + 'الرصيد الآن: ' + l.player.total + ' نقطة</div>' +
      '<button class="btn primary wide" id="next">' + (isLast ? 'شوف ترتيب التحدي 📊' : 'مرّر للاعب التالي ➜') + '</button>' +
      '</div>');

    on('#next', 'click', function () {
      if (isLast) { S.phase = 'gameResults'; render(); }
      else { S.turnIndex++; S.phase = 'pass'; render(); }
    });
  }

  /* ---------- 6. ترتيب التحدي ---------- */
  function gameResultsScreen() {
    var game = window.Games[S.gameIndex];
    var sorted = S.roundResults.slice().sort(function (a, b) { return b.score - a.score; });
    var rows = sorted.map(function (r, i) {
      var badge = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : (i + 1);
      return '<div class="rank-row"><div class="rank-pos">' + badge + '</div>' + avatar(r, 36) +
        '<div class="rank-name">' + esc(r.name) + (i === 0 ? ' 👑' : '') + '</div>' +
        '<div class="rank-score">' + r.score + '<small> نقطة</small></div></div>';
    }).join('');
    var isFinal = S.gameIndex >= window.Games.length - 1;

    mount('<div class="screen">' +
      '<div class="brand"><div class="brand-logo">' + game.emoji + '</div><div><h1>نتائج التحدي</h1><p>' + esc(game.name) + '</p></div></div>' +
      '<h2 class="title">ترتيب اللاعبين</h2>' +
      '<p class="subtitle">نقاط هذا التحدي اضافت لرصيد كل لاعب.</p>' +
      '<div class="rank-list">' + rows + '</div>' +
      '<button class="btn gold wide" id="continue" style="margin-top:20px">' +
      (isFinal ? 'شوف البطل النهائي 🏁' : 'التحدي التالي ➜') + '</button>' +
      '</div>');

    on('#continue', 'click', function () {
      S.history.push({ index: S.gameIndex, results: S.roundResults.slice() });
      if (isFinal) { S.gameIndex = window.Games.length; S.phase = 'final'; }
      else { S.gameIndex++; S.phase = 'hub'; }
      S.roundResults = []; S.turnIndex = 0; S.last = null;
      render();
    });
  }

  /* ---------- 7. الترتيب العام ---------- */
  function rankingScreen() {
    var sorted = S.players.slice().sort(function (a, b) { return b.total - a.total; });
    var rows = sorted.map(function (p, i) {
      return '<div class="rank-row"><div class="rank-pos">' + (i + 1) + '</div>' + avatar(p, 36) +
        '<div class="rank-name">' + esc(p.name) + '</div><div class="rank-score">' + p.total + '<small> نقطة</small></div></div>';
    }).join('');
    mount('<div class="screen">' +
      '<div class="topbar"><h2 class="title" style="margin:0">الترتيب العام</h2><button class="icon-btn" id="back">✕</button></div>' +
      '<div class="rank-list">' + rows + '</div></div>');
    on('#back', 'click', function () { S.phase = 'hub'; render(); });
  }

  /* ---------- 8. النهاية ---------- */
  function finalScreen() {
    var sorted = S.players.slice().sort(function (a, b) { return b.total - a.total; });
    var podiumOrder = [sorted[1], sorted[0], sorted[2]].filter(Boolean);
    var podiumClasses = ['second', 'first', 'third'];
    var podiumHtml = podiumOrder.map(function (p, i) {
      var medal = p === sorted[0] ? '👑' : p === sorted[1] ? '🥈' : '🥉';
      return '<div class="p ' + podiumClasses[i] + '"><div class="face">' + medal + '</div>' +
        '<div class="block">' + p.total + '</div><div class="nm">' + esc(p.name) + '</div></div>';
    }).join('');
    var rows = sorted.map(function (p, i) {
      return '<div class="rank-row' + (i === 0 ? ' me' : '') + '"><div class="rank-pos">' +
        (i === 0 ? '🏆' : i + 1) + '</div>' + avatar(p, 38) +
        '<div class="rank-name">' + esc(p.name) + '</div><div class="rank-score">' + p.total + '<small> نقطة</small></div></div>';
    }).join('');

    mount('<div class="screen">' +
      '<div style="text-align:center;padding-top:12px"><div style="font-size:60px">🎉</div>' +
      '<h2 class="title" style="margin:8px 0 4px">انتهت التحديات!</h2>' +
      '<p class="subtitle">البطل: ' + window.charOf(sorted[0]).emoji + ' ' + esc(sorted[0].name) + ' بـ ' + sorted[0].total + ' نقطة</p></div>' +
      '<div class="podium">' + podiumHtml + '</div>' +
      '<div class="section-label">الترتيب النهائي</div>' +
      '<div class="rank-list">' + rows + '</div>' +
      '<div class="btn-row" style="margin-top:18px">' +
      '<button class="btn primary" id="again">العب مرة تانية 🔁</button>' +
      '<button class="btn" id="edit">لاعبين جدد</button></div>' +
      '</div>');

    var colors = ['#fbbf24', '#a855f7', '#22d3ee', '#f472b6', '#34d399'];
    var conf = document.createElement('div');
    conf.className = 'confetti';
    for (var i = 0; i < 42; i++) {
      var bit = document.createElement('i');
      bit.style.left = Math.random() * 100 + '%';
      bit.style.background = colors[i % colors.length];
      bit.style.animationDuration = (2.2 + Math.random() * 2) + 's';
      bit.style.animationDelay = (Math.random() * 1.2) + 's';
      conf.appendChild(bit);
    }
    document.body.appendChild(conf);
    setTimeout(function () { conf.remove(); }, 5000);

    on('#again', 'click', function () {
      S.players.forEach(function (p) { p.total = 0; });
      S.gameIndex = 0; S.turnIndex = 0; S.roundResults = []; S.history = []; S.last = null; S.phase = 'hub';
      render();
    });
    on('#edit', 'click', function () {
      S.players.forEach(function (p) { p.total = 0; });
      S.gameIndex = 0; S.turnIndex = 0; S.roundResults = []; S.history = []; S.last = null; S.phase = 'setup';
      render();
    });
  }

  /* ---------- تشغيل ---------- */
  render();

  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () {});
    });
  }
})();
