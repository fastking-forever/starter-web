/* يولّد أيقونات PNG للـ PWA بدون مكتبات خارجية: node tools/gen-icons.js */
const fs = require('fs');
const zlib = require('zlib');
const path = require('path');

function crc32(buf) {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = c ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const name = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([name, data])));
  return Buffer.concat([len, name, data, crc]);
}

function cross(ax, ay, bx, by) { return ax * by - ay * bx; }

function inStar(x, y, cx, cy, outer, inner, points) {
  const dx = x - cx, dy = y - cy;
  const r = Math.hypot(dx, dy);
  if (r > outer) return false;
  let a = Math.atan2(dy, dx) - Math.PI / 2;
  const seg = Math.PI / points;
  while (a < 0) a += seg * 2;
  a %= seg;
  if (a < 0.0001) return r <= outer;
  if (a > seg - 0.0001) return r <= inner;
  const dirx = Math.cos(a), diry = Math.sin(a);
  const p1x = outer, p1y = 0;
  const p2x = inner * Math.cos(seg), p2y = inner * Math.sin(seg);
  const denom = cross(p2x - p1x, p2y - p1y, dirx, diry);
  if (Math.abs(denom) < 1e-9) return false;
  const t = -cross(p1x, p1y, dirx, diry) / denom;
  const bx = p1x + t * (p2x - p1x), by = p1y + t * (p2y - p1y);
  return r <= Math.hypot(bx, by);
}

function makePNG(size, outFile) {
  const rowSize = size * 4 + 1;
  const raw = Buffer.alloc(rowSize * size);
  const cx = size / 2, cy = size / 2;

  for (let y = 0; y < size; y++) {
    raw[y * rowSize] = 0;
    for (let x = 0; x < size; x++) {
      const u = y / size;
      let r = Math.round(109 + u * 80), g = Math.round(40 + u * 35), b = Math.round(180 + u * 40);
      const outer = size * 0.33, inner = size * 0.15;
      if (inStar(x, y, cx, cy - size * 0.01, outer, inner, 5)) { r = 255; g = 214; b = 90; }
      // لمعات صغيرة حول النجمة
      const sparkles = [[0.2, 0.25], [0.82, 0.3], [0.27, 0.76], [0.75, 0.72]];
      sparkles.forEach(function (s) {
        if (Math.hypot(x - s[0] * size, y - s[1] * size) < size * 0.022) { r = 255; g = 255; b = 255; }
      });
      // زوايا داكنة شوية لعمق
      const edge = Math.min(x, y, size - 1 - x, size - 1 - y) / size;
      const dim = 1 - Math.max(0, 0.12 - edge) * 1.1;
      const i = y * rowSize + 1 + x * 4;
      raw[i] = Math.max(0, Math.round(r * dim));
      raw[i + 1] = Math.max(0, Math.round(g * dim));
      raw[i + 2] = Math.max(0, Math.round(b * dim));
      raw[i + 3] = 255;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const png = Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))
  ]);
  fs.writeFileSync(outFile, png);
  console.log('تم إنشاء:', outFile, '(' + size + 'x' + size + ')');
}

const dir = path.join(__dirname, '..', 'icons');
fs.mkdirSync(dir, { recursive: true });
makePNG(192, path.join(dir, 'icon-192.png'));
makePNG(512, path.join(dir, 'icon-512.png'));
