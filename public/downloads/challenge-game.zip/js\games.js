/* ========== تحدي الأبطال — الألعاب الخمسة (نسخة الشخصيات) ========== */
(function () {
  'use strict';

  /* ---------- أصوات واهتزاز ---------- */
  var audioCtx = null;
  function beep(freq, duration, type) {
    try {
      if (!window.GameSound.enabled) return;
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      var osc = audioCtx.createOscillator(), gain = audioCtx.createGain();
      osc.type = type || 'sine'; osc.frequency.value = freq;
      gain.gain.setValueAtTime(.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime + duration);
      osc.connect(gain); gain.connect(audioCtx.destination);
      osc.start(); osc.stop(audioCtx.currentTime + duration);
    } catch (e) {}
  }
  function vibrate(ms) { try { if (window.GameSound.enabled && navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }

  window.GameSound = {
    enabled: true,
    tick: function () { beep(520, .05, 'square'); vibrate(6); },
    good: function () { beep(760, .09); setTimeout(function () { beep(1050, .12); }, 80); vibrate(15); },
    bad: function () { beep(170, .16, 'sawtooth'); vibrate([25, 40, 25]); },
    win: function () { [523, 659, 784, 1046].forEach(function (f, i) { setTimeout(function () { beep(f, .18); }, i * 110); }); vibrate([30, 40, 60]); }
  };

  /* ---------- الشخصيات ---------- */
  window.Characters = [
    { id: 'chicken', emoji: '🐔', name: 'دجاجة', color: '#fbbf24' },
    { id: 'fox', emoji: '🦊', name: 'ثعلب', color: '#f97316' },
    { id: 'bear', emoji: '🐻', name: 'دب', color: '#b45309' },
    { id: 'cat', emoji: '🐱', name: 'قط', color: '#f472b6' },
    { id: 'frog', emoji: '🐸', name: 'ضفدع', color: '#34d399' },
    { id: 'panda', emoji: '🐼', name: 'باندا', color: '#94a3b8' },
    { id: 'lion', emoji: '🦁', name: 'أسد', color: '#f59e0b' },
    { id: 'penguin', emoji: '🐧', name: 'بطريق', color: '#22d3ee' },
    { id: 'rabbit', emoji: '🐰', name: 'أرنب', color: '#c084fc' },
    { id: 'dog', emoji: '🐶', name: 'كلب', color: '#fb923c' }
  ];

  function charOf(p) {
    for (var i = 0; i < window.Characters.length; i++) {
      if (window.Characters[i].id === (p && p.char)) return window.Characters[i];
    }
    return window.Characters[0];
  }
  window.charOf = charOf;

  /* ---------- أدوات ---------- */
  function rand(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function shuffle(a) {
    var r = a.slice();
    for (var i = r.length - 1; i > 0; i--) { var j = rand(0, i), t = r[i]; r[i] = r[j]; r[j] = t; }
    return r;
  }
  function garbage() {
    var fns = [];
    return {
      add: function (fn) { fns.push(fn); },
      clear: function () { fns.forEach(function (f) { try { f(); } catch (e) {} }); fns = []; }
    };
  }
  function head(icon, title, desc, color) {
    return '<div class="game-head"><div class="gicon" style="background:' + color + '22">' + icon + '</div>' +
      '<div><h2>' + title + '</h2><p>' + desc + '</p></div></div>';
  }
  function hud(hero) {
    return '<div class="hud"><div class="hud-box"><span>النقاط</span><b id="hud-score">0</b></div>' +
      '<div class="hud-box hero-box"><span>بطل الدور</span><b>' + (hero ? hero.emoji + ' ' + hero.name : '') + '</b></div>' +
      '<div class="hud-box"><span>الوقت</span><b id="hud-time">20</b></div></div>' +
      '<div class="timer-track"><div class="timer-fill" id="hud-fill"></div></div>';
  }
  function arenaHtml(hero, inner, hint) {
    return '<div class="arena" id="arena">' + (inner || '') +
      '<div class="ground"></div>' + (hero ? '<div class="runner" id="runner"><span class="runner-face">' + hero.emoji + '</span></div>' : '') + '</div>' +
      '<p class="hint" style="text-align:center;margin-top:10px">' + hint + '</p>';
  }

  function hop(runner) {
    if (!runner) return;
    runner.classList.remove('hop'); void runner.offsetWidth; runner.classList.add('hop');
    var t = setTimeout(function () { runner.classList.remove('hop'); }, 390);
    return t;
  }

  function floatText(arena, x, y, text, color) {
    var f = document.createElement('span');
    f.className = 'floating-score';
    f.textContent = text;
    f.style.left = x + 'px'; f.style.top = y + 'px'; f.style.color = color;
    arena.appendChild(f);
    setTimeout(function () { f.remove(); }, 700);
  }

  function runTimer(gc, duration, onTick, onEnd) {
    var start = performance.now();
    var id = setInterval(function () {
      var remain = Math.max(0, duration - (performance.now() - start));
      onTick(remain / duration, Math.ceil(remain / 1000));
      if (remain <= 0) { clearInterval(id); onEnd(); }
    }, 50);
    gc.add(function () { clearInterval(id); });
    return id;
  }

  /* ================= 1. اجمع الدجاج ================= */
  function chickenGame(root, done, hero) {
    var gc = garbage(), score = 0, finished = false;
    root.innerHTML = head('🐔', 'اجمع الدجاج', 'المس الدجاج واكسب نقاط — إياك بالثعلب 🦊', '#fbbf24') +
      hud(hero) + arenaHtml(hero, '<div class="entity-layer" id="layer"></div>', 'اضغط على الدجاج اللي بيظهر — الثعلب بيخصم 15 نقطة') +
      '<div class="decor" style="text-align:center;font-size:30px">🌾 🐔 🌾 🐤 🌾 🐔 🌾</div>';

    var arena = root.querySelector('#arena'), layer = root.querySelector('#layer'), runner = root.querySelector('#runner');
    var scoreEl = root.querySelector('#hud-score'), timeEl = root.querySelector('#hud-time'), fill = root.querySelector('#hud-fill');

    function update() { scoreEl.textContent = score; }
    function end() { if (finished) return; finished = true; gc.clear(); done(Math.max(0, Math.min(100, score)), 'دجاجات مجمّعة'); }

    function spawn() {
      if (finished) return;
      var bad = Math.random() < .2;
      var e = document.createElement('button');
      e.className = 'ent spawn-in' + (bad ? ' bad' : '');
      e.textContent = bad ? '🦊' : pick(['🐔', '🐔', '🐤', '🥚']);
      e.style.left = rand(4, 82) + '%';
      e.style.top = rand(10, 62) + '%';
      layer.appendChild(e);
      var life = setTimeout(function () { e.remove(); }, 1000);
      gc.add(function () { clearTimeout(life); });
      e.addEventListener('pointerdown', function (ev) {
        ev.preventDefault();
        if (bad) { score = Math.max(0, score - 15); window.GameSound.bad(); floatText(arena, parseFloat(e.style.left) * arena.clientWidth / 100, parseFloat(e.style.top) * arena.clientHeight / 100, '-15', '#fb7185'); }
        else { score += 10; window.GameSound.good(); floatText(arena, parseFloat(e.style.left) * arena.clientWidth / 100, parseFloat(e.style.top) * arena.clientHeight / 100, '+10', '#fde68a'); }
        runner.style.left = e.style.left;
        hop(runner);
        e.remove(); update();
      });
    }

    var spawnId = setInterval(function () { spawn(); }, 560);
    gc.add(function () { clearInterval(spawnId); });
    spawn(); spawn();
    runTimer(gc, 20000, function (ratio, sec) { fill.style.width = (ratio * 100) + '%'; timeEl.textContent = sec; }, end);
    return gc.clear;
  }

  /* ================= 2. امسك التفاح ================= */
  function catchGame(root, done, hero) {
    var gc = garbage(), score = 0, finished = false;
    root.innerHTML = head('🍎', 'امسك التفاح', 'اسحب بطلتك لليسار أو لليمين واصطد التفاح', '#34d399') +
      hud(hero) + arenaHtml(hero, '<div class="entity-layer" id="layer"></div>', 'اسحب بإصبعك على الميدان — التفاح +10، القنبلة 💣 −15') +
      '<div class="decor" style="text-align:center;font-size:26px">🍏 🍎 🍐 🍏 🍎 🍐</div>';

    var arena = root.querySelector('#arena'), layer = root.querySelector('#layer'), runner = root.querySelector('#runner');
    var scoreEl = root.querySelector('#hud-score'), timeEl = root.querySelector('#hud-time'), fill = root.querySelector('#hud-fill');
    var items = [], heroX = arena.clientWidth / 2 || 160, loopId = 0, last = performance.now();

    function update() { scoreEl.textContent = score; }
    function end() { if (finished) return; finished = true; gc.clear(); done(Math.max(0, Math.min(100, score)), 'فواكه تمسّكت'); }

    function move(ev) {
      var rect = arena.getBoundingClientRect();
      heroX = Math.max(28, Math.min(rect.width - 28, ev.clientX - rect.left));
      runner.style.left = (heroX - 28) + 'px';
    }
    arena.addEventListener('pointerdown', move);
    arena.addEventListener('pointermove', function (e) { if (e.buttons || e.pointerType === 'touch') move(e); });
    gc.add(function () { arena.removeEventListener('pointerdown', move); });

    function spawn() {
      if (finished) return;
      var bad = Math.random() < .22;
      var el = document.createElement('div');
      el.className = 'ent falling';
      el.textContent = bad ? '💣' : pick(['🍎', '🍏', '🍐']);
      el.style.left = rand(4, 88) + '%';
      layer.appendChild(el);
      items.push({ el: el, x: el.offsetLeft, y: -40, vy: rand(3, 5.5), bad: bad });
    }
    var spawnId = setInterval(spawn, 520);
    gc.add(function () { clearInterval(spawnId); });

    function frame(now) {
      if (finished) return;
      var dt = Math.min(2.5, (now - last) / 16.7); last = now;
      var h = arena.clientHeight;
      for (var i = items.length - 1; i >= 0; i--) {
        var it = items[i];
        it.y += it.vy * dt;
        it.el.style.transform = 'translate3d(0,' + it.y + 'px,0)';
        var caught = it.y > h - 78 && Math.abs(it.x - heroX) < 42;
        if (caught) {
          score = it.bad ? Math.max(0, score - 15) : score + 10;
          it.bad ? window.GameSound.bad() : window.GameSound.good();
          hop(runner);
          floatText(arena, it.x, h - 60, it.bad ? '-15' : '+10', it.bad ? '#fb7185' : '#fde68a');
          it.el.remove(); items.splice(i, 1); update();
        } else if (it.y > h + 30) { it.el.remove(); items.splice(i, 1); }
      }
    }
    loopId = setInterval(function () { frame(performance.now()); }, 16);
    gc.add(function () { clearInterval(loopId); });

    runTimer(gc, 20000, function (ratio, sec) { fill.style.width = (ratio * 100) + '%'; timeEl.textContent = sec; }, end);
    return gc.clear;
  }

  /* ================= 3. قفز العقبات ================= */
  function jumpGame(root, done, hero) {
    var gc = garbage(), score = 0, lives = 3, finished = false;
    root.innerHTML = head('🐰', 'قفز العقبات', 'اطبّع على «اقفز» لتتجنب السياج 🌵', '#c084fc') +
      hud(hero) + arenaHtml(hero, '<div class="entity-layer" id="layer"></div><div class="lives" id="lives">❤️ ❤️ ❤️</div>', 'كل عقبة تتخطّاها = 10 نقاط — 3 محاولات بس') +
      '<button class="jump-btn" id="jump">اقفز ⬆️</button>';

    var arena = root.querySelector('#arena'), layer = root.querySelector('#layer');
    var runner = root.querySelector('#runner'), livesEl = root.querySelector('#lives');
    var scoreEl = root.querySelector('#hud-score'), timeEl = root.querySelector('#hud-time'), fill = root.querySelector('#hud-fill');
    var y = 0, vy = 0, jumping = false, obstacles = [], loopId = 0, last = performance.now();

    function update() { scoreEl.textContent = score; livesEl.textContent = Array(lives).fill('❤️').join(' ') + ' ' + Array(3 - lives).fill('🖤').join(' '); }
    function end() { if (finished) return; finished = true; gc.clear(); done(Math.min(100, score), 'عقبات تم تخطيها'); }

    runner.classList.add('running');
    function jump() { if (!jumping && !finished) { jumping = true; vy = -9; window.GameSound.tick(); hop(runner); } }
    root.querySelector('#jump').addEventListener('pointerdown', function (e) { e.preventDefault(); jump(); });
    arena.addEventListener('pointerdown', jump);
    gc.add(function () { arena.removeEventListener('pointerdown', jump); });

    function spawn() {
      if (finished) return;
      var el = document.createElement('div');
      el.className = 'ent obstacle';
      el.textContent = pick(['🌵', '🧱', '🚧', '🪵']);
      layer.appendChild(el);
      obstacles.push({ el: el, x: arena.clientWidth + 20, hit: false });
    }
    var spawnId = setInterval(spawn, 1050);
    gc.add(function () { clearInterval(spawnId); });
    spawn();

    function frame(now) {
      if (finished) return;
      var dt = Math.min(2.5, (now - last) / 16.7); last = now;
      if (jumping) {
        vy += .62 * dt; y += vy * dt;
        if (y >= 0) { y = 0; vy = 0; jumping = false; }
      }
      runner.style.transform = 'translate(-50%,' + y + 'px)';
      for (var i = obstacles.length - 1; i >= 0; i--) {
        var o = obstacles[i];
        o.x -= (4.6 + score / 60) * dt;
        o.el.style.transform = 'translate3d(' + o.x + 'px,0,0)';
        if (!o.hit && o.x < 72 && o.x > 18 && y > -38) {
          o.hit = true; lives--; score = Math.max(0, score - 10);
          window.GameSound.bad(); arena.classList.add('shake');
          setTimeout(function () { arena.classList.remove('shake'); }, 250);
          floatText(arena, 40, arena.clientHeight - 90, '-10', '#fb7185');
          update();
          if (lives <= 0) { end(); return; }
        }
        if (o.x < -60) { o.el.remove(); obstacles.splice(i, 1); score += 10; update(); }
      }
    }
    loopId = setInterval(function () { frame(performance.now()); }, 16);
    gc.add(function () { clearInterval(loopId); });

    runTimer(gc, 20000, function (ratio, sec) { fill.style.width = (ratio * 100) + '%'; timeEl.textContent = sec; }, end);
    return gc.clear;
  }

  /* ================= 4. فقّ البالونات ================= */
  function balloonGame(root, done, hero) {
    var gc = garbage(), score = 0, finished = false;
    root.innerHTML = head('🎈', 'فقّ البالونات', 'افقع البالونات قبل ما تهرب — بالون القنبلة يخصم', '#f472b6') +
      hud(hero) + arenaHtml(hero, '<div class="entity-layer" id="layer"></div>', 'اضغط على 🎈 لـ +10 — لو ضربت 💣 هتخسر 15 نقطة') +
      '<div class="decor" style="text-align:center;font-size:28px">🎈 ☁️ 🎈 ☁️ 🎈 ☁️ 🎈</div>';

    var arena = root.querySelector('#arena'), layer = root.querySelector('#layer'), runner = root.querySelector('#runner');
    var scoreEl = root.querySelector('#hud-score'), timeEl = root.querySelector('#hud-time'), fill = root.querySelector('#hud-fill');
    var balloons = [], loopId = 0, last = performance.now();

    function update() { scoreEl.textContent = score; }
    function end() { if (finished) return; finished = true; gc.clear(); done(Math.max(0, Math.min(100, score)), 'بالونات مفقوعة'); }

    function spawn() {
      if (finished) return;
      var bad = Math.random() < .18;
      var el = document.createElement('button');
      el.className = 'ent balloon' + (bad ? ' bad' : '');
      el.textContent = bad ? '💣' : pick(['🎈', '🎈', '🎈', '🫧']);
      el.style.left = rand(4, 86) + '%';
      layer.appendChild(el);
      balloons.push({ el: el, x: el.offsetLeft, y: arena.clientHeight + 10, vy: rand(2.4, 4.6), bad: bad });
      el.addEventListener('pointerdown', function (ev) {
        ev.preventDefault();
        for (var i = 0; i < balloons.length; i++) {
          if (balloons[i].el === el) {
            score = bad ? Math.max(0, score - 15) : score + 10;
            bad ? window.GameSound.bad() : window.GameSound.good();
            floatText(arena, balloons[i].x, balloons[i].y, bad ? '-15' : '+10', bad ? '#fb7185' : '#fde68a');
            runner.style.left = balloons[i].x + 'px';
            hop(runner);
            el.remove(); balloons.splice(i, 1); update();
            break;
          }
        }
      });
    }
    var spawnId = setInterval(spawn, 480);
    gc.add(function () { clearInterval(spawnId); });
    spawn(); spawn(); spawn();

    function frame(now) {
      if (finished) return;
      var dt = Math.min(2.5, (now - last) / 16.7); last = now;
      for (var i = balloons.length - 1; i >= 0; i--) {
        var b = balloons[i];
        b.y -= b.vy * dt;
        b.el.style.transform = 'translate3d(0,' + (b.y - arena.clientHeight) + 'px,0)';
        if (b.y < -40) { b.el.remove(); balloons.splice(i, 1); }
      }
    }
    loopId = setInterval(function () { frame(performance.now()); }, 16);
    gc.add(function () { clearInterval(loopId); });

    runTimer(gc, 20000, function (ratio, sec) { fill.style.width = (ratio * 100) + '%'; timeEl.textContent = sec; }, end);
    return gc.clear;
  }

  /* ================= 5. ذاكرة الأبطال ================= */
  function memoryGame(root, done, hero) {
    var faces = window.Characters.slice(0, 6).map(function (c) { return c.emoji; });
    var deck = shuffle(faces.concat(faces));
    var flipped = [], matched = 0, moves = 0, busy = false, finished = false;
    var gc = garbage();

    root.innerHTML = head('🧠', 'ذاكرة الأبطال', 'اعثر على أزواج الشخصيات بأقل عدد محاولات', '#34d399') +
      '<div class="stat-strip"><div class="stat-box"><span>المحاولات</span><b id="m-moves">0</b></div>' +
      '<div class="stat-box"><span>الأزواج</span><b id="m-pairs">0 / 6</b></div></div>' +
      '<div class="memory-grid" id="m-grid">' +
      deck.map(function (ic, i) {
        return '<button class="mem-card" data-i="' + i + '"><span class="mem-inner">' +
          '<span class="mem-face mem-back">' + (hero ? hero.emoji : '❓') + '</span>' +
          '<span class="mem-face mem-front">' + ic + '</span></span></button>';
      }).join('') + '</div>';

    var grid = root.querySelector('#m-grid'), movesEl = root.querySelector('#m-moves'), pairsEl = root.querySelector('#m-pairs');

    function end(score, note) { if (finished) return; finished = true; gc.clear(); done(score, note); }

    grid.addEventListener('click', function (e) {
      var card = e.target.closest('.mem-card');
      if (!card || busy || finished) return;
      var i = +card.dataset.i;
      if (card.classList.contains('flipped') || card.classList.contains('matched')) return;
      card.classList.add('flipped'); window.GameSound.tick(); flipped.push(card);
      if (flipped.length < 2) return;
      busy = true; moves++; movesEl.textContent = moves;
      var a = flipped[0], b = flipped[1];
      if (deck[+a.dataset.i] === deck[+b.dataset.i]) {
        a.classList.add('matched'); b.classList.add('matched');
        a.classList.remove('flipped'); b.classList.remove('flipped');
        matched++; pairsEl.textContent = matched + ' / 6';
        window.GameSound.good(); flipped = []; busy = false;
        if (matched === 6) end(Math.max(10, 100 - (moves - 6) * 7), 'أكملتها في ' + moves + ' محاولة');
      } else {
        var t = setTimeout(function () { a.classList.remove('flipped'); b.classList.remove('flipped'); flipped = []; busy = false; }, 780);
        gc.add(function () { clearTimeout(t); });
      }
    });

    return gc.clear;
  }

  window.Games = [
    { name: 'اجمع الدجاج', emoji: '🐔', desc: 'المس الدجاج واكسب — والثعلب بيخصم!', color: '#fbbf24', mount: chickenGame },
    { name: 'امسك التفاح', emoji: '🍎', desc: 'اسحب بطلتك واصطد التفاح، اتجنّب القنابل', color: '#34d399', mount: catchGame },
    { name: 'قفز العقبات', emoji: '🐰', desc: 'اقفز فوق السياج واتخطّى 3 عقبات', color: '#c084fc', mount: jumpGame },
    { name: 'فقّ البالونات', emoji: '🎈', desc: 'افقع البالونات قبل ما تهرب منك', color: '#f472b6', mount: balloonGame },
    { name: 'ذاكرة الأبطال', emoji: '🧠', desc: 'اعثر على أزواج الشخصيات بأقل محاولات', color: '#22d3ee', mount: memoryGame }
  ];
})();
