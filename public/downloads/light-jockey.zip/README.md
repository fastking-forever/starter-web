# Light Jockey — Browser Edition

A playable HTML5 port of [Light-Jockey](https://github.com/jmfieldman/Light-Jockey), the 2009 iPhone game by Jason Fieldman. The original Objective-C project needs an old Xcode/iPhone SDK, so this version reimplements the same beam physics, discs, prisms, targets and **all 30 original levels** using Canvas 2D + WebAudio.

## Run

Open `index.html` in a modern browser (Chrome / Edge / Firefox / Safari). No server or build step is needed.

## Controls

| Action | Control |
| --- | --- |
| Move a disc | Drag it with mouse / finger |
| Resize a disc | Mouse wheel over it, the `−` / `+` buttons, or the `-` / `+` keys |
| Restart level | `↺` button or `R` |
| Level select | `☰` button or `Esc` |
| Mute / unmute | `♪` button |

The goal is to fill **every** target ring to maximum and keep them all lit for a few seconds. Discs bend, pull, push, bounce, split or change the speed of the light. Prisms change its colour — a target only charges from a beam of the matching colour.

## Files

- `index.html`, `style.css`, `game.js` — the game.
- `levels.js` — generated from the original `LJLevelData.m`; contains all 30 levels.
- `assets/` — copied images from the original repository (background and disc icons).
- `tools/parse-levels.ps1` — regenerates `levels.js` from the original Objective-C level table:

  ```powershell
  powershell -ExecutionPolicy Bypass -File .\tools\parse-levels.ps1
  ```

Progress (beaten levels) is stored in `localStorage`.

## Fidelity notes

- Simulation runs at 50 Hz like the original `NSTimer` interval (0.02 s).
- Beam charge/friction, push directions, attraction/repulsion, bounce, split angle (±30°) and target charge/decay values mirror the original constants.
- The original OpenGL ping-pong blur is approximated with a low-resolution additive buffer plus a two-pass canvas blur.
- The original `.caf` music tracks are replaced with soft WebAudio tones whose volume follows target charge, since those files are iOS-era audio containers.
- Win hold time is 3 s (original: 4 s) to make it a little friendlier.
