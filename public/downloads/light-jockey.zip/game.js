/* Light Jockey — browser port of the 2009 iPhone game by Jason Fieldman.
   Physics and level data are faithful to the original Objective-C sources. */
(() => {
'use strict';

const W = 320, H = 480;
const LEVELS = window.LJ_LEVELS || [];

const COLOR = {
  WHITE:0, CYAN:1, MAGENTA:2, YELLOW:3, BLUE:4, RED:5, GREEN:6,
  CHR1:7, CHR2:8, CHR3:9, DIV1:10, DIV2:11, DIV3:12,
  REP1:13, REP2:14, RAINBOW:15
};
const CORE = [
  [255,255,255],[96,255,255],[255,96,255],[255,255,96],[0,0,255],[255,0,0],[96,255,96],
  [255,128,128],[255,210,103],[255,103,228],
  [128,128,255],[64,220,255],[255,160,255],
  [255,255,64],[255,160,96],[255,255,0]
];
const GLOW = [
  [160,160,160],[0,160,160],[160,0,160],[160,160,0],[0,0,160],[160,0,0],[10,160,10],
  [160,80,80],[160,120,80],[160,0,160],
  [24,34,160],[16,136,160],[160,72,160],
  [160,160,40],[160,80,20],[160,160,160]
];
const DIR = { N:1, W:2, S:4, E:8 };
const DTYPE = {
  NONE:0, PUSH:1, ATTRACT:2, REPEL:3, SPEEDUP:4, SLOWDOWN:5, GRAVITY:6, BOUNCE:7, SPLIT:8
};
const ICON = {
  1:'disc_push.png', 2:'disc_attract.png', 3:'disc_repel.png', 4:'disc_speed.png',
  5:'disc_slow.png', 6:'disc_radar.png', 7:'disc_bounce.png', 8:'disc_radar.png'
};
const GROUP_TIPS = {
  LEARNING:   'Drag the discs to bend the light into every target.',
  CHROMATICS: 'Prisms recolour the beam — match each target’s colour.',
  GRAVITATION:'Attraction and repulsion bend the beam into curves.',
  DIVISION:   'Split discs fork the light into two directions.',
  SPEED:      'Speed discs keep the light alive across long gaps.',
  REPULSION:  'Bounce discs reflect the beam away from their surface.'
};

const canvas = document.getElementById('game');
const dpr = Math.min(2, window.devicePixelRatio || 1);
canvas.width = Math.round(W * dpr);
canvas.height = Math.round(H * dpr);
const ctx = canvas.getContext('2d');
const fx = document.createElement('canvas');
fx.width = W; fx.height = H;
const fxc = fx.getContext('2d');

const el = {
  levelLabel: document.getElementById('levelLabel'),
  hint: document.getElementById('hint'),
  menu: document.getElementById('menu'),
  menuList: document.getElementById('levelList'),
  menuProgress: document.getElementById('menuProgress'),
  complete: document.getElementById('complete'),
  toast: document.getElementById('toast'),
  radius: document.getElementById('radiusLabel'),
  btnSound: document.getElementById('btnSound'),
  btnReset: document.getElementById('btnReset'),
  btnMenu: document.getElementById('btnMenu'),
  btnCloseMenu: document.getElementById('btnCloseMenu'),
  btnNext: document.getElementById('btnNext'),
  btnSmaller: document.getElementById('btnSmaller'),
  btnBigger: document.getElementById('btnBigger')
};

let state = null;
let beaten = loadBeaten();
let soundOn = true;
let activeDisc = -1;
let dragOffset = { x:0, y:0 };
let toastTimer = 0;
let lastTime = 0, accumulator = 0;
let audio = null;
const targetVoices = [];
let bgImage = null;

/* ------------------------------------------------------------------ utils */
const clamp = (v,a,b) => Math.max(a, Math.min(b,v));
const randInt = n => Math.floor(Math.random() * (n + 1));
const inCircle = (x,y,cx,cy,r) => (x-cx)*(x-cx) + (y-cy)*(y-cy) <= r*r;
const sy = y => H - y; // data space is y-up (OpenGL), screen space is y-down

function showToast(text) {
  el.toast.textContent = text;
  el.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.toast.classList.remove('show'), 1100);
}
function loadBeaten() {
  try { return JSON.parse(localStorage.getItem('lj-web-beaten') || '{}'); } catch (_) { return {}; }
}
function saveBeaten() {
  try { localStorage.setItem('lj-web-beaten', JSON.stringify(beaten)); } catch (_) {}
}
const rgba = (c,a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;

/* ------------------------------------------------------------------ audio */
function ensureAudio() {
  if (audio || !soundOn) return;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  audio = new AC();
}
function startVoices(count) {
  targetVoices.forEach(v => { try { v.osc.stop(); } catch (_) {} });
  targetVoices.length = 0;
  if (!audio) return;
  const scale = [0,3,5,7,10,12,15,17,19,22];
  for (let i=0; i<count; i++) {
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = i % 2 ? 'triangle' : 'sine';
    osc.frequency.value = 196 * Math.pow(2, (scale[i % scale.length] + 12*Math.floor(i/scale.length))/12);
    gain.gain.value = 0;
    osc.connect(gain).connect(audio.destination);
    osc.start();
    targetVoices.push({ osc, gain });
  }
}
function updateVoices() {
  if (!audio || !state) return;
  state.targets.forEach((t,i) => {
    const v = targetVoices[i];
    if (v) v.gain.gain.setTargetAtTime(soundOn ? (t.power/1024) * 0.035 : 0, audio.currentTime, 0.1);
  });
}
function chime() {
  if (!audio || !soundOn) return;
  const now = audio.currentTime;
  [0,4,7,12].forEach((semi,i) => {
    const o = audio.createOscillator(), g = audio.createGain();
    o.type = 'sine';
    o.frequency.value = 440 * Math.pow(2, semi/12);
    g.gain.setValueAtTime(0, now + i*0.11);
    g.gain.linearRampToValueAtTime(0.12, now + i*0.11 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, now + i*0.11 + 0.5);
    o.connect(g).connect(audio.destination);
    o.start(now + i*0.11); o.stop(now + i*0.11 + 0.55);
  });
}

/* ------------------------------------------------------------------ levels */
function levelNumber(i) {
  let n = i + 1;
  for (let g=0; g<LEVELS.length; g++) {
    if (n <= countInGroup(g)) return `${g+1}:${n}`;
    n -= countInGroup(g);
  }
  return '1:1';
}
const countInGroup = g => LEVELS.filter(l => l.group === groupNameAt(g)).length;
const groupNames = [];
LEVELS.forEach(l => { if (!groupNames.includes(l.group)) groupNames.push(l.group); });
function groupNameAt(g) { return groupNames[g]; }

function buildMenu() {
  el.menuList.innerHTML = '';
  let idx = 0;
  const total = LEVELS.length;
  const done = LEVELS.filter((l,i) => beaten[l.tag]).length;
  el.menuProgress.textContent = `${done} / ${total} levels beaten`;
  groupNames.forEach((gname, g) => {
    const head = document.createElement('div');
    head.className = 'group';
    head.textContent = `${g+1}. ${gname}`;
    el.menuList.appendChild(head);
    const grid = document.createElement('div');
    grid.className = 'level-grid';
    let local = 0;
    LEVELS.forEach((l, i) => {
      if (l.group !== gname) return;
      const b = document.createElement('button');
      b.className = 'level-btn' + (state && state.index === i ? ' current' : '');
      const win = beaten[l.tag];
      b.innerHTML = `<span class="num">${g+1}:${local+1}</span>${l.name}<br><span class="star${win?'':' off'}">★</span>`;
      b.onclick = () => { ensureAudio(); loadLevel(i); hideMenu(); };
      grid.appendChild(b);
      local++; idx++;
    });
    el.menuList.appendChild(grid);
  });
}
function showMenu() { buildMenu(); el.menu.classList.remove('hidden'); }
function hideMenu() { el.menu.classList.add('hidden'); }

function loadLevel(index) {
  const d = LEVELS[index];
  if (!d) return;
  ensureAudio();
  startVoices(d.targets.length);
  state = {
    index, level: d,
    beams: [], discs: [], targets: [], prisms: [],
    intro: 1, winTimer: 0, completed: false,
    time: 0
  };
  d.discs.forEach(v => state.discs.push({
    x: v.x, y: v.y, type: DTYPE[v.type] || 0,
    dir: DIR[v.dir] || 0, radius: 48
  }));
  d.targets.forEach(v => state.targets.push({
    x: v.x, y: v.y, color: COLOR[v.color] !== undefined ? COLOR[v.color] : 0,
    power: 0, charge: 0
  }));
  d.prisms.forEach(v => state.prisms.push({
    x: v.x, y: v.y, color: COLOR[v.color] !== undefined ? COLOR[v.color] : 0,
    radius: v.radius || 20
  }));
  activeDisc = -1;
  el.levelLabel.textContent = `${levelNumber(index)} ${d.name.toUpperCase()}`;
  el.hint.textContent = GROUP_TIPS[d.group] || 'Drag the discs to steer the light.';
  el.radius.textContent = '48';
  el.complete.classList.add('hidden');
  showToast(`${levelNumber(index)} — ${d.name}`);
}

/* ------------------------------------------------------------------ physics */
function spawnBeam() {
  const d = state.level;
  state.beams.push({
    x: d.homeX + randInt(d.homeJitter),
    y: d.homeY + randInt(d.homeJitter),
    vx: d.vx + randInt(d.velJitter),
    vy: d.vy + randInt(d.velJitter),
    color: COLOR[d.startColor] !== undefined ? COLOR[d.startColor] : 0,
    life: 240, charge: d.charge, maxCharge: d.charge,
    friction: d.friction, wasInDisc: false,
    trail: []
  });
}
function clampSpeed(b) {
  b.vx = clamp(b.vx, -60, 60);
  b.vy = clamp(b.vy, -60, 60);
}
function applyDisc(b, disc) {
  switch (disc.type) {
    case DTYPE.PUSH:
      if (disc.dir === DIR.N) b.vy += 1;
      if (disc.dir === DIR.S) b.vy -= 1;
      if (disc.dir === DIR.W) b.vx -= 1;
      if (disc.dir === DIR.E) b.vx += 1;
      clampSpeed(b);
      b.charge = b.maxCharge;
      break;
    case DTYPE.SPEEDUP: b.vx *= 1.05; b.vy *= 1.05; b.charge = b.maxCharge; break;
    case DTYPE.SLOWDOWN: b.vx *= 0.95; b.vy *= 0.95; b.charge = b.maxCharge; break;
    case DTYPE.BOUNCE: {
      const dx = disc.x - b.x, dy = disc.y - b.y;
      const len = Math.hypot(dx, dy) || 1;
      const nx = dx/len, ny = dy/len;
      const dot = b.vx*nx + b.vy*ny;
      if (dot > 0) { b.vx -= 2*dot*nx; b.vy -= 2*dot*ny; b.charge = b.maxCharge; }
      break;
    }
    case DTYPE.ATTRACT:
    case DTYPE.REPEL: {
      const dx = disc.x - b.x, dy = disc.y - b.y;
      const dist = Math.hypot(dx, dy) || 1;
      if (dist < 16) {
        if (disc.type === DTYPE.ATTRACT && Math.hypot(b.vx,b.vy) < 8) b.life = 0;
        break;
      }
      const force = 64 / dist;
      const fx2 = force * dx/dist, fy2 = force * dy/dist;
      if (disc.type === DTYPE.ATTRACT) { b.vx += fx2; b.vy += fy2; }
      else { b.vx -= fx2/2; b.vy -= fy2/2; }
      break;
    }
    case DTYPE.SPLIT: {
      const toCenter = Math.atan2(disc.y-b.y, disc.x-b.x) * 180/Math.PI;
      const travel = Math.atan2(b.vy, b.vx) * 180/Math.PI;
      let diff = Math.abs(toCenter - travel) % 360;
      if (diff > 180) diff = 360 - diff;
      if (b.wasInDisc && diff >= 120) break;
      const ang = (travel + (Math.random() < 0.5 ? 30 : -30)) * Math.PI/180;
      const speed = Math.hypot(b.vx, b.vy);
      b.vx = Math.cos(ang)*speed; b.vy = Math.sin(ang)*speed;
      b.x = disc.x + Math.cos(ang)*7 + (Math.random()*9-4);
      b.y = disc.y + Math.sin(ang)*7 + (Math.random()*9-4);
      break;
    }
    case DTYPE.GRAVITY: b.vy -= 0.5; break;
  }
}

function step() {
  const s = state;
  if (!s || s.completed) return;
  s.time++;

  for (const t of s.targets) {
    if (t.charge > 0) t.charge--;
    else if (t.power > 0) t.power = Math.max(0, t.power - 10);
  }

  for (let i = s.beams.length-1; i >= 0; i--) {
    const b = s.beams[i];
    b.life--;
    if (b.charge > 0) b.charge--;
    else { b.vx *= b.friction; b.vy *= b.friction; }

    const bx = b.x, by = b.y;
    let inDisc = false;
    for (const d of s.discs) {
      if (inCircle(bx, by, d.x, d.y, d.radius)) { applyDisc(b, d); inDisc = true; }
    }
    b.wasInDisc = inDisc;

    for (const t of s.targets) {
      if (t.color === b.color && inCircle(bx, by, t.x, t.y, 32)) {
        t.charge = 30;
        t.power = Math.min(1024, t.power + 4);
      }
    }

    b.x += b.vx; b.y += b.vy;
    for (const p of s.prisms) {
      if (b.color !== p.color && inCircle(b.x, b.y, p.x, p.y, p.radius)) b.color = p.color;
    }
    b.trail.push({ x:b.x, y:b.y });
    if (b.trail.length > 20) b.trail.shift();

    if (b.x > W+200 || b.y > H+200 || b.x < -200 || b.y < -200 ||
        b.life < 0 || (b.charge <= 0 && Math.abs(b.vx) < 0.3 && Math.abs(b.vy) < 0.3)) {
      s.beams.splice(i,1);
    }
  }

  if (--s.intro <= 0 && s.beams.length < 200) {
    spawnBeam();
    s.intro = 1 + (Math.random() < 0.5 ? 0 : 1);
  }

  updateVoices();

  if (s.targets.length && s.targets.every(t => t.power >= 1024)) {
    s.winTimer += 1/50;
    if (s.winTimer >= 3) completeLevel();
  } else {
    s.winTimer = 0;
  }
}

function completeLevel() {
  const s = state;
  if (!s || s.completed) return;
  s.completed = true;
  beaten[s.level.tag] = true;
  saveBeaten();
  chime();
  el.complete.classList.remove('hidden');
  const last = s.index === LEVELS.length-1;
  document.getElementById('btnNext').textContent = last ? 'Back to menu →' : 'Next level →';
}

/* ------------------------------------------------------------------ drawing */
function loadImages() {
  bgImage = new Image(); bgImage.src = 'assets/background512.jpg';
  const icons = {};
  Object.values(ICON).forEach(name => {
    const img = new Image(); img.src = 'assets/disc_icons/' + name;
    icons[name] = img;
  });
  return icons;
}
const icons = loadImages();

function drawBackground() {
  ctx.setTransform(1,0,0,1,0,0);
  ctx.fillStyle = '#02040b';
  ctx.fillRect(0,0,W,H);
  ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);
  if (bgImage && bgImage.complete && bgImage.naturalWidth) {
    ctx.globalAlpha = 0.30;
    ctx.drawImage(bgImage, 0,0,W,H);
    ctx.globalAlpha = 1;
  }
  ctx.fillStyle = 'rgba(0,0,0,.35)';
  ctx.fillRect(0,0,W,H);
}

function drawBeams() {
  fxc.clearRect(0,0,W,H);
  fxc.globalCompositeOperation = 'lighter';
  fxc.lineCap = 'round';
  fxc.lineJoin = 'round';
  for (const b of state.beams) {
    const p = b.trail;
    if (p.length < 2) continue;
    const c = GLOW[b.color] || GLOW[0];
    const chunks = 4, per = Math.ceil(p.length/chunks);
    for (let k=0; k<chunks; k++) {
      const from = k*per, to = Math.min(p.length-1, (k+1)*per);
      if (from >= to) continue;
      fxc.strokeStyle = rgba(c, 0.18 + 0.20*k);
      fxc.lineWidth = k === chunks-1 ? 2.6 : 2.0;
      fxc.beginPath();
      fxc.moveTo(p[from].x, sy(p[from].y));
      for (let j=from+1; j<=to; j++) fxc.lineTo(p[j].x, sy(p[j].y));
      fxc.stroke();
    }
    fxc.fillStyle = rgba(c, 0.55);
    fxc.beginPath();
    fxc.arc(b.x, sy(b.y), 2.6, 0, Math.PI*2);
    fxc.fill();
  }
  fxc.globalCompositeOperation = 'source-over';

  ctx.globalCompositeOperation = 'lighter';
  if ('filter' in ctx) {
    ctx.filter = 'blur(7px)'; ctx.globalAlpha = 0.9; ctx.drawImage(fx,0,0);
    ctx.filter = 'blur(2px)'; ctx.globalAlpha = 0.85; ctx.drawImage(fx,0,0);
    ctx.filter = 'none';
  }
  ctx.globalAlpha = 1;
  ctx.drawImage(fx,0,0);
  ctx.globalCompositeOperation = 'source-over';
}

function drawPrisms() {
  for (const p of state.prisms) {
    const c = CORE[p.color] || CORE[0];
    const X = p.x, Y = sy(p.y);
    const g = ctx.createRadialGradient(X,Y,1,X,Y,p.radius);
    g.addColorStop(0, rgba(c,0.55));
    g.addColorStop(0.7, rgba(c,0.18));
    g.addColorStop(1, rgba(c,0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(X,Y,p.radius,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle = rgba(c,0.75); ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(X,Y,p.radius*0.75,0,Math.PI*2); ctx.stroke();
  }
}

function drawDiscs() {
  state.discs.forEach((d,i) => {
    const X = d.x, Y = sy(d.y);
    const selected = i === activeDisc;
    ctx.save();
    ctx.strokeStyle = selected ? 'rgba(255,255,255,.75)' : 'rgba(140,190,240,.42)';
    ctx.lineWidth = selected ? 2 : 1;
    ctx.setLineDash([4,6]);
    ctx.beginPath(); ctx.arc(X,Y,d.radius,0,Math.PI*2); ctx.stroke();
    ctx.setLineDash([]);

    const img = icons[ICON[d.type]];
    if (img && img.complete && img.naturalWidth) {
      let rot = 0;
      if (d.type === DTYPE.PUSH) {
        if (d.dir === DIR.E) rot = Math.PI/2;
        if (d.dir === DIR.S) rot = Math.PI;
        if (d.dir === DIR.W) rot = Math.PI*1.5;
      }
      ctx.translate(X,Y); ctx.rotate(rot);
      ctx.globalAlpha = selected ? 1 : 0.85;
      ctx.drawImage(img,-17,-17,34,34);
      ctx.globalAlpha = 1;
    } else {
      ctx.fillStyle = 'rgba(120,200,255,.5)';
      ctx.beginPath(); ctx.arc(X,Y,10,0,Math.PI*2); ctx.fill();
    }
    ctx.restore();
  });
}

function drawTargets() {
  // Targets sharing a position are drawn as one multi-ring target, like the original.
  const groups = new Map();
  state.targets.forEach((t,i) => {
    const key = `${t.x},${t.y}`;
    if (!groups.has(key)) groups.set(key, { x:t.x, y:t.y, rings:[] });
    groups.get(key).rings.push({ color:t.color, power:t.power, index:i });
  });
  for (const g of groups.values()) {
    const X = g.x, Y = sy(g.y);
    ctx.fillStyle = 'rgba(0,0,0,.75)';
    ctx.beginPath(); ctx.arc(X,Y,32,0,Math.PI*2); ctx.fill();
    g.rings.forEach((r,k) => {
      const c = CORE[r.color] || CORE[0];
      const rad = 32 - k*7;
      ctx.strokeStyle = 'rgba(60,80,105,.5)'; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(X,Y,rad,0,Math.PI*2); ctx.stroke();
      const frac = r.power/1024;
      if (frac > 0) {
        ctx.strokeStyle = rgba(c, 0.55 + 0.45*frac);
        ctx.lineWidth = 5;
        ctx.shadowBlur = frac > 0.99 ? 16 : 6;
        ctx.shadowColor = rgba(c,0.9);
        ctx.beginPath();
        ctx.arc(X,Y,rad,-Math.PI/2, -Math.PI/2 + Math.PI*2*frac);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      ctx.strokeStyle = rgba(c,0.9); ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(X,Y,rad-4,0,Math.PI*2); ctx.stroke();
    });
    ctx.fillStyle = 'rgba(255,255,255,.8)';
    ctx.beginPath(); ctx.arc(X,Y,3,0,Math.PI*2); ctx.fill();
  }
}

function drawWinIndicator() {
  if (!state || state.winTimer <= 0) return;
  const y = 44, w = 160, x = (W-w)/2;
  ctx.fillStyle = 'rgba(0,0,0,.6)';
  ctx.fillRect(x-2,y-2,w+4,8);
  ctx.fillStyle = '#ffe27a';
  ctx.fillRect(x,y,w*Math.min(1,state.winTimer/3),4);
}

function render() {
  if (!state) return;
  drawBackground();
  drawBeams();
  drawPrisms();
  drawTargets();
  drawDiscs();
  drawWinIndicator();
}

/* ------------------------------------------------------------------ loop */
function frame(now) {
  if (!lastTime) lastTime = now;
  const dt = Math.min(0.25, (now-lastTime)/1000);
  lastTime = now;
  accumulator += dt;
  while (accumulator >= 0.02) { step(); accumulator -= 0.02; }
  render();
  requestAnimationFrame(frame);
}

/* ------------------------------------------------------------------ input */
function pointFromEvent(e) {
  const r = canvas.getBoundingClientRect();
  return {
    x: (e.clientX - r.left) / r.width * W,
    y: H - (e.clientY - r.top) / r.height * H
  };
}
function pickDisc(p) {
  let best = -1, bestDist = 26*26;
  state.discs.forEach((d,i) => {
    const dd = (d.x-p.x)**2 + (d.y-p.y)**2;
    if (dd < bestDist) { bestDist = dd; best = i; }
  });
  return best;
}
function resizeActive(delta) {
  if (!state) return;
  const i = activeDisc >= 0 ? activeDisc : 0;
  if (!state.discs[i]) return;
  state.discs[i].radius = clamp(state.discs[i].radius + delta, 16, 200);
  el.radius.textContent = Math.round(state.discs[i].radius);
}
canvas.addEventListener('pointerdown', e => {
  if (!state || !el.menu.classList.contains('hidden') || state.completed) return;
  ensureAudio();
  if (audio && audio.state === 'suspended') audio.resume();
  const p = pointFromEvent(e);
  activeDisc = pickDisc(p);
  if (activeDisc >= 0) {
    dragOffset.x = state.discs[activeDisc].x - p.x;
    dragOffset.y = state.discs[activeDisc].y - p.y;
    canvas.setPointerCapture(e.pointerId);
    el.radius.textContent = Math.round(state.discs[activeDisc].radius);
  }
});
canvas.addEventListener('pointermove', e => {
  if (activeDisc < 0 || !state || state.completed) return;
  const p = pointFromEvent(e);
  state.discs[activeDisc].x = clamp(p.x + dragOffset.x, 0, W);
  state.discs[activeDisc].y = clamp(p.y + dragOffset.y, 0, H);
});
const endDrag = () => { activeDisc = -1; };
canvas.addEventListener('pointerup', endDrag);
canvas.addEventListener('pointercancel', endDrag);
canvas.addEventListener('wheel', e => {
  if (!state) return;
  e.preventDefault();
  const p = pointFromEvent(e);
  const i = pickDisc(p);
  if (i >= 0) activeDisc = i;
  resizeActive(e.deltaY < 0 ? 6 : -6);
}, { passive:false });

el.btnSmaller.onclick = () => resizeActive(-8);
el.btnBigger.onclick = () => resizeActive(8);
el.btnReset.onclick = () => state && loadLevel(state.index);
el.btnMenu.onclick = showMenu;
el.btnCloseMenu.onclick = hideMenu;
el.btnNext.onclick = () => {
  if (!state) return;
  const next = state.index + 1;
  if (next < LEVELS.length) loadLevel(next);
  else { hideMenu(); showMenu(); }
};
el.btnSound.onclick = () => {
  soundOn = !soundOn;
  el.btnSound.classList.toggle('off', !soundOn);
  el.btnSound.textContent = soundOn ? '♪' : '✕';
  if (soundOn) { ensureAudio(); if (audio && audio.state === 'suspended') audio.resume(); }
  else if (audio) targetVoices.forEach(v => v.gain.gain.setTargetAtTime(0, audio.currentTime, 0.05));
};
window.addEventListener('keydown', e => {
  if (e.key === 'Escape') el.menu.classList.contains('hidden') ? showMenu() : hideMenu();
  if (e.key.toLowerCase() === 'r' && state) loadLevel(state.index);
  if (e.key === '+' || e.key === '=') resizeActive(8);
  if (e.key === '-') resizeActive(-8);
});

/* Small debug hook (useful for automated checks and tinkering) */
window.__LJ = { get state() { return state; }, loadLevel, step, get beaten() { return beaten; } };

/* ------------------------------------------------------------------ boot */
if (!LEVELS.length) {
  document.getElementById('hint').textContent = 'levels.js missing — run tools/parse-levels.ps1';
} else {
  loadLevel(0);
  showMenu();
  requestAnimationFrame(frame);
}
})();
