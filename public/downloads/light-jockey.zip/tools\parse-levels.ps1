# Parses the original Objective-C level table (Light-Jockey-master/Classes/LJLevelData.m)
# into a plain JavaScript array that can be loaded by the browser port.

$srcPath = Join-Path $PSScriptRoot '..\..\Light-Jockey-master\Classes\LJLevelData.m'
$outPath = Join-Path $PSScriptRoot '..\levels.js'
$src = Get-Content -Path $srcPath -Raw

$reLevel  = [regex]'(?s)\{\s*/\*\s*level\s+[\d.]+\s*\*/(.*?)(?=\{\s*/\*\s*(?:level|group)\s|$)'
$reGroup  = [regex]'(?s)\{\s*/\*\s*group\s+\d+\s*\*/\s*(\d+),\s*/\*\s*Number of levels\s*\*/\s*@"([^"]+)"'
$reString = [regex]'@"([^"]+)"'
$rePoint  = [regex]'\{\s*(-?\s*\d+)\s*,\s*(-?\s*\d+)\s*\}'
$reNote   = [regex]'([\d.]+)\s*,\s*/\*\s*(Beam home|Home jitter|Velocity jitter|Beam charge|Friction|Number of discs|Number of targets|Number of prisms)\s*\*/'
$reColor  = [regex]'BEAM_COLOR_(\w+)'
$reDisc   = [regex]'(?s)\{\s*\{\s*(-?\s*\d+)\s*,\s*(-?\s*\d+)\s*\}\s*,?\s*LJDISCTYPE_(\w+)\s*,?\s*DIR_(\w+)'
$reTarget = [regex]'(?s)\{\s*\{\s*(-?\s*\d+)\s*,\s*(-?\s*\d+)\s*\}\s*,?\s*BEAM_COLOR_(\w+)\s*,?\s*(kMusicTrack\w+)'
$rePrism  = [regex]'(?s)\{\s*\{\s*(-?\s*\d+)\s*,\s*(-?\s*\d+)\s*\}\s*,?\s*BEAM_COLOR_(\w+)\s*,?\s*(\d+)\s*,?\s*\}'

function N([string]$s) { [int]($s -replace '\s','') }

$groups = @()
foreach ($g in $reGroup.Matches($src)) {
    $groups += [pscustomobject]@{ Index = $g.Index; Count = [int]$g.Groups[1].Value; Name = $g.Groups[2].Value }
}

$levels = New-Object System.Collections.ArrayList
foreach ($m in $reLevel.Matches($src)) {
    $block = $m.Groups[1].Value
    $group = $groups | Where-Object { $_.Index -lt $m.Index } | Select-Object -Last 1
    if (-not $group) { continue }

    $strings = @($reString.Matches($block) | ForEach-Object { $_.Groups[1].Value })
    if ($strings.Count -lt 2) { continue }

    $homeX = 0; $homeY = 0; $vx = 0; $vy = 0
    $jitter = 0; $velJitter = 0; $charge = 0; $friction = 1.0
    foreach ($n in $reNote.Matches($block)) {
        $val = $n.Groups[1].Value
        switch ($n.Groups[2].Value) {
            'Home jitter'       { $jitter = [int]$val }
            'Velocity jitter'   { $velJitter = [int]$val }
            'Beam charge'       { $charge = [int]$val }
            'Friction'          { $friction = [double]::Parse($val, [Globalization.CultureInfo]::InvariantCulture) }
        }
    }

    $points = @($rePoint.Matches($block))
    if ($points.Count -ge 1) { $homeX = N $points[0].Groups[1].Value; $homeY = N $points[0].Groups[2].Value }
    if ($points.Count -ge 2) { $vx = N $points[1].Groups[1].Value; $vy = N $points[1].Groups[2].Value }

    $cm = $reColor.Match($block)

    $discs = @()
    foreach ($d in $reDisc.Matches($block)) {
        $discs += [ordered]@{ x=(N $d.Groups[1].Value); y=(N $d.Groups[2].Value); type=$d.Groups[3].Value; dir=$d.Groups[4].Value }
    }
    $targets = @()
    foreach ($t in $reTarget.Matches($block)) {
        $targets += [ordered]@{ x=(N $t.Groups[1].Value); y=(N $t.Groups[2].Value); color=$t.Groups[3].Value; track=$t.Groups[4].Value }
    }
    $prisms = @()
    foreach ($p in $rePrism.Matches($block)) {
        $prisms += [ordered]@{ x=(N $p.Groups[1].Value); y=(N $p.Groups[2].Value); color=$p.Groups[3].Value; radius=[int]$p.Groups[4].Value }
    }

    [void]$levels.Add([ordered]@{
        group = $group.Name
        name = $strings[0]
        tag = $strings[1]
        startColor = if ($cm.Success) { $cm.Groups[1].Value } else { 'WHITE' }
        homeX = $homeX; homeY = $homeY
        homeJitter = $jitter
        vx = $vx; vy = $vy
        velJitter = $velJitter
        charge = $charge
        friction = $friction
        discs = @($discs)
        targets = @($targets)
        prisms = @($prisms)
    })
}

$json = $levels | ConvertTo-Json -Depth 8 -Compress
Set-Content -Path $outPath -Value ('window.LJ_LEVELS = ' + $json + ';') -Encoding UTF8
Write-Host "Parsed $($levels.Count) levels into $outPath"
$levels | Group-Object { $_.group } | ForEach-Object { Write-Host "  $($_.Name): $($_.Count)" }
$levels | ForEach-Object { Write-Host "  - $($_.group)/$($_.name): d=$($_.discs.Count) t=$($_.targets.Count) p=$($_.prisms.Count)" }
