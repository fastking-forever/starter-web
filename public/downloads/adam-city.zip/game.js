try {
// Uses global THREE from three.min.js (file:// friendly)
const THREE = window.THREE;

const STORAGE_KEY = 'adam_city_ops_v1';
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);
const choice = (arr) => arr[Math.floor(Math.random() * arr.length)];

const WEAPONS = [
  { id: 'pistol', name: 'مسدس', price: 0, damage: 18, fireRate: 320, range: 70, auto: false, ammo: Infinity, color: 0xfcd34d },
  { id: 'smg', name: 'SMG', price: 450, damage: 12, fireRate: 110, range: 65, auto: true, ammo: 120, color: 0x60a5fa },
  { id: 'rifle', name: 'بندقية', price: 900, damage: 28, fireRate: 180, range: 110, auto: true, ammo: 90, color: 0xf97316 },
];
const SHOP_ITEMS = [
  { id: 'smg', kind: 'weapon', name: 'SMG', desc: 'سلاح سريع مناسب للاشتباكات القريبة.', price: 450 },
  { id: 'rifle', kind: 'weapon', name: 'بندقية تكتيكية', desc: 'ضرر أعلى ومدى أطول لمهام العصابات.', price: 900 },
  { id: 'armor', kind: 'armor', name: 'درع خفيف', desc: 'يزيد الحماية حتى 100.', price: 200 },
  { id: 'ammo', kind: 'ammo', name: 'ذخيرة إضافية', desc: 'يعيد تعبئة ذخيرة الأسلحة التي تملكها.', price: 120 },
  { id: 'house', kind: 'house', name: 'ترقية المخبأ', desc: 'يحسن الاستشفاء ويزيد مكافأة حفظ الأمان.', price: 700 },
];

const DEFAULT_SAVE = () => ({
  money: 150, health: 100, armor: 0,
  ownedWeapons: ['pistol'], equipped: 'pistol',
  ammo: { pistol: Infinity, smg: 90, rifle: 60 },
  houseLevel: 1, missionIndex: 0,
  stats: { earned: 0, kills: 0, missions: 0 },
  position: { x: 0, z: 18 },
});

let save = loadSave();
function loadSave() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SAVE();
    const p = JSON.parse(raw);
    return { ...DEFAULT_SAVE(), ...p, ammo: { ...DEFAULT_SAVE().ammo, ...(p.ammo || {}) }, stats: { ...DEFAULT_SAVE().stats, ...(p.stats || {}) }, position: { ...DEFAULT_SAVE().position, ...(p.position || {}) } };
  } catch { return DEFAULT_SAVE(); }
}
function persist(showToastMsg = false) {
  save.position = { x: player.position.x, z: player.position.z };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
  if (showToastMsg) toast('تم حفظ التقدم');
}

const ui = {
  menu: document.getElementById('menu'), hud: document.getElementById('hud'), menuStats: document.getElementById('menuStats'),
  startBtn: document.getElementById('startBtn'), resetBtn: document.getElementById('resetBtn'), respawnBtn: document.getElementById('respawnBtn'),
  healthBar: document.getElementById('healthBar'), armorBar: document.getElementById('armorBar'), healthText: document.getElementById('healthText'), armorText: document.getElementById('armorText'),
  moneyText: document.getElementById('moneyText'), weaponText: document.getElementById('weaponText'), ammoText: document.getElementById('ammoText'),
  missionTitle: document.getElementById('missionTitle'), missionDesc: document.getElementById('missionDesc'), missionProgress: document.getElementById('missionProgress'),
  toast: document.getElementById('toast'), hitMarker: document.getElementById('hitMarker'), damageOverlay: document.getElementById('damageOverlay'),
  shopModal: document.getElementById('shopModal'), houseModal: document.getElementById('houseModal'), gameOver: document.getElementById('gameOver'), shopItems: document.getElementById('shopItems'), shopMoney: document.getElementById('shopMoney'), houseInfo: document.getElementById('houseInfo'),
  healBtn: document.getElementById('healBtn'), saveBtn: document.getElementById('saveBtn'), minimap: document.getElementById('minimap'),
  moveZone: document.getElementById('moveZone'), moveKnob: document.getElementById('moveKnob'), lookPad: document.getElementById('lookPad'),
  shootBtn: document.getElementById('shootBtn'), reloadBtn: document.getElementById('reloadBtn'), interactBtn: document.getElementById('interactBtn'), weaponBtn: document.getElementById('weaponBtn'),
};
const mmCtx = ui.minimap.getContext('2d');

const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('game'), antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);
scene.fog = new THREE.Fog(0x87ceeb, 90, 320);
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 500);
const clock = new THREE.Clock();
scene.add(new THREE.HemisphereLight(0xdbeafe, 0x3f6212, 1.15));
const dir = new THREE.DirectionalLight(0xfff1c1, 1.35);
dir.position.set(80, 120, 40); dir.castShadow = true;
dir.shadow.mapSize.set(2048, 2048);
dir.shadow.camera.left = -140; dir.shadow.camera.right = 140; dir.shadow.camera.top = 140; dir.shadow.camera.bottom = -140; dir.shadow.camera.far = 350;
scene.add(dir);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), new THREE.MeshStandardMaterial({ color: 0x4b5563, roughness: 1 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
const grass = new THREE.Mesh(new THREE.PlaneGeometry(700, 700), new THREE.MeshStandardMaterial({ color: 0x365314, roughness: 1 }));
grass.rotation.x = -Math.PI / 2; grass.position.y = -0.02; grass.receiveShadow = true; scene.add(grass);

const city = { colliders: [], buildings: [], interactables: [], bounds: 180 };
const raycaster = new THREE.Raycaster();
const tmpVec = new THREE.Vector3();
const player = { position: new THREE.Vector3(save.position.x, 0, save.position.z), velocity: new THREE.Vector3(), yaw: 0, pitch: 0.18, radius: 0.8, speed: 12, sprint: 1, health: save.health, armor: save.armor, dead: false, lastShot: 0, invuln: 0 };
const input = { keys: {}, moveX: 0, moveY: 0, lookDX: 0, lookDY: 0, shooting: false, touchLookId: null, lastLook: null };
let gameStarted = false, paused = false, pauseWanted = false;
let enemies = [], bullets = [], particles = [], pickups = [], mission = null;
let toastTimer = 0;


function toast(msg, ms = 2200) {
  ui.toast.textContent = msg;
  ui.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ui.toast.classList.remove('show'), ms);
}
function addCollider(x, z, w, d) { city.colliders.push({ x, z, w, d }); }
function boxIntersects(px, pz, r, c) {
  const dx = Math.abs(px - c.x) - (c.w / 2 + r);
  const dz = Math.abs(pz - c.z) - (c.d / 2 + r);
  return dx < 0 && dz < 0;
}
function collides(px, pz, r = player.radius) {
  for (const c of city.colliders) if (boxIntersects(px, pz, r, c)) return true;
  return Math.abs(px) > city.bounds - r || Math.abs(pz) > city.bounds - r;
}
function makeBuilding(x, z, w, h, d, color, opts = {}) {
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.85, metalness: 0.05 });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  mesh.position.set(x, h / 2, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  scene.add(mesh);
  city.buildings.push(mesh);
  if (!opts.noCollider) addCollider(x, z, w, d);
  if (opts.rim) {
    const rim = new THREE.Mesh(new THREE.BoxGeometry(w + 0.2, 0.4, d + 0.2), new THREE.MeshStandardMaterial({ color: opts.rim, emissive: opts.rim, emissiveIntensity: 0.25 }));
    rim.position.set(x, h + 0.2, z);
    scene.add(rim);
  }
  return mesh;
}
function makeRoad(x, z, w, d) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 1 }));
  m.rotation.x = -Math.PI / 2; m.position.set(x, 0.01, z); m.receiveShadow = true; scene.add(m);
}
function makeMarker(color, x, z, label) {
  const ring = new THREE.Mesh(new THREE.RingGeometry(2.2, 3.2, 32), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
  ring.rotation.x = -Math.PI / 2; ring.position.set(x, 0.05, z); scene.add(ring);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 8, 12), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.18 }));
  beam.position.set(x, 4, z); scene.add(beam);
  return { ring, beam, x, z, label };
}
function buildCity() {
  for (let i = -3; i <= 3; i++) { makeRoad(i * 45, 0, 16, 380); makeRoad(0, i * 45, 380, 16); }
  const palette = [0x334155, 0x475569, 0x64748b, 0x374151, 0x1f2937, 0x4b5563];
  for (let gx = -3; gx <= 3; gx++) {
    for (let gz = -3; gz <= 3; gz++) {
      const cx = gx * 45, cz = gz * 45;
      if (Math.abs(gx) <= 0 && Math.abs(gz) <= 0) continue;
      const seed = Math.abs(gx * 7 + gz * 13);
      const bCount = 2 + (seed % 2);
      for (let i = 0; i < bCount; i++) {
        const w = 10 + (seed + i * 3) % 10;
        const d = 10 + (seed + i * 5) % 12;
        const h = 8 + ((seed + i * 11) % 8) * 3;
        const ox = (i === 0 ? -8 : 8) + ((seed % 5) - 2);
        const oz = (i === 0 ? -8 : 8) + (((seed + 2) % 5) - 2);
        const color = palette[(seed + i) % palette.length];
        makeBuilding(cx + ox, cz + oz, w, h, d, color, { rim: [0x38bdf8,0xf59e0b,0xa78bfa][(seed+i)%3] });
      }
    }
  }
  const plaza = new THREE.Mesh(new THREE.CircleGeometry(18, 48), new THREE.MeshStandardMaterial({ color: 0x6b7280, roughness: 0.95 }));
  plaza.rotation.x = -Math.PI / 2; plaza.position.y = 0.015; plaza.receiveShadow = true; scene.add(plaza);
  makeBuilding(-95, 70, 18, 8, 16, 0x14532d, { rim: 0x22c55e });
  const houseDoor = new THREE.Mesh(new THREE.BoxGeometry(3, 4, 0.5), new THREE.MeshStandardMaterial({ color: 0x86efac, emissive: 0x22c55e, emissiveIntensity: 0.4 }));
  houseDoor.position.set(-95, 2, 62.2); scene.add(houseDoor);
  city.interactables.push({ type: 'house', x: -95, z: 60, r: 5, label: 'المخبأ الآمن' });
  makeBuilding(95, -70, 18, 8, 16, 0x1e3a8a, { rim: 0x60a5fa });
  const shopDoor = new THREE.Mesh(new THREE.BoxGeometry(3, 4, 0.5), new THREE.MeshStandardMaterial({ color: 0xbfdbfe, emissive: 0x60a5fa, emissiveIntensity: 0.4 }));
  shopDoor.position.set(95, 2, -62.2); scene.add(shopDoor);
  city.interactables.push({ type: 'shop', x: 95, z: -60, r: 5, label: 'متجر الأسلحة' });
  city.interactables.forEach(it => { it.marker = makeMarker(it.type === 'shop' ? 0x60a5fa : 0x22c55e, it.x, it.z, it.label); });
  for (let i = 0; i < 60; i++) {
    const x = (Math.random()*300)-150, z = (Math.random()*300)-150;
    if (Math.abs(x) < 25 && Math.abs(z) < 25) continue;
    if (collides(x, z, 2.5)) continue;
    const crate = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.8, 1.8), new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.9 }));
    crate.position.set(x, 0.9, z); crate.castShadow = true; crate.receiveShadow = true; scene.add(crate);
    addCollider(x, z, 1.8, 1.8);
  }
  for (let i = -3; i <= 3; i++) for (let j = -3; j <= 3; j++) {
    if ((i + j) % 2 !== 0) continue;
    const x = i * 45 + 10, z = j * 45 + 10;
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.18, 7, 8), new THREE.MeshStandardMaterial({ color: 0x9ca3af }));
    pole.position.set(x, 3.5, z); scene.add(pole);
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.45, 10, 10), new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfef08a, emissiveIntensity: 1.2 }));
    lamp.position.set(x, 7.1, z); scene.add(lamp);
  }
}
function createPlayerMesh() {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.55, 1.2, 4, 8), new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.7 }));
  body.position.y = 1.5; body.castShadow = true; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.38, 16, 16), new THREE.MeshStandardMaterial({ color: 0xf1c27d }));
  head.position.y = 2.45; head.castShadow = true; g.add(head);
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 0.8), new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.4, roughness: 0.4 }));
  gun.position.set(0.35, 1.55, -0.5); g.add(gun);
  g.userData.gun = gun;
  scene.add(g);
  return g;
}
function makeEnemy(x, z) {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.55, 1.2, 4, 8), new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.75 }));
  body.position.y = 1.5; body.castShadow = true; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.36, 14, 14), new THREE.MeshStandardMaterial({ color: 0xe0ac69 }));
  head.position.y = 2.42; head.castShadow = true; g.add(head);
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.15, 0.2), new THREE.MeshStandardMaterial({ color: 0x111827 }));
  visor.position.set(0, 2.45, -0.28); g.add(visor);
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.7), new THREE.MeshStandardMaterial({ color: 0x111827 }));
  gun.position.set(0.32, 1.55, -0.45); g.add(gun);
  g.position.set(x, 0, z);
  scene.add(g);
  return { mesh: g, hp: 55, maxHp: 55, speed: 3.2 + Math.random()*1.6, fireCd: 0.6 + Math.random()*0.8, alive: true, radius: 0.8, aggro: 0 };
}
function spawnMission(index) {
  enemies.forEach(e => scene.remove(e.mesh));
  enemies = []; bullets.forEach(b=>scene.remove(b.mesh)); bullets = []; particles.forEach(p=>scene.remove(p.mesh)); particles = []; pickups.forEach(p=>scene.remove(p.mesh)); pickups = [];
  const defs = [
    { title: 'تطهير نقطة العصابة', desc: 'اقضِ على 3 من عناصر العصابة المسلحة في الساحة الشمالية.', center: {x:0,z:-75}, count:3, reward: 200 },
    { title: 'حماية طريق الإمداد', desc: 'صفِّ 4 مسلحين يحاولون السيطرة على التقاطع الشرقي.', center: {x:80,z:0}, count:4, reward: 320 },
    { title: 'اقتحام وكر السلاح', desc: 'اقتحم المنطقة الجنوبية وأزل 5 من حراس العصابة.', center: {x:0,z:80}, count:5, reward: 450 },
    { title: 'عملية المدينة', desc: 'واجه 6 مسلحين في منطقة صناعية غرب المدينة.', center: {x:-85,z:-10}, count:6, reward: 650 },
  ];
  const def = defs[index % defs.length];
  mission = { ...def, index, killed: 0, done: false };
  for (let i = 0; i < def.count; i++) {
    const a = (i / def.count) * Math.PI * 2;
    const r = 8 + Math.random() * 10;
    const x = Math.max(-175, Math.min(175, def.center.x + Math.cos(a) * r));
    const z = Math.max(-175, Math.min(175, def.center.z + Math.sin(a) * r));
    enemies.push(makeEnemy(x, z));
  }
  toast('مهمة جديدة: ' + def.title);
  updateMissionUI();
}
function updateMissionUI() {
  if (!mission) return;
  ui.missionTitle.textContent = mission.title;
  ui.missionDesc.textContent = mission.desc + ' (أعداء مسلحون فقط)';
  ui.missionProgress.textContent = mission.done ? 'مكتملة! +$' + mission.reward : 'التقدم: ' + mission.killed + '/' + mission.count + ' | المكافأة: $' + mission.reward;
}
function currentWeapon() { return WEAPONS.find(w => w.id === save.equipped) || WEAPONS[0]; }
function equipWeapon(id) {
  if (!save.ownedWeapons.includes(id)) return;
  save.equipped = id;
  updateHUD();
  persist();
}
function addMoney(amount) {
  save.money += amount;
  if (amount > 0) save.stats.earned += amount;
  updateHUD();
}
function updateHUD() {
  ui.healthBar.style.width = Math.max(0,Math.min(100,player.health)) + '%';
  ui.armorBar.style.width = Math.max(0,Math.min(100,player.armor)) + '%';
  ui.healthText.textContent = Math.max(0, Math.ceil(player.health));
  ui.armorText.textContent = Math.max(0, Math.ceil(player.armor));
  ui.moneyText.textContent = '$' + save.money;
  const w = currentWeapon();
  ui.weaponText.textContent = w.name;
  const ammo = save.ammo[w.id];
  ui.ammoText.textContent = ammo === Infinity ? '∞' : '' + ammo;
}

function togglePause(force) {
  if (!gameStarted || player.dead) return;
  if (!ui.shopModal.classList.contains('hidden') || !ui.houseModal.classList.contains('hidden')) return;
  pauseWanted = typeof force === 'boolean' ? force : !pauseWanted;
  ui.pauseOverlay.classList.toggle('hidden', !pauseWanted);
  if (!pauseWanted) clock.getDelta();
}
function showMenu() {
  ui.menu.classList.remove('hidden');
  ui.hud.classList.add('hidden');
  ui.menuStats.innerHTML = '<div class="menu-stat"><div class="label">الفلوس</div><div class="value">$' + save.money + '</div></div>' +
    '<div class="menu-stat"><div class="label">المهمات</div><div class="value">' + save.stats.missions + '</div></div>' +
    '<div class="menu-stat"><div class="label">المخبأ</div><div class="value">Lv ' + save.houseLevel + '</div></div>';
}
function startGame() {
  ui.menu.classList.add('hidden');
  ui.hud.classList.remove('hidden');
  gameStarted = true;
  player.health = save.health; player.armor = save.armor; player.dead = false;
  if (!mission) spawnMission(save.missionIndex);
  updateHUD(); updateMissionUI();
  toast('مرحبًا بك في ADAM: City Ops');
}
function resetSave() {
  if (!confirm('مسح التقدم بالكامل؟')) return;
  localStorage.removeItem(STORAGE_KEY);
  save = DEFAULT_SAVE();
  player.position.set(save.position.x, 0, save.position.z);
  player.health = 100; player.armor = 0; player.dead = false;
  spawnMission(0);
  updateHUD(); updateMissionUI(); renderShop(); renderHouse(); showMenu();
}
function openModal(id) { document.getElementById(id).classList.remove('hidden'); if (id === 'shopModal') renderShop(); if (id === 'houseModal') renderHouse(); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => closeModal(btn.dataset.close)));
function renderShop() {
  ui.shopMoney.textContent = 'رصيدك: $' + save.money;
  ui.shopItems.innerHTML = '';
  for (const item of SHOP_ITEMS) {
    const owned = item.kind === 'weapon' && save.ownedWeapons.includes(item.id);
    const el = document.createElement('div');
    el.className = 'shop-item' + (owned ? ' owned' : '');
    el.innerHTML = '<h3>' + item.name + '</h3><p>' + item.desc + '</p><div class="shop-price">' + (owned ? 'مملوك' : '$'+item.price) + '</div>';
    const btn = document.createElement('button');
    btn.className = owned ? 'secondary-btn' : 'primary-btn';
    btn.textContent = owned ? 'مجهز' : 'شراء';
    btn.disabled = owned || save.money < item.price;
    btn.onclick = () => buyItem(item);
    el.appendChild(btn);
    ui.shopItems.appendChild(el);
  }
}
function buyItem(item) {
  if (save.money < item.price) { toast('رصيدك غير كافٍ'); return; }
  if (item.kind === 'weapon') {
    if (save.ownedWeapons.includes(item.id)) return;
    save.money -= item.price; save.ownedWeapons.push(item.id);
    const def = WEAPONS.find(w=>w.id===item.id);
    save.ammo[item.id] = def.ammo === Infinity ? Infinity : Math.max(save.ammo[item.id]||0, def.ammo);
    equipWeapon(item.id); toast('تم شراء ' + item.name);
  } else if (item.kind === 'armor') {
    save.money -= item.price; player.armor = 100; save.armor = 100; toast('تم شراء الدرع');
  } else if (item.kind === 'ammo') {
    save.money -= item.price;
    for (const wid of save.ownedWeapons) { if (wid !== 'pistol') save.ammo[wid] = (save.ammo[wid] || 0) + (wid === 'rifle' ? 45 : 60); }
    toast('تمت تعبئة الذخيرة');
  } else if (item.kind === 'house') {
    save.money -= item.price; save.houseLevel += 1; toast('تمت ترقية المخبأ');
  }
  persist(); updateHUD(); renderShop(); renderHouse();
}
function renderHouse() {
  ui.houseInfo.innerHTML = '<div class="house-row"><span>مستوى المخبأ</span><strong>Lv ' + save.houseLevel + '</strong></div>' +
    '<div class="house-row"><span>استشفاء متاح</span><strong>' + (50 + (save.houseLevel-1)*10) + ' صحة</strong></div>' +
    '<div class="house-row"><span>الأسلحة المملوكة</span><strong>' + save.ownedWeapons.map(id=>WEAPONS.find(w=>w.id===id).name).join('، ') + '</strong></div>' +
    '<div class="house-row"><span>الموقع</span><strong>الحي الأخضر</strong></div>';
}

function nearestInteractable() {
  let best = null, bestD = 999;
  for (const it of city.interactables) {
    const d = Math.hypot(player.position.x - it.x, player.position.z - it.z);
    if (d < it.r + 1.2 && d < bestD) { best = it; bestD = d; }
  }
  return best;
}
function tryInteract() {
  const it = nearestInteractable();
  if (!it) { toast('لا يوجد شيء للتفاعل معه هنا'); return; }
  if (it.type === 'shop') openModal('shopModal');
  if (it.type === 'house') openModal('houseModal');
}

function spawnBullet(from, dir, owner, damage, range, color=0xfff2a8) {
  bullets.push({ from: from.clone(), dir: dir.clone().normalize(), owner, damage, range, traveled: 0, speed: owner==='player'? 90 : 55, color });
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshBasicMaterial({ color }));
  m.position.copy(from);
  scene.add(m);
  bullets[bullets.length-1].mesh = m;
}

function muzzleFlash(pos, color) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), new THREE.MeshBasicMaterial({ color, transparent:true, opacity:0.9 }));
  m.position.copy(pos); scene.add(m);
  particles.push({ mesh:m, life:0.06, max:0.06, vel:new THREE.Vector3() });
}

function impact(pos, color=0xf59e0b) {
  for (let i=0;i<6;i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.08,0.08,0.08), new THREE.MeshBasicMaterial({ color }));
    m.position.copy(pos); scene.add(m);
    particles.push({ mesh:m, life: rand(0.2,0.5), max:0.5, vel:new THREE.Vector3(rand(-2,2),rand(1,4),rand(-2,2)) });
  }
}

function shoot() {
  if (!gameStarted || player.dead) return;
  if (!ui.shopModal.classList.contains('hidden') || !ui.houseModal.classList.contains('hidden')) return;
  const w = currentWeapon();
  const now = performance.now();
  if (now - player.lastShot < w.fireRate) return;
  const ammo = save.ammo[w.id];
  if (ammo !== Infinity && ammo <= 0) { toast('لا توجد ذخيرة'); return; }
  player.lastShot = now;
  if (ammo !== Infinity) save.ammo[w.id] = ammo - 1;
  const dir = new THREE.Vector3(0,0,-1).applyAxisAngle(new THREE.Vector3(0,1,0), player.yaw).applyAxisAngle(new THREE.Vector3(1,0,0), player.pitch);
  dir.x += rand(-0.01,0.01); dir.y += rand(-0.01,0.01); dir.z += rand(-0.01,0.01);
  const from = player.position.clone().add(new THREE.Vector3(0,1.6,0)).add(dir.clone().multiplyScalar(0.8));
  spawnBullet(from, dir, 'player', w.damage, w.range, w.color);
  muzzleFlash(from, w.color);
  updateHUD();
}

function damagePlayer(amount) {
  if (player.dead || player.invuln > 0) return;
  let a = amount;
  if (player.armor > 0) { const absorbed = Math.min(player.armor, a * 0.6); player.armor -= absorbed; a -= absorbed; }
  player.health -= a;
  save.health = Math.max(0, player.health); save.armor = Math.max(0, player.armor);
  ui.damageOverlay.classList.add('show'); setTimeout(()=>ui.damageOverlay.classList.remove('show'), 120);
  if (player.health <= 0) die();
  updateHUD();
}

function die() {
  player.dead = true;
  save.money = Math.max(0, Math.floor(save.money * 0.95));
  save.health = 100; save.armor = Math.max(0, Math.floor(player.armor));
  persist();
  ui.gameOver.classList.remove('hidden');
}

function respawn() {
  ui.gameOver.classList.add('hidden');
  player.dead = false; player.health = 100; player.armor = save.armor;
  save.health = 100; player.invuln = 2;
  player.position.set(-95, 0, 55);
  player.yaw = 0; player.pitch = 0.15;
  persist(); updateHUD();
  toast('عدت إلى المخبأ الآمن');
}

function updateEnemies(dt) {
  for (const e of enemies) {
    if (!e.alive) continue;
    const toP = tmpVec.subVectors(player.position, e.mesh.position);
    toP.y = 0;
    const dist = toP.length();
    if (dist < 40) e.aggro = 1;
    if (e.aggro <= 0) continue;
    const dir = toP.clone().normalize();
    e.mesh.lookAt(player.position.x, 0, player.position.z);
    const desired = dist > 10 ? 1 : (dist < 6 ? -0.7 : 0);
    const step = dir.multiplyScalar(desired * e.speed * dt);
    const nx = e.mesh.position.x + step.x;
    const nz = e.mesh.position.z + step.z;
    if (!collides(nx, e.mesh.position.z, e.radius)) e.mesh.position.x = nx;
    if (!collides(e.mesh.position.x, nz, e.radius)) e.mesh.position.z = nz;

    e.fireCd -= dt;
    if (e.fireCd <= 0 && dist < 35 && !player.dead) {
      e.fireCd = rand(0.8, 1.6);
      const aim = new THREE.Vector3(player.position.x - e.mesh.position.x, 1.4, player.position.z - e.mesh.position.z).normalize();
      aim.x += rand(-0.03,0.03); aim.y += rand(-0.01,0.01); aim.z += rand(-0.03,0.03);
      const from = e.mesh.position.clone().add(new THREE.Vector3(0,1.5,0)).add(aim.clone().multiplyScalar(0.8));
      spawnBullet(from, aim, 'enemy', 8, 45, 0xff7777);
      muzzleFlash(from, 0xff6666);
    }
  }
}

function updateBullets(dt) {
  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    const step = b.speed * dt;
    b.mesh.position.addScaledVector(b.dir, step);
    b.traveled += step;
    let hit = false;
    if (b.traveled > b.range) hit = true;

    // building collision
    if (!hit) {
      for (const c of city.colliders) {
        if (Math.abs(b.mesh.position.x - c.x) < c.w/2 + 0.1 && Math.abs(b.mesh.position.z - c.z) < c.d/2 + 0.1 && b.mesh.position.y < 12) { hit = true; impact(b.mesh.position, 0x94a3b8); break; }
      }
    }

    if (!hit && b.owner === 'player') {
      for (const e of enemies) {
        if (!e.alive) continue;
        const dx = b.mesh.position.x - e.mesh.position.x;
        const dz = b.mesh.position.z - e.mesh.position.z;
        const dy = b.mesh.position.y - 1.5;
        if (dx*dx + dz*dz < 0.9*0.9 && Math.abs(dy) < 1.6) {
          e.hp -= b.damage; hit = true; impact(b.mesh.position, 0xffcc00);
          ui.hitMarker.classList.add('show'); setTimeout(()=>ui.hitMarker.classList.remove('show'), 70);
          if (e.hp <= 0) {
            e.alive = false; scene.remove(e.mesh);
            save.stats.kills += 1; addMoney(35);
            mission.killed += 1;
            toast('+35$ — تم إسقاط هدف مسلح');
            if (Math.random() < 0.35) spawnPickup(e.mesh.position.x, e.mesh.position.z);
            if (mission.killed >= mission.count && !mission.done) {
              mission.done = true; addMoney(mission.reward); save.stats.missions += 1; save.missionIndex += 1;
              toast(`اكتملت المهمة! +$${mission.reward}`);
              persist();
              setTimeout(() => { if (gameStarted) spawnMission(save.missionIndex); }, 2500);
            }
            updateMissionUI(); persist(); updateHUD();
          }
          break;
        }
      }
    }

    if (!hit && b.owner === 'enemy' && !player.dead) {
      const dx = b.mesh.position.x - player.position.x;
      const dz = b.mesh.position.z - player.position.z;
      const dy = b.mesh.position.y - 1.5;
      if (dx*dx + dz*dz < 0.8*0.8 && Math.abs(dy) < 1.6) {
        hit = true; damagePlayer(b.damage); impact(b.mesh.position, 0xef4444);
      }
    }

    if (hit) { scene.remove(b.mesh); bullets.splice(i,1); }
  }
}


function spawnPickup(x, z) {
  const m = new THREE.Mesh(new THREE.OctahedronGeometry(0.45), new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x22c55e, emissiveIntensity: 0.5 }));
  m.position.set(x, 0.7, z); m.castShadow = true; scene.add(m);
  pickups.push({ mesh: m, type: 'health', x, z, t: 0 });
}
function updatePickups(dt) {
  for (let i = pickups.length - 1; i >= 0; i--) {
    const p = pickups[i];
    p.t += dt;
    p.mesh.rotation.y += dt * 2;
    p.mesh.position.y = 0.7 + Math.sin(p.t * 3) * 0.12;
    const d = Math.hypot(player.position.x - p.x, player.position.z - p.z);
    if (d < 1.8) {
      player.health = Math.min(100, player.health + 25);
      save.health = player.health;
      scene.remove(p.mesh);
      pickups.splice(i,1);
      toast('+25 صحة');
      updateHUD(); persist();
    }
  }
}
function updateParticles(dt) {
  for (let i=particles.length-1;i>=0;i--) {
    const p = particles[i]; p.life -= dt;
    p.mesh.position.addScaledVector(p.vel, dt);
    p.vel.y -= 9 * dt;
    p.mesh.material.opacity = Math.max(0, p.life / p.max);
    p.mesh.scale.setScalar(Math.max(0.2, p.life / p.max));
    if (p.life <= 0) { scene.remove(p.mesh); particles.splice(i,1); }
  }
}

function updatePlayer(dt) {
  if (player.dead) return;
  player.invuln = Math.max(0, player.invuln - dt);
  // look
  player.yaw -= input.lookDX * 0.0032;
  player.pitch -= input.lookDY * 0.0026;
  player.pitch = clamp(player.pitch, -1.1, 1.1);
  input.lookDX = 0; input.lookDY = 0;

  // movement
  let mx = 0, mz = 0;
  if (input.keys['KeyW'] || input.keys['ArrowUp']) mz -= 1;
  if (input.keys['KeyS'] || input.keys['ArrowDown']) mz += 1;
  if (input.keys['KeyA'] || input.keys['ArrowLeft']) mx -= 1;
  if (input.keys['KeyD'] || input.keys['ArrowRight']) mx += 1;
  mx += input.moveX; mz += input.moveY;
  const len = Math.hypot(mx, mz);
  if (len > 1) { mx /= len; mz /= len; }
  const sprinting = !!(input.keys['ShiftLeft'] || input.keys['ShiftRight']);
  const speed = player.speed * (sprinting ? 1.7 : 1);
  const sin = Math.sin(player.yaw), cos = Math.cos(player.yaw);
  const vx = (mx * cos - mz * sin) * speed * dt;
  const vz = (mx * sin + mz * cos) * speed * dt;
  const nx = player.position.x + vx;
  const nz = player.position.z + vz;
  if (!collides(nx, player.position.z)) player.position.x = clamp(nx, -city.bounds+1, city.bounds-1);
  if (!collides(player.position.x, nz)) player.position.z = clamp(nz, -city.bounds+1, city.bounds-1);

  playerMesh.position.copy(player.position);
  playerMesh.rotation.y = player.yaw;

  // shooting auto
  const w = currentWeapon();
  if (input.shooting && w.auto) shoot();
}

function updateCamera() {
  const behind = new THREE.Vector3(Math.sin(player.yaw), 0, Math.cos(player.yaw));
  const camPos = player.position.clone().add(new THREE.Vector3(0, 4.8, 0)).add(behind.multiplyScalar(7.5));
  camPos.y += player.pitch * 2.2;
  camera.position.lerp(camPos, 0.18);
  const look = player.position.clone().add(new THREE.Vector3(0, 1.7, 0)).add(new THREE.Vector3(-Math.sin(player.yaw), player.pitch * 2.2, -Math.cos(player.yaw)).multiplyScalar(8));
  camera.lookAt(look);
}

function drawMinimap() {
  const c = ui.minimap, ctx = mmCtx, w=c.width, h=c.height;
  ctx.clearRect(0,0,w,h);
  ctx.fillStyle = 'rgba(15,23,42,0.9)'; ctx.fillRect(0,0,w,h);
  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  for(let i=0;i<=6;i++){ const p=i*w/6; ctx.beginPath(); ctx.moveTo(p,0); ctx.lineTo(p,h); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0,p); ctx.lineTo(w,p); ctx.stroke(); }
  const scale = w / (city.bounds*2);
  function mapX(x){ return (x + city.bounds) * scale; }
  function mapY(z){ return (z + city.bounds) * scale; }
  // mission
  if (mission && mission.center) { ctx.fillStyle = '#f59e0b'; ctx.beginPath(); ctx.arc(mapX(mission.center.x), mapY(mission.center.z), 5, 0, Math.PI*2); ctx.fill(); }
  // interactables
  for (const it of city.interactables) {
    ctx.fillStyle = it.type==='shop' ? '#60a5fa' : '#22c55e';
    ctx.beginPath(); ctx.arc(mapX(it.x), mapY(it.z), 4, 0, Math.PI*2); ctx.fill();
  }
  // enemies
  for (const e of enemies) { if(!e.alive) continue; ctx.fillStyle='#ef4444'; ctx.fillRect(mapX(e.mesh.position.x)-2, mapY(e.mesh.position.z)-2,4,4); }
  // player
  ctx.fillStyle='#f8fafc'; ctx.beginPath(); ctx.arc(mapX(player.position.x), mapY(player.position.z), 4, 0, TAU); ctx.fill();
  ctx.strokeStyle='#f59e0b'; ctx.beginPath(); ctx.moveTo(mapX(player.position.x), mapY(player.position.z));
  ctx.lineTo(mapX(player.position.x - Math.sin(player.yaw)*12), mapY(player.position.z - Math.cos(player.yaw)*12)); ctx.stroke();
}

function updateMarkers(t) {
  for (const it of city.interactables) {
    const m = it.marker; m.ring.position.y = 0.06 + Math.sin(t*0.003 + it.x)*0.03; m.beam.material.opacity = 0.12 + (Math.sin(t*0.003 + it.z)*0.04+0.04);
  }
}

function updateUIState() {
  const it = nearestInteractable();
  if (it) {
    ui.interactBtn.textContent = it.type === 'shop' ? 'المتجر' : 'المخبأ';
    ui.interactBtn.style.boxShadow = '0 0 0 2px rgba(245,158,11,.7)';
  } else {
    ui.interactBtn.textContent = 'تفاعل';
    ui.interactBtn.style.boxShadow = '';
  }
  if (mission && !mission.done) {
    const d = Math.hypot(player.position.x - mission.center.x, player.position.z - mission.center.z);
    ui.missionProgress.textContent = 'التقدم: ' + mission.killed + '/' + mission.count + ' | المكافأة: $' + mission.reward + ' | المسافة: ' + Math.round(d) + 'م';
  }
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = performance.now();
  if (gameStarted) {
    const modalOpen = !ui.shopModal.classList.contains('hidden') || !ui.houseModal.classList.contains('hidden') || !ui.gameOver.classList.contains('hidden') || pauseWanted;
    if (!modalOpen) {
      updatePlayer(dt);
      updateEnemies(dt);
      updateBullets(dt);
      updateParticles(dt);
      updatePickups(dt);
      updateCamera();
      updateMarkers(t);
      updateUIState();
      drawMinimap();
    } else {
      updateCamera(); drawMinimap();
    }
  } else {
    camera.position.lerp(new THREE.Vector3(30, 28, 30), 0.02);
    camera.lookAt(0,0,0);
  }
  renderer.render(scene, camera);
}

// Input
window.addEventListener('keydown', e => {
  input.keys[e.code] = true;
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.code === 'KeyE') tryInteract();
  if (e.code === 'KeyR') reload();
  if (e.code === 'KeyQ') cycleWeapon();
  if (e.code === 'KeyP') togglePause();
  if (e.code === 'Escape') { if (pauseWanted) { togglePause(false); return; } closeModal('shopModal'); closeModal('houseModal'); }
});
window.addEventListener('keyup', e => { input.keys[e.code] = false; });

function reload() {
  const w = currentWeapon();
  if (w.id === 'pistol') { toast('مسدس - ذخيرة غير محدودة'); return; }
  save.ammo[w.id] = w.ammo;
  updateHUD(); persist(); toast('تمت إعادة التعبئة');
}
function cycleWeapon() {
  const owned = save.ownedWeapons;
  const idx = owned.indexOf(save.equipped);
  equipWeapon(owned[(idx + 1) % owned.length]);
  toast('السلاح: ' + currentWeapon().name);
}

document.addEventListener('mousedown', e => {
  if (!gameStarted) return;
  if (e.button === 0) { input.shooting = true; shoot(); }
});
document.addEventListener('mouseup', e => { if (e.button === 0) input.shooting = false; });
document.addEventListener('mousemove', e => {
  if (!gameStarted) return;
  if (document.pointerLockElement === renderer.domElement) {
    input.lookDX += e.movementX; input.lookDY += e.movementY;
  }
});
renderer.domElement.addEventListener('click', () => {
  if (!gameStarted) return;
  if (window.matchMedia('(pointer: fine)').matches) renderer.domElement.requestPointerLock?.();
});

ui.startBtn.onclick = startGame;
ui.resetBtn.onclick = resetSave;
ui.respawnBtn.onclick = respawn;
ui.healBtn.onclick = () => {
  if (save.money < 50) { toast('تحتاج 50$ للاستشفاء'); return; }
  save.money -= 50; player.health = Math.min(100, player.health + 50 + (save.houseLevel-1)*10); save.health = player.health;
  persist(); updateHUD(); renderHouse(); toast('تم الاستشفاء');
};
ui.saveBtn.onclick = () => persist(true);
if (ui.pauseBtn) ui.pauseBtn.onclick = () => togglePause();
if (ui.resumeBtn) ui.resumeBtn.onclick = () => togglePause(false);
if (ui.pauseHomeBtn) ui.pauseHomeBtn.onclick = () => { togglePause(false); player.position.set(-95,0,55); player.health = Math.max(player.health, 60); save.health = player.health; persist(); updateHUD(); toast('عدت للمخبأ الآمن'); };

// Mobile controls
function setMoveFromTouch(t) {
  const rect = ui.moveZone.getBoundingClientRect();
  const cx = rect.left + rect.width/2, cy = rect.top + rect.height/2;
  const dx = t.clientX - cx, dy = t.clientY - cy;
  const max = rect.width * 0.28;
  const d = Math.hypot(dx,dy); const k = d > max ? max/d : 1;
  const nx = dx*k, ny = dy*k;
  ui.moveKnob.style.left = (rect.width/2 - 32 + nx) + 'px';
  ui.moveKnob.style.top = (rect.height/2 - 32 + ny) + 'px';
  input.moveX = clamp(nx/max, -1, 1);
  input.moveY = clamp(ny/max, -1, 1);
}
function resetMove() { ui.moveKnob.style.left = 'calc(50% - 32px)'; ui.moveKnob.style.top = 'calc(50% - 32px)'; input.moveX=0; input.moveY=0; }

ui.moveZone.addEventListener('touchstart', e => { e.preventDefault(); setMoveFromTouch(e.changedTouches[0]); }, {passive:false});
ui.moveZone.addEventListener('touchmove', e => { e.preventDefault(); setMoveFromTouch(e.changedTouches[0]); }, {passive:false});
ui.moveZone.addEventListener('touchend', e => { e.preventDefault(); resetMove(); }, {passive:false});
ui.moveZone.addEventListener('touchcancel', resetMove);

ui.lookPad.addEventListener('touchstart', e => { e.preventDefault(); const t=e.changedTouches[0]; input.touchLookId=t.identifier; input.lastLook={x:t.clientX,y:t.clientY}; }, {passive:false});
ui.lookPad.addEventListener('touchmove', e => {
  e.preventDefault();
  for (const t of e.changedTouches) {
    if (t.identifier === input.touchLookId && input.lastLook) {
      input.lookDX += (t.clientX - input.lastLook.x) * 1.3;
      input.lookDY += (t.clientY - input.lastLook.y) * 1.3;
      input.lastLook = {x:t.clientX,y:t.clientY};
    }
  }
}, {passive:false});
ui.lookPad.addEventListener('touchend', e => { for (const t of e.changedTouches) if (t.identifier===input.touchLookId){ input.touchLookId=null; input.lastLook=null; } });

ui.shootBtn.addEventListener('touchstart', e=>{ e.preventDefault(); input.shooting=true; shoot(); }, {passive:false});
ui.shootBtn.addEventListener('touchend', e=>{ e.preventDefault(); input.shooting=false; }, {passive:false});
ui.shootBtn.addEventListener('mousedown', ()=>{ input.shooting=true; shoot(); });
ui.shootBtn.addEventListener('mouseup', ()=>{ input.shooting=false; });
ui.reloadBtn.onclick = reload;
ui.interactBtn.onclick = tryInteract;
ui.weaponBtn.onclick = cycleWeapon;

window.addEventListener('orientationchange', () => setTimeout(() => window.dispatchEvent(new Event('resize')), 150));
window.addEventListener('resize', () => {
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
});

const playerMesh = createPlayerMesh();
buildCity();
spawnMission(save.missionIndex);
updateHUD(); updateMissionUI(); renderShop(); renderHouse(); showMenu();
animate();

window.__gameLoaded = true;

window.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('beforeunload', () => persist());
setInterval(() => { if (gameStarted) persist(); }, 10000);
} catch(e) { console.error(e); if(window.__showErr) window.__showErr((e && (e.stack||e.message)) || String(e)); }
