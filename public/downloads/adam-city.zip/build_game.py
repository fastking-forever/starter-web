import * as THREE from 'three';

const STORAGE_KEY = 'adam_city_ops_v1';
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);
const choice = (arr) => arr[Math.floor(Math.random() * arr.length)];

const WEAPONS = [
  { id: 'pistol', name: 'مسدس', price: 0, damage: 18, fireRate: 320, range: 70, auto: false, ammo: Infinity, color: 0xfcd34d },
  { id: 'smg', name: 'SMG', price: 450, damage: 12, fireRate: 110, range: 65, auto: true, ammo: 120, color: 0x60a5fa },
  { id: 'rifle', name: 'بندقية', price: 900, damage: 28, fireRate: 180, range: 110, auto: true, ammo: 90, color: 0xf97316 },
];
const SHOP_ITEMS = [
  { id: 'smg', kind: 'weapon', name: 'SMG', desc: 'سلاح سريع مناسب للاشتباكات القريبة.', price: 450 },
  { id: 'rifle', kind: 'weapon', name: 'بندقية تكتيكية', desc: 'ضرر أعلى ومدى أطول لمهام العصابات.', price: 900 },
  { id: 'armor', kind: 'armor', name: 'درع خفيف', desc: 'يزيد الحماية حتى 100.', price: 200 },
  { id: 'ammo', kind: 'ammo', name: 'ذخيرة إضافية', desc: 'يعيد تعبئة ذخيرة الأسلحة التي تملكها.', price: 120 },
  { id: 'house', kind: 'house', name: 'ترقية المخبأ', desc: 'يحسن الاستشفاء ويزيد مكافأة حفظ الأمان.', price: 700 },
];

const DEFAULT_SAVE = () => ({
  money: 150, health: 100, armor: 0,
  ownedWeapons: ['pistol'], equipped: 'pistol',
  ammo: { pistol: Infinity, smg: 90, rifle: 60 },
  houseLevel: 1, missionIndex: 0,
  stats: { earned: 0, kills: 0, missions: 0 },
  position: { x: 0, z: 18 },
});

let save = loadSave();
function loadSave() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SAVE();
    const p = JSON.parse(raw);
    return { ...DEFAULT_SAVE(), ...p, ammo: { ...DEFAULT_SAVE().ammo, ...(p.ammo || {}) }, stats: { ...DEFAULT_SAVE().stats, ...(p.stats || {}) }, position: { ...DEFAULT_SAVE().position, ...(p.position || {}) } };
  } catch { return DEFAULT_SAVE(); }
}
function persist(showToastMsg = false) {
  save.position = { x: player.position.x, z: player.position.z };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
  if (showToastMsg) toast('تم حفظ التقدم');
}

const ui = {
  menu: document.getElementById('menu'), hud: document.getElementById('hud'), menuStats: document.getElementById('menuStats'),
  startBtn: document.getElementById('startBtn'), resetBtn: document.getElementById('resetBtn'), respawnBtn: document.getElementById('respawnBtn'),
  healthBar: document.getElementById('healthBar'), armorBar: document.getElementById('armorBar'), healthText: document.getElementById('healthText'), armorText: document.getElementById('armorText'),
  moneyText: document.getElementById('moneyText'), weaponText: document.getElementById('weaponText'), ammoText: document.getElementById('ammoText'),
  missionTitle: document.getElementById('missionTitle'), missionDesc: document.getElementById('missionDesc'), missionProgress: document.getElementById('missionProgress'),
  toast: document.getElementById('toast'), hitMarker: document.getElementById('hitMarker'), damageOverlay: document.getElementById('damageOverlay'),
  shopModal: document.getElementById('shopModal'), houseModal: document.getElementById('houseModal'), shopItems: document.getElementById('shopItems'), shopMoney: document.getElementById('shopMoney'), houseInfo: document.getElementById('houseInfo'),
  healBtn: document.getElementById('healBtn'), saveBtn: document.getElementById('saveBtn'), minimap: document.getElementById('minimap'),
  moveZone: document.getElementById('moveZone'), moveKnob: document.getElementById('moveKnob'), lookPad: document.getElementById('lookPad'),
  shootBtn: document.getElementById('shootBtn'), reloadBtn: document.getElementById('reloadBtn'), interactBtn: document.getElementById('interactBtn'), weaponBtn: document.getElementById('weaponBtn'),
};
const mmCtx = ui.minimap.getContext('2d');

const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('game'), antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);
scene.fog = new THREE.Fog(0x87ceeb, 90, 320);
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 500);
const clock = new THREE.Clock();
scene.add(new THREE.HemisphereLight(0xdbeafe, 0x3f6212, 1.15));
const dir = new THREE.DirectionalLight(0xfff1c1, 1.35);
dir.position.set(80, 120, 40); dir.castShadow = true;
dir.shadow.mapSize.set(2048, 2048);
dir.shadow.camera.left = -140; dir.shadow.camera.right = 140; dir.shadow.camera.top = 140; dir.shadow.camera.bottom = -140; dir.shadow.camera.far = 350;
scene.add(dir);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), new THREE.MeshStandardMaterial({ color: 0x4b5563, roughness: 1 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
const grass = new THREE.Mesh(new THREE.PlaneGeometry(700, 700), new THREE.MeshStandardMaterial({ color: 0x365314, roughness: 1 }));
grass.rotation.x = -Math.PI / 2; grass.position.y = -0.02; grass.receiveShadow = true; scene.add(grass);

const city = { colliders: [], buildings: [], interactables: [], bounds: 180 };
const raycaster = new THREE.Raycaster();
const tmpVec = new THREE.Vector3();
const player = { position: new THREE.Vector3(save.position.x, 0, save.position.z), velocity: new THREE.Vector3(), yaw: 0, pitch: 0.18, radius: 0.8, speed: 12, health: save.health, armor: save.armor, dead: false, lastShot: 0, invuln: 0 };
const input = { keys: {}, moveX: 0, moveY: 0, lookDX: 0, lookDY: 0, shooting: false, touchLookId: null, lastLook: null };
let gameStarted = false;
let enemies = [], bullets = [], particles = [], pickups = [];
let mission = null;
let toastTimer = 0;

function toast(msg, ms = 2200) {
  ui.toast.textContent = msg;
  ui.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => ui.toast.classList.remove('show'), ms);
}

function addCollider(x, z, w, d) { city.colliders.push({ x, z, w, d }); }
function boxIntersects(px, pz, r, c) {
  const dx = Math.abs(px - c.x) - (c.w / 2 + r);
  const dz = Math.abs(pz - c.z) - (c.d / 2 + r);
  return dx < 0 && dz < 0;
}
function collides(px, pz, r = player.radius) {
  for (const c of city.colliders) if (boxIntersects(px, pz, r, c)) return true;
  return Math.abs(px) > city.bounds - r || Math.abs(pz) > city.bounds - r;
}

function makeBuilding(x, z, w, h, d, color, opts = {}) {
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.85, metalness: 0.05 });
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  mesh.position.set(x, h / 2, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  scene.add(mesh);
  city.buildings.push(mesh);
  if (!opts.noCollider) addCollider(x, z, w, d);
  if (opts.rim) {
    const rim = new THREE.Mesh(new THREE.BoxGeometry(w + 0.2, 0.4, d + 0.2), new THREE.MeshStandardMaterial({ color: opts.rim, emissive: opts.rim, emissiveIntensity: 0.25 }));
    rim.position.set(x, h + 0.2, z);
    scene.add(rim);
  }
  return mesh;
}

function makeRoad(x, z, w, d) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 1 }));
  m.rotation.x = -Math.PI / 2; m.position.set(x, 0.01, z); m.receiveShadow = true; scene.add(m);
}

function makeMarker(color, x, z, label) {
  const ring = new THREE.Mesh(new THREE.RingGeometry(2.2, 3.2, 32), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, side: THREE.DoubleSide }));
  ring.rotation.x = -Math.PI / 2; ring.position.set(x, 0.05, z); scene.add(ring);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 8, 12), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.18 }));
  beam.position.set(x, 4, z); scene.add(beam);
  return { ring, beam, x, z, label };
}

function buildCity() {
  // Roads
  for (let i = -3; i <= 3; i++) { makeRoad(i * 45, 0, 16, 380); makeRoad(0, i * 45, 380, 16); }
  // Blocks/buildings
  const palette = [0x334155, 0x475569, 0x64748b, 0x374151, 0x1f2937, 0x4b5563];
  for (let gx = -3; gx <= 3; gx++) {
    for (let gz = -3; gz <= 3; gz++) {
      const cx = gx * 45, cz = gz * 45;
      if (Math.abs(gx) <= 0 && Math.abs(gz) <= 0) continue; // center plaza
      const seed = Math.abs(gx * 7 + gz * 13);
      const bCount = 2 + (seed % 2);
      for (let i = 0; i < bCount; i++) {
        const w = 10 + (seed + i * 3) % 10;
        const d = 10 + (seed + i * 5) % 12;
        const h = 8 + ((seed + i * 11) % 8) * 3;
        const ox = (i === 0 ? -8 : 8) + ((seed % 5) - 2);
        const oz = (i === 0 ? -8 : 8) + (((seed + 2) % 5) - 2);
        const color = palette[(seed + i) % palette.length];
        makeBuilding(cx + ox, cz + oz, w, h, d, color, { rim: [0x38bdf8,0xf59e0b,0xa78bfa][(seed+i)%3] });
      }
    }
  }
  // Plaza
  const plaza = new THREE.Mesh(new THREE.CircleGeometry(18, 48), new THREE.MeshStandardMaterial({ color: 0x6b7280, roughness: 0.95 }));
  plaza.rotation.x = -Math.PI / 2; plaza.position.y = 0.015; plaza.receiveShadow = true; scene.add(plaza);

  // Safe house
  makeBuilding(-95, 70, 18, 8, 16, 0x14532d, { rim: 0x22c55e });
  const houseDoor = new THREE.Mesh(new THREE.BoxGeometry(3, 4, 0.5), new THREE.MeshStandardMaterial({ color: 0x86efac, emissive: 0x22c55e, emissiveIntensity: 0.4 }));
  houseDoor.position.set(-95, 2, 62.2); scene.add(houseDoor);
  city.interactables.push({ type: 'house', x: -95, z: 60, r: 5, label: 'المخبأ الآمن' });

  // Shop
  makeBuilding(95, -70, 18, 8, 16, 0x1e3a8a, { rim: 0x60a5fa });
  const shopDoor = new THREE.Mesh(new THREE.BoxGeometry(3, 4, 0.5), new THREE.MeshStandardMaterial({ color: 0xbfdbfe, emissive: 0x60a5fa, emissiveIntensity: 0.4 }));
  shopDoor.position.set(95, 2, -62.2); scene.add(shopDoor);
  city.interactables.push({ type: 'shop', x: 95, z: -60, r: 5, label: 'متجر الأسلحة' });

  city.interactables.forEach(it => { it.marker = makeMarker(it.type === 'shop' ? 0x60a5fa : 0x22c55e, it.x, it.z, it.label); });

  // Props / cover
  for (let i = 0; i < 60; i++) {
    const x = rand(-150, 150), z = rand(-150, 150);
    if (Math.abs(x) < 25 && Math.abs(z) < 25) continue;
    if (collides(x, z, 2.5)) continue;
    const crate = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.8, 1.8), new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.9 }));
    crate.position.set(x, 0.9, z); crate.castShadow = true; crate.receiveShadow = true; scene.add(crate);
    addCollider(x, z, 1.8, 1.8);
  }
  // Street lights
  for (let i = -3; i <= 3; i++) for (let j = -3; j <= 3; j++) {
    if ((i + j) % 2 !== 0) continue;
    const x = i * 45 + 10, z = j * 45 + 10;
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.18, 7, 8), new THREE.MeshStandardMaterial({ color: 0x9ca3af }));
    pole.position.set(x, 3.5, z); scene.add(pole);
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.45, 10, 10), new THREE.MeshStandardMaterial({ color: 0xfef08a, emissive: 0xfef08a, emissiveIntensity: 1.2 }));
    lamp.position.set(x, 7.1, z); scene.add(lamp);
  }
}

function createPlayerMesh() {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.55, 1.2, 4, 8), new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.7 }));
  body.position.y = 1.5; body.castShadow = true; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.38, 16, 16), new THREE.MeshStandardMaterial({ color: 0xf1c27d }));
  head.position.y = 2.45; head.castShadow = true; g.add(head);
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 0.8), new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.4, roughness: 0.4 }));
  gun.position.set(0.35, 1.55, -0.5); g.add(gun);
  g.userData.gun = gun;
  scene.add(g);
  return g;
}
const playerMesh = createPlayerMesh();

function makeEnemy(x, z) {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.55, 1.2, 4, 8), new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.75 }));
  body.position.y = 1.5; body.castShadow = true; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.36, 14, 14), new THREE.MeshStandardMaterial({ color: 0xe0ac69 }));
  head.position.y = 2.42; head.castShadow = true; g.add(head);
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.15, 0.2), new THREE.MeshStandardMaterial({ color: 0x111827 }));
  visor.position.set(0, 2.45, -0.28); g.add(visor);
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.7), new THREE.MeshStandardMaterial({ color: 0x111827 }));
  gun.position.set(0.32, 1.55, -0.45); g.add(gun);
  g.position.set(x, 0, z);
  scene.add(g);
  return { mesh: g, hp: 55, maxHp: 55, speed: rand(3.2, 4.8), fireCd: rand(0.6, 1.4), alive: true, radius: 0.8, aggro: 0 };
}

function spawnMission(index) {
  enemies.forEach(e => scene.remove(e.mesh));
  enemies = []; bullets = []; pickups = [];
  const defs = [
    { title: 'تطهير نقطة العصابة', desc: 'اقضِ على 3 من عناصر العصابة المسلحة في الساحة الشمالية.', center: {x:0,z:-75}, count:3, reward: 200 },
    { title: 'حماية طريق الإمداد', desc: 'صفِّ 4 مسلحين يحاولون السيطرة على التقاطع الشرقي.', center: {x:80,z:0}, count:4, reward: 320 },
    { title: 'اقتحام وكر السلاح', desc: 'اقتحم المنطقة الجنوبية وازل 5 من حراس العصابة.', center: {x:0,z:80}, count:5, reward: 450 },
    { title: 'عملية المدينة', desc: 'واجه 6 مسلحين في منطقة صناعية غرب المدينة.', center: {x:-85,z:-10}, count:6, reward: 650 },
  ];
  const def = defs[index % defs.length];
  mission = { ...def, index, killed: 0, done: false };
  for (let i = 0; i < def.count; i++) {
    const a = (i / def.count) * TAU;
    const r = 8 + Math.random() * 10;
    const x = clamp(def.center.x + Math.cos(a) * r, -city.bounds + 5, city.bounds - 5);
    const z = clamp(def.center.z + Math.sin(a) * r, -city.bounds + 5, city.bounds - 5);
    enemies.push(makeEnemy(x, z));
  }
  toast('مهمة جديدة: ' + def.title);
  updateMissionUI();
}

function updateMissionUI() {
  if (!mission) return;
  ui.missionTitle.textContent = mission.title;
  ui.missionDesc.textContent = mission.desc + ' (أعداء مسلحون فقط)';
  ui.missionProgress.textContent = mission.done ? `مكتملة! +$${mission.reward}` : `التقدم: ${mission.killed}/${mission.count} | المكافأة: $${mission.reward}`;
}

function equipWeapon(id) {
  if (!save.ownedWeapons.includes(id)) return;
  save.equipped = id;
  const w = WEAPONS.find(x => x.id === id);
  ui.weaponText.textContent = w.name;
  updateHUD();
  persist();
}
function currentWeapon() { return WEAPONS.find(w => w.id === save.equipped) || WEAPONS[0]; }

function addMoney(amount) {
  save.money += amount;
  if (amount > 0) save.stats.earned += amount;
  updateHUD();
}
function updateHUD() {
  ui.healthBar.style.width = clamp(player.health, 0, 100) + '%';
  ui.armorBar.style.width = clamp(player.armor, 0, 100) + '%';
  ui.healthText.textContent = Math.max(0, Math.ceil(player.health));
  ui.armorText.textContent = Math.max(0, Math.ceil(player.armor));
  ui.moneyText.textContent = '$' + save.money;
  const w = currentWeapon();
  ui.weaponText.textContent = w.name;
  const ammo = save.ammo[w.id];
  ui.ammoText.textContent = ammo === Infinity ? '∞' : `${ammo}`;
}

function showMenu() {
  ui.menu.classList.remove('hidden');
  ui.hud.classList.add('hidden');
  ui.menuStats.innerHTML = `
    <div class="menu-stat"><div class="label">الفلوس</div><div class="value">$${save.money}</div></div>
    <div class="menu-stat"><div class="label">المهمات</div><div class="value">${save.stats.missions}</div></div>
    <div class="menu-stat"><div class="label">المخبأ</div><div class="value">Lv ${save.houseLevel}</div></div>`;
}

function startGame() {
  ui.menu.classList.add('hidden');
  ui.hud.classList.remove('hidden');
  gameStarted = true;
  player.health = save.health; player.armor = save.armor; player.dead = false;
  if (!mission) spawnMission(save.missionIndex);
  updateHUD(); updateMissionUI();
  toast('مرحبًا بك في ADAM: City Ops');
}

function resetSave() {
  if (!confirm('مسح التقدم بالكامل؟')) return;
  localStorage.removeItem(STORAGE_KEY);
  save = DEFAULT_SAVE();
  player.position.set(save.position.x, 0, save.position.z);
  player.health = 100; player.armor = 0; player.dead = false;
  spawnMission(0);
  updateHUD(); updateMissionUI(); renderShop(); renderHouse(); showMenu();
}

function openModal(id) { document.getElementById(id).classList.remove('hidden'); if (id === 'shopModal') renderShop(); if (id === 'houseModal') renderHouse(); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => closeModal(btn.dataset.close)));

function renderShop() {
  ui.shopMoney.textContent = 'رصيدك: $' + save.money;
  ui.shopItems.innerHTML = '';
  for (const item of SHOP_ITEMS) {
    const owned = item.kind === 'weapon' && save.ownedWeapons.includes(item.id);
    const canBuy = !owned && save.money >= item.price;
    const el = document.createElement('div');
    el.className = 'shop-item' + (owned ? ' owned' : '');
    el.innerHTML = `<h3>${item.name}</h3><p>${item.desc}</p><div class="shop-price">${owned ? 'مملوك' : '$'+item.price}</div>`;
    const btn = document.createElement('button');
    btn.className = owned ? 'secondary-btn' : 'primary-btn';
    btn.textContent = owned ? 'مجهز' : (item.kind === 'weapon' ? 'شراء' : 'شراء/استخدام');
    btn.disabled = owned || (!canBuy && item.kind !== 'ammo' && item.kind !== 'armor' && item.kind !== 'house');
    if (!owned && save.money < item.price) btn.disabled = true;
    btn.onclick = () => buyItem(item);
    el.appendChild(btn);
    ui.shopItems.appendChild(el);
  }
}
function buyItem(item) {
  if (save.money < item.price) { toast('رصيدك غير كافٍ'); return; }
  if (item.kind === 'weapon') {
    if (save.ownedWeapons.includes(item.id)) return;
    save.money -= item.price; save.ownedWeapons.push(item.id); save.ammo[item.id] = WEAPONS.find(w=>w.id===item.id).ammo === Infinity ? Infinity : Math.max(save.ammo[item.id]||0, WEAPONS.find(w=>w.id===item.id).ammo);
    equipWeapon(item.id); toast('تم شراء ' + item.name);
  } else if (item.kind === 'armor') {
    save.money -= item.price; player.armor = 100; save.armor = 100; toast('تم شراء الدرع');
  } else if (item.kind === 'ammo') {
    save.money -= item.price;
    for (const wid of save.ownedWeapons) { if (wid !== 'pistol') save.ammo[wid] = (save.ammo[wid] || 0) + (wid === 'rifle' ? 45 : 60); }
    toast('تمت تعبئة الذخيرة');
  } else if (item.kind === 'house') {
    save.money -= item.price; save.houseLevel += 1; toast('تمت ترقية المخبأ');
  }
  persist(); updateHUD(); renderShop(); renderHouse();
}

function renderHouse() {
  ui.houseInfo.innerHTML = `
    <div class="house-row"><span>مستوى المخبأ</span><strong>Lv ${save.houseLevel}</strong></div>
    <div class="house-row"><span>استشفاء متاح</span><strong>${50 + (save.houseLevel-1)*10} صحة</strong></div>
    <div class="house-row"><span>الأسلحة المملوكة</span><strong>${save.ownedWeapons.map(id=>WEAPONS.find(w=>w.id===id).name).join('، ')}</strong></div>
    <div class="house-row"><span>الموقع</span><strong>الحي الأخضر</strong></div>`;
}

Path('adam-city/game.js').write_text(''.join(chunks), encoding='utf-8')
print('ok')
