from pathlib import Path
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')

# Better HUD objective distance and interaction hint
old_ui_state = '''function updateUIState() {
  const it = nearestInteractable();
  if (it) ui.interactBtn.textContent = it.type === 'shop' ? 'المتجر' : 'المخبأ';
  else ui.interactBtn.textContent = 'تفاعل';
}'''
new_ui_state = '''function updateUIState() {
  const it = nearestInteractable();
  if (it) {
    ui.interactBtn.textContent = it.type === 'shop' ? 'المتجر' : 'المخبأ';
    ui.interactBtn.style.boxShadow = '0 0 0 2px rgba(245,158,11,.7)';
  } else {
    ui.interactBtn.textContent = 'تفاعل';
    ui.interactBtn.style.boxShadow = '';
  }
  if (mission && !mission.done) {
    const d = Math.hypot(player.position.x - mission.center.x, player.position.z - mission.center.z);
    ui.missionProgress.textContent = 'التقدم: ' + mission.killed + '/' + mission.count + ' | المكافأة: $' + mission.reward + ' | المسافة: ' + Math.round(d) + 'م';
  }
}'''
if old_ui_state in s:
    s = s.replace(old_ui_state, new_ui_state)
    print('ui ok')
else:
    print('ui miss')

# add health pickups from killed enemies
old_kill = '''          if (e.hp <= 0) {
            e.alive = false; scene.remove(e.mesh);
            save.stats.kills += 1; addMoney(35);
            mission.killed += 1;
            toast('+35$ — تم إسقاط هدف مسلح');'''
new_kill = '''          if (e.hp <= 0) {
            e.alive = false; scene.remove(e.mesh);
            save.stats.kills += 1; addMoney(35);
            mission.killed += 1;
            toast('+35$ — تم إسقاط هدف مسلح');
            if (Math.random() < 0.35) spawnPickup(e.mesh.position.x, e.mesh.position.z);'''
if old_kill in s:
    s = s.replace(old_kill, new_kill)
    print('kill ok')
else:
    print('kill miss')

# pickup system
if 'function spawnPickup' not in s:
    pickup_code = r'''
function spawnPickup(x, z) {
  const m = new THREE.Mesh(new THREE.OctahedronGeometry(0.45), new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x22c55e, emissiveIntensity: 0.5 }));
  m.position.set(x, 0.7, z); m.castShadow = true; scene.add(m);
  pickups.push({ mesh: m, type: 'health', x, z, t: 0 });
}
function updatePickups(dt) {
  for (let i = pickups.length - 1; i >= 0; i--) {
    const p = pickups[i];
    p.t += dt;
    p.mesh.rotation.y += dt * 2;
    p.mesh.position.y = 0.7 + Math.sin(p.t * 3) * 0.12;
    const d = Math.hypot(player.position.x - p.x, player.position.z - p.z);
    if (d < 1.8) {
      player.health = Math.min(100, player.health + 25);
      save.health = player.health;
      scene.remove(p.mesh);
      pickups.splice(i,1);
      toast('+25 صحة');
      updateHUD(); persist();
    }
  }
}
'''
    s = s.replace('function updateParticles(dt) {', pickup_code + 'function updateParticles(dt) {', 1)
    print('pickup ok')
else:
    print('pickup skip')

# call updatePickups in animate
s = s.replace('      updateParticles(dt);\n      updateCamera();', '      updateParticles(dt);\n      updatePickups(dt);\n      updateCamera();', 1)

# remove pickups in spawnMission
s = s.replace('enemies = []; bullets.forEach(b=>scene.remove(b.mesh)); bullets = []; particles.forEach(p=>scene.remove(p.mesh)); particles = [];',
              'enemies = []; bullets.forEach(b=>scene.remove(b.mesh)); bullets = []; particles.forEach(p=>scene.remove(p.mesh)); particles = []; pickups.forEach(p=>scene.remove(p.mesh)); pickups = [];', 1)

# expose window resize on orientation change for mobile
if 'orientationchange' not in s:
    s = s.replace("window.addEventListener('resize', () => {", "window.addEventListener('orientationchange', () => setTimeout(() => window.dispatchEvent(new Event('resize')), 150));\nwindow.addEventListener('resize', () => {", 1)

# prevent context menu on long press mobile
if 'contextmenu' not in s:
    s = s.replace("window.addEventListener('beforeunload'", "window.addEventListener('contextmenu', e => e.preventDefault());\nwindow.addEventListener('beforeunload'", 1)

p.write_text(s, encoding='utf-8')
print('done')
