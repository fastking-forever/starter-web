from pathlib import Path

rest = r'''
function nearestInteractable() {
  let best = null, bestD = 999;
  for (const it of city.interactables) {
    const d = Math.hypot(player.position.x - it.x, player.position.z - it.z);
    if (d < it.r + 1.2 && d < bestD) { best = it; bestD = d; }
  }
  return best;
}
function tryInteract() {
  const it = nearestInteractable();
  if (!it) { toast('لا يوجد شيء للتفاعل معه هنا'); return; }
  if (it.type === 'shop') openModal('shopModal');
  if (it.type === 'house') openModal('houseModal');
}

function spawnBullet(from, dir, owner, damage, range, color=0xfff2a8) {
  bullets.push({ from: from.clone(), dir: dir.clone().normalize(), owner, damage, range, traveled: 0, speed: owner==='player'? 90 : 55, color });
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshBasicMaterial({ color }));
  m.position.copy(from);
  scene.add(m);
  bullets[bullets.length-1].mesh = m;
}

function muzzleFlash(pos, color) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), new THREE.MeshBasicMaterial({ color, transparent:true, opacity:0.9 }));
  m.position.copy(pos); scene.add(m);
  particles.push({ mesh:m, life:0.06, max:0.06, vel:new THREE.Vector3() });
}

function impact(pos, color=0xf59e0b) {
  for (let i=0;i<6;i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.08,0.08,0.08), new THREE.MeshBasicMaterial({ color }));
    m.position.copy(pos); scene.add(m);
    particles.push({ mesh:m, life: rand(0.2,0.5), max:0.5, vel:new THREE.Vector3(rand(-2,2),rand(1,4),rand(-2,2)) });
  }
}

function shoot() {
  if (!gameStarted || player.dead) return;
  if (!ui.shopModal.classList.contains('hidden') || !ui.houseModal.classList.contains('hidden')) return;
  const w = currentWeapon();
  const now = performance.now();
  if (now - player.lastShot < w.fireRate) return;
  const ammo = save.ammo[w.id];
  if (ammo !== Infinity && ammo <= 0) { toast('لا توجد ذخيرة'); return; }
  player.lastShot = now;
  if (ammo !== Infinity) save.ammo[w.id] = ammo - 1;
  const dir = new THREE.Vector3(0,0,-1).applyAxisAngle(new THREE.Vector3(0,1,0), player.yaw).applyAxisAngle(new THREE.Vector3(1,0,0), player.pitch);
  dir.x += rand(-0.01,0.01); dir.y += rand(-0.01,0.01); dir.z += rand(-0.01,0.01);
  const from = player.position.clone().add(new THREE.Vector3(0,1.6,0)).add(dir.clone().multiplyScalar(0.8));
  spawnBullet(from, dir, 'player', w.damage, w.range, w.color);
  muzzleFlash(from, w.color);
  updateHUD();
}

function damagePlayer(amount) {
  if (player.dead || player.invuln > 0) return;
  let a = amount;
  if (player.armor > 0) { const absorbed = Math.min(player.armor, a * 0.6); player.armor -= absorbed; a -= absorbed; }
  player.health -= a;
  save.health = Math.max(0, player.health); save.armor = Math.max(0, player.armor);
  ui.damageOverlay.classList.add('show'); setTimeout(()=>ui.damageOverlay.classList.remove('show'), 120);
  if (player.health <= 0) die();
  updateHUD();
}

function die() {
  player.dead = true;
  save.money = Math.max(0, Math.floor(save.money * 0.95));
  save.health = 100; save.armor = Math.max(0, Math.floor(player.armor));
  persist();
  ui.gameOver.classList.remove('hidden');
}

function respawn() {
  ui.gameOver.classList.add('hidden');
  player.dead = false; player.health = 100; player.armor = save.armor;
  save.health = 100; player.invuln = 2;
  player.position.set(-95, 0, 55);
  player.yaw = 0; player.pitch = 0.15;
  persist(); updateHUD();
  toast('عدت إلى المخبأ الآمن');
}

function updateEnemies(dt) {
  for (const e of enemies) {
    if (!e.alive) continue;
    const toP = tmpVec.subVectors(player.position, e.mesh.position);
    toP.y = 0;
    const dist = toP.length();
    if (dist < 40) e.aggro = 1;
    if (e.aggro <= 0) continue;
    const dir = toP.clone().normalize();
    e.mesh.lookAt(player.position.x, 0, player.position.z);
    const desired = dist > 10 ? 1 : (dist < 6 ? -0.7 : 0);
    const step = dir.multiplyScalar(desired * e.speed * dt);
    const nx = e.mesh.position.x + step.x;
    const nz = e.mesh.position.z + step.z;
    if (!collides(nx, e.mesh.position.z, e.radius)) e.mesh.position.x = nx;
    if (!collides(e.mesh.position.x, nz, e.radius)) e.mesh.position.z = nz;

    e.fireCd -= dt;
    if (e.fireCd <= 0 && dist < 35 && !player.dead) {
      e.fireCd = rand(0.8, 1.6);
      const aim = new THREE.Vector3(player.position.x - e.mesh.position.x, 1.4, player.position.z - e.mesh.position.z).normalize();
      aim.x += rand(-0.03,0.03); aim.y += rand(-0.01,0.01); aim.z += rand(-0.03,0.03);
      const from = e.mesh.position.clone().add(new THREE.Vector3(0,1.5,0)).add(aim.clone().multiplyScalar(0.8));
      spawnBullet(from, aim, 'enemy', 8, 45, 0xff7777);
      muzzleFlash(from, 0xff6666);
    }
  }
}

function updateBullets(dt) {
  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    const step = b.speed * dt;
    b.mesh.position.addScaledVector(b.dir, step);
    b.traveled += step;
    let hit = false;
    if (b.traveled > b.range) hit = true;

    // building collision
    if (!hit) {
      for (const c of city.colliders) {
        if (Math.abs(b.mesh.position.x - c.x) < c.w/2 + 0.1 && Math.abs(b.mesh.position.z - c.z) < c.d/2 + 0.1 && b.mesh.position.y < 12) { hit = true; impact(b.mesh.position, 0x94a3b8); break; }
      }
    }

    if (!hit && b.owner === 'player') {
      for (const e of enemies) {
        if (!e.alive) continue;
        const dx = b.mesh.position.x - e.mesh.position.x;
        const dz = b.mesh.position.z - e.mesh.position.z;
        const dy = b.mesh.position.y - 1.5;
        if (dx*dx + dz*dz < 0.9*0.9 && Math.abs(dy) < 1.6) {
          e.hp -= b.damage; hit = true; impact(b.mesh.position, 0xffcc00);
          ui.hitMarker.classList.add('show'); setTimeout(()=>ui.hitMarker.classList.remove('show'), 70);
          if (e.hp <= 0) {
            e.alive = false; scene.remove(e.mesh);
            save.stats.kills += 1; addMoney(35);
            mission.killed += 1;
            toast('+35$ — تم إسقاط هدف مسلح');
            if (mission.killed >= mission.count && !mission.done) {
              mission.done = true; addMoney(mission.reward); save.stats.missions += 1; save.missionIndex += 1;
              toast(`اكتملت المهمة! +$${mission.reward}`);
              persist();
              setTimeout(() => { if (gameStarted) spawnMission(save.missionIndex); }, 2500);
            }
            updateMissionUI(); persist(); updateHUD();
          }
          break;
        }
      }
    }

    if (!hit && b.owner === 'enemy' && !player.dead) {
      const dx = b.mesh.position.x - player.position.x;
      const dz = b.mesh.position.z - player.position.z;
      const dy = b.mesh.position.y - 1.5;
      if (dx*dx + dz*dz < 0.8*0.8 && Math.abs(dy) < 1.6) {
        hit = true; damagePlayer(b.damage); impact(b.mesh.position, 0xef4444);
      }
    }

    if (hit) { scene.remove(b.mesh); bullets.splice(i,1); }
  }
}

function updateParticles(dt) {
  for (let i=particles.length-1;i>=0;i--) {
    const p = particles[i]; p.life -= dt;
    p.mesh.position.addScaledVector(p.vel, dt);
    p.vel.y -= 9 * dt;
    p.mesh.material.opacity = Math.max(0, p.life / p.max);
    p.mesh.scale.setScalar(Math.max(0.2, p.life / p.max));
    if (p.life <= 0) { scene.remove(p.mesh); particles.splice(i,1); }
  }
}
'''
Path('adam-city/game.js').write_text(Path('adam-city/game.js').read_text(encoding='utf-8') + rest, encoding='utf-8')
print('ok')
