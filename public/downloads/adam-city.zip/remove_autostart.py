from pathlib import Path
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')
old = "setTimeout(function(){ try{ if(typeof startGame==='function') startGame(); }catch(e){ if(window.__showErr) window.__showErr(e.stack||String(e)); } }, 1200);"
if old in s:
    p.write_text(s.replace(old,''), encoding='utf-8')
    print('ok')
else:
    print('not found')
