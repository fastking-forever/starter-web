from pathlib import Path
import re
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')

# add UI refs
s = s.replace(
    "  gameOver: document.getElementById('gameOver'), shopItems: document.getElementById('shopItems'), shopMoney: document.getElementById('shopMoney'), houseInfo: document.getElementById('houseInfo'),",
    "  gameOver: document.getElementById('gameOver'), pauseOverlay: document.getElementById('pauseOverlay'), resumeBtn: document.getElementById('resumeBtn'), pauseHomeBtn: document.getElementById('pauseHomeBtn'), pauseBtn: document.getElementById('pauseBtn'), shopItems: document.getElementById('shopItems'), shopMoney: document.getElementById('shopMoney'), houseInfo: document.getElementById('houseInfo'),",
    1
)

# add paused state
s = s.replace(
    "let gameStarted = false, paused = false;",
    "let gameStarted = false, paused = false, pauseWanted = false;",
    1
)

# pause helpers
if 'function togglePause' not in s:
    pause_code = r'''
function togglePause(force) {
  if (!gameStarted || player.dead) return;
  if (!ui.shopModal.classList.contains('hidden') || !ui.houseModal.classList.contains('hidden')) return;
  pauseWanted = typeof force === 'boolean' ? force : !pauseWanted;
  ui.pauseOverlay.classList.toggle('hidden', !pauseWanted);
  if (!pauseWanted) clock.getDelta();
}
'''
    s = s.replace('function showMenu() {', pause_code + 'function showMenu() {', 1)

# wire pause buttons after ui.saveBtn.onclick
old_wire = "ui.saveBtn.onclick = () => persist(true);"
new_wire = """ui.saveBtn.onclick = () => persist(true);
if (ui.pauseBtn) ui.pauseBtn.onclick = () => togglePause();
if (ui.resumeBtn) ui.resumeBtn.onclick = () => togglePause(false);
if (ui.pauseHomeBtn) ui.pauseHomeBtn.onclick = () => { togglePause(false); player.position.set(-95,0,55); player.health = Math.max(player.health, 60); save.health = player.health; persist(); updateHUD(); toast('عدت للمخبأ الآمن'); };"""
if old_wire in s and 'ui.pauseBtn' not in s:
    s = s.replace(old_wire, new_wire, 1)

# key for pause
s = s.replace("  if (e.code === 'Escape') { closeModal('shopModal'); closeModal('houseModal'); }",
              "  if (e.code === 'KeyP') togglePause();\n  if (e.code === 'Escape') { if (pauseWanted) { togglePause(false); return; } closeModal('shopModal'); closeModal('houseModal'); }", 1)

# animate: respect pauseWanted
s = s.replace(
    "if (gameStarted) {\n    if (ui.shopModal.classList.contains('hidden') && ui.houseModal.classList.contains('hidden') && ui.gameOver.classList.contains('hidden')) {",
    "if (gameStarted) {\n    const modalOpen = !ui.shopModal.classList.contains('hidden') || !ui.houseModal.classList.contains('hidden') || !ui.gameOver.classList.contains('hidden') || pauseWanted;\n    if (!modalOpen) {",
    1
)

# sprint in updatePlayer
s = s.replace("  const speed = player.speed;", "  const sprinting = !!(input.keys['ShiftLeft'] || input.keys['ShiftRight']);\n  const speed = player.speed * (sprinting ? 1.7 : 1);", 1)

# draw mission marker on minimap
old_mm = """  // interactables
  for (const it of city.interactables) {
    ctx.fillStyle = it.type==='shop' ? '#60a5fa' : '#22c55e';
    ctx.beginPath(); ctx.arc(mapX(it.x), mapY(it.z), 4, 0, TAU); ctx.fill();
  }
  // enemies
  for (const e of enemies) { if(!e.alive) continue; ctx.fillStyle='#ef4444'; ctx.fillRect(mapX(e.mesh.position.x)-2, mapY(e.mesh.position.z)-2,4,4); }"""
new_mm = """  // mission
  if (mission && mission.center) { ctx.fillStyle = '#f59e0b'; ctx.beginPath(); ctx.arc(mapX(mission.center.x), mapY(mission.center.z), 5, 0, Math.PI*2); ctx.fill(); }
  // interactables
  for (const it of city.interactables) {
    ctx.fillStyle = it.type==='shop' ? '#60a5fa' : '#22c55e';
    ctx.beginPath(); ctx.arc(mapX(it.x), mapY(it.z), 4, 0, Math.PI*2); ctx.fill();
  }
  // enemies
  for (const e of enemies) { if(!e.alive) continue; ctx.fillStyle='#ef4444'; ctx.fillRect(mapX(e.mesh.position.x)-2, mapY(e.mesh.position.z)-2,4,4); }"""
if old_mm in s:
    s = s.replace(old_mm, new_mm, 1)

p.write_text(s, encoding='utf-8')
print('ok')
