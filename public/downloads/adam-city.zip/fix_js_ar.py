from pathlib import Path
import re
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')
s = s.replace(' (????? ?????? ???)', ' (أعداء مسلحون فقط)')
s = s.replace('??????</div><div class="value">$' , 'الفلوس</div><div class="value">$')
s = s.replace('???????</div><div class="value">\' + save.stats.missions + \'</div></div>' , 'المهمات</div><div class="value">\' + save.stats.missions + \'</div></div>')
s = s.replace('??????</div><div class="value">Lv ' , 'المخبأ</div><div class="value">Lv ')
s = re.sub(r"toast\('U,O USU\^O�O_ O'USO� U,U,O�U\?OO1U, U\.O1U� U�U\+O'\);", "toast('لا يوجد شيء للتفاعل معه هنا');", s)
# generic: fix the specific interact toast if still garbled
s = re.sub(r"if \(!it\) \{ toast\('[^']+'\); return; \}", "if (!it) { toast('لا يوجد شيء للتفاعل معه هنا'); return; }", s)
# heal
s = re.sub(r"if \(save\.money < 50\) \{ toast\('[^']*50\$[^']*'\); return; \}", "if (save.money < 50) { toast('تحتاج 50$ للاستشفاء'); return; }", s)
s = re.sub(r"renderHouse\(\); toast\('[^']*'\);\n\};\nui\.saveBtn\.onclick", "renderHouse(); toast('تم الاستشفاء');\n};\nui.saveBtn.onclick", s)
p.write_text(s, encoding='utf-8')
print('ok')
