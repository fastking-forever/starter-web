from pathlib import Path
import re
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')
s = re.sub(r"ui\.missionDesc\.textContent = mission\.desc \+ ' \([^']*\)';", "ui.missionDesc.textContent = mission.desc + ' (أعداء مسلحون فقط)';", s)
s = re.sub(r"ui\.missionProgress\.textContent = mission\.done \? '[^']*' \+ mission\.reward : '[^']*' \+ mission\.killed \+ '/' \+ mission\.count \+ ' \| [^']*' \+ mission\.reward;", "ui.missionProgress.textContent = mission.done ? 'مكتملة! +$' + mission.reward : 'التقدم: ' + mission.killed + '/' + mission.count + ' | المكافأة: $' + mission.reward;", s)
s = re.sub(r"ui\.ammoText\.textContent = ammo === Infinity \? '[^']*' : '' \+ ammo;", "ui.ammoText.textContent = ammo === Infinity ? '∞' : '' + ammo;", s)
s = re.sub(r"'<div class=\"menu-stat\"><div class=\"label\">[^<]*</div><div class=\"value\">\$' \+ save\.money \+ '</div></div>' \+", "'<div class=\"menu-stat\"><div class=\"label\">الفلوس</div><div class=\"value\">$' + save.money + '</div></div>' +", s)
s = re.sub(r"'<div class=\"menu-stat\"><div class=\"label\">[^<]*</div><div class=\"value\">' \+ save\.stats\.missions \+ '</div></div>' \+", "'<div class=\"menu-stat\"><div class=\"label\">المهمات</div><div class=\"value\">' + save.stats.missions + '</div></div>' +", s)
s = re.sub(r"'<div class=\"menu-stat\"><div class=\"label\">[^<]*</div><div class=\"value\">Lv ' \+ save\.houseLevel \+ '</div></div>';", "'<div class=\"menu-stat\"><div class=\"label\">المخبأ</div><div class=\"value\">Lv ' + save.houseLevel + '</div></div>';", s)
s = re.sub(r"if \(!it\) \{ toast\('[^']*'\); return; \}\n  if \(it\.type === 'shop'\)", "if (!it) { toast('لا يوجد شيء للتفاعل معه هنا'); return; }\n  if (it.type === 'shop')", s)
s = re.sub(r"if \(ammo !== Infinity && ammo <= 0\) \{ toast\('[^']*'\); return; \}\n  player\.lastShot", "if (ammo !== Infinity && ammo <= 0) { toast('لا توجد ذخيرة'); return; }\n  player.lastShot", s)
p.write_text(s, encoding='utf-8')
print('ok')
