from pathlib import Path
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')
# fix the two mangled heal/save toasts
s = s.replace("toast('O�O-O�OO� $50 U,U,OO3O�O'U?OO�'); return; }", "toast('تحتاج 50$ للاستشفاء'); return; }")
# try alternate form
import re
s = re.sub(r"toast\('[^']*\$50[^']*'\); return; \}", "toast('تحتاج 50$ للاستشفاء'); return; }", s)
s = re.sub(r"toast\('[^']*OU,OO3O�O'U?OO�[^']*'\);", "toast('تم الاستشفاء');", s)
# general: replace remaining mojibake-like Arabic in toasts/UI with safe text? better fix specific known ones
known = {
    "toast('O�O�O1 O%U,O% OU,U.OrO\"O� OU,O�U.U+')": "toast('عدت إلى المخبأ الآمن')",
    "toast('+35$  O�U. O%O3U,OO� U�O_U? U.O3U,O-')": "toast('+35$ - تم إسقاط هدف مسلح')",
    "toast('U.O�U.U�Oc O,O_USO_Oc: ' + def.title)": "toast('مهمة جديدة: ' + def.title)",
    "toast(`OU�O�U.U,O� OU,U.U�U.U�Oc! +$${mission.reward}`)": "toast(`اكتملت المهمة! +$${mission.reward}`)",
    "toast('U.O�O-O\"O\"O O\"U� U?US ADAM: City Ops')": "toast('مرحبًا بك في ADAM: City Ops')",
    "toast('U,O USU^O,O_ O�USO� U,U,O�U?OO1U, U.O1U� U�U+O')": "toast('لا يوجد شيء للتفاعل معه هنا')",
    "toast('O�O�USO_U� O:USO� U�OU?US')": "toast('رصيدك غير كافٍ')",
    "toast('O�U. O'O�OO� ' + item.name)": "toast('تم شراء ' + item.name)",
    "toast('O�U. O'O�OO� OU,O_O�O1')": "toast('تم شراء الدرع')",
    "toast('O�U.O� O�O1O\"O�Oc OU,O�OrUSO�Oc')": "toast('تمت تعبئة الذخيرة')",
    "toast('O�U.O� O�O�U,USOc OU,U.OrO\"O�')": "toast('تمت ترقية المخبأ')",
    "toast('U,O O�U^O,O_ O�OrUSO�Oc')": "toast('لا توجد ذخيرة')",
    "toast('U.O3O_O3 - O�OrUSO�Oc O:USO� U.O-O_U^O_Oc')": "toast('مسدس - ذخيرة غير محدودة')",
    "toast('O�U.O� O%O1OO_Oc OU,O�O1O\"O�Oc')": "toast('تمت إعادة التعبئة')",
    "toast('OU,O3U,OO-: ' + currentWeapon().name)": "toast('السلاح: ' + currentWeapon().name)",
    "ui.interactBtn.textContent = it.type === 'shop' ? 'OU,U.U�O,O�' : 'OU,U.OrO\"O�';": "ui.interactBtn.textContent = it.type === 'shop' ? 'المتجر' : 'المخبأ';",
    "else ui.interactBtn.textContent = 'O�U?OO1U,';": "else ui.interactBtn.textContent = 'تفاعل';",
}
for k,v in known.items():
    if k in s: s=s.replace(k,v)
# houseInfo labels
s = s.replace("'>U.O3O�U^U% OU,U.OrO\"O�</span>", "'>مستوى المخبأ</span>")
s = s.replace("'>OO3O�O'U?OO� U.O�OO-</span>", "'>استشفاء متاح</span>")
s = s.replace("'>OU,O�O3U,O-Oc OU,U.U.U,U^U�Oc</span>", "'>الأسلحة المملوكة</span>")
s = s.replace("'>OU,U.U^U,U1</span>", "'>الموقع</span>")
s = s.replace("<strong>OU,O-US UOU,O�OO�</strong>", "<strong>الحي الأخضر</strong>")
s = s.replace("O�O-Oc", "صحة") # استشفاء متاح ... صحة
# mission
s = s.replace("title: 'O�O�U�USO� U+U,U�Oc OU,O1O�OO\"Oc'", "title: 'تطهير نقطة العصابة'")
s = s.replace("desc: 'OU,OU� U1U,U% 3 U.U+ O1U+OO�O� OU,O1O�OO\"Oc OU,U.O3U,U-Oc U?US OU,O3OO-Oc OU,O'U.OU,USOc.'", "desc: 'اقضِ على 3 من عناصر العصابة المسلحة في الساحة الشمالية.'")
s = s.replace("title: 'O-U.OUSOc O�O�USU, OU,O%U.O_OO_'", "title: 'حماية طريق الإمداد'")
s = s.replace("desc: 'O�U?U� 4 U.O3U,U-USU+ USO-OU^U,U^U+ OU,O3USO�O�Oc O1U,U% OU,O�U,OO�O1 OU,O'O�U,US.'", "desc: 'صفِّ 4 مسلحين يحاولون السيطرة على التقاطع الشرقي.'")
s = s.replace("title: 'OU,O�O-OU. U^U�O� OU,O3U,OO-'", "title: 'اقتحام وكر السلاح'")
s = s.replace("desc: 'OU,O�O-O.U. OU,U.U+O�U,Oc OU,O,U+U^O\"USOc U^OO�U, 5 U.U+ O-O�OO3 OU,O1O�OO\"Oc.'", "desc: 'اقتحم المنطقة الجنوبية وأزل 5 من حراس العصابة.'")
s = s.replace("title: 'O1U.U,USOc OU,U.O_USU+Oc'", "title: 'عملية المدينة'")
s = s.replace("desc: 'U^OO,U� 6 U.O3U,U-USU+ U?US U.U+O�U,Oc O�U+OO1USOc O:O�O\" OU,U.O_USU+Oc.'", "desc: 'واجه 6 مسلحين في منطقة صناعية غرب المدينة.'")
# UI strings
s = s.replace("'U.O.OrO\"O� OU,O�U.U+'", "'المخبأ الآمن'")
s = s.replace("'U.O�O,O� OU,O�O3U,O-Oc'", "'متجر الأسلحة'")
# fallback: any remaining long mojibake in JS strings - replace chars commonly seen
p.write_text(s, encoding='utf-8')
print('ok')
