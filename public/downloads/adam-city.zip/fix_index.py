from pathlib import Path
import re
p = Path('adam-city/index.html')
s = p.read_text(encoding='utf-8')

repls = {
    '???? ???????': 'اسحب للتصويب',
}
for k,v in repls.items():
    s = s.replace(k,v)

s = re.sub(r'<div class="desktop-hint" id="desktopHint">.*?</div>', '<div class="desktop-hint" id="desktopHint">WASD حركة • الفأرة تصويب • زر أيسر إطلاق • E تفاعل • R إعادة تعبئة • Q تبديل سلاح</div>', s, flags=re.DOTALL)
s = re.sub(r'<p class="menu-text">[^<]*?????[^<]*</p>', '<p class="menu-text">مدينة مفتوحة ثلاثية الأبعاد. نفّذ المهام، واجه العصابات المسلحة، اجمع المكافآت، طوّر أسلحتك، وامتلك مخبأك الخاص. تعمل على المتصفح والموبايل.</p>', s, count=1)
s = s.replace('>???? ?????</button>', '>ابدأ اللعب</button>')
s = s.replace('>??? ??????</button>', '>مسح التقدم</button>', 1)
s = s.replace('اللعبة تركز على مهام أكشن ضد أهداف مسلحة/عصابات فقط.' if 'اللعبة تركز على مهام أكشن ضد أهداف مسلحة/عصابات فقط.' in s else '?????? ???? ??? ???? ???? ?? ????? ?????/?????? ???.', 'اللعبة تركز على مهام أكشن ضد أهداف مسلحة/عصابات فقط.')
s = s.replace('<h2>??????</h2>', '<h2>المتجر</h2>')
s = s.replace('<h2>?????? ?????</h2>', '<h2>المخبأ الآمن</h2>')
# close buttons
s = s.replace('<button class="close-btn" data-close="shopModal">?????</button>', '<button class="close-btn" data-close="shopModal">إغلاق</button>')
s = s.replace('<button class="close-btn" data-close="houseModal">?????</button>', '<button class="close-btn" data-close="houseModal">إغلاق</button>')
s = s.replace('>??????? ($50)</button>', '>استشفاء ($50)</button>')
s = s.replace('<button id="saveBtn" class="secondary-btn">??? ??????</button>', '<button id="saveBtn" class="secondary-btn">حفظ التقدم</button>')
s = s.replace('<h2>???? ?? ??????</h2>', '<h2>سقطت في المهمة</h2>')
s = s.replace('?? ???? ?????? ?????. ???? ????? ?????? ?? ???????? ??? ?????? ??????.', 'تم نقلك للمخبأ الآمن. خسرت جزءًا بسيطًا من المكافأة لكن معداتك محفوظة.')
s = s.replace('>?????? ??????</button>', '>العودة للمخبأ</button>')
# action buttons
s = s.replace('<button class="action-btn shoot" id="shootBtn">?????</button>', '<button class="action-btn shoot" id="shootBtn">إطلاق</button>')
s = s.replace('<button class="action-btn" id="reloadBtn">?????</button>', '<button class="action-btn" id="reloadBtn">ذخيرة</button>')
s = s.replace('<button class="action-btn" id="interactBtn">?????</button>', '<button class="action-btn" id="interactBtn">تفاعل</button>')
s = s.replace('<button class="action-btn" id="weaponBtn">????</button>', '<button class="action-btn" id="weaponBtn">سلاح</button>')
# hud labels - order matters
s = s.replace('<div class="stat-label">?????</div>\n          <div class="bar"><div id="healthBar"', '<div class="stat-label">الصحة</div>\n          <div class="bar"><div id="healthBar"', 1)
s = s.replace('<div class="stat-label">?????</div>\n          <div class="bar"><div id="armorBar"', '<div class="stat-label">الدرع</div>\n          <div class="bar"><div id="armorBar"', 1)
s = s.replace('<div class="stat-label">??????</div>\n          <div id="moneyText"', '<div class="stat-label">الفلوس</div>\n          <div id="moneyText"', 1)
s = s.replace('<div class="stat-label">??????</div>\n          <div id="weaponText"', '<div class="stat-label">السلاح</div>\n          <div id="weaponText"', 1)
s = s.replace('<div id="weaponText" class="stat-value">????</div>', '<div id="weaponText" class="stat-value">مسدس</div>')
s = s.replace('<div class="panel-title">?????? ???????</div>', '<div class="panel-title">المهمة الحالية</div>')
s = s.replace('<div class="panel-title">???????</div>', '<div class="panel-title">الخريطة</div>')
# error messages
s = re.sub(r"msg = 'Script error \(.*?\)';", "msg = 'Script error (غالبًا الملف اتفتح بطريقة بتمنع قراءة تفاصيل الخطأ). جرّب افتح http://127.0.0.1:8081 أو تأكد إن three.min.js و game.js موجودين.';", s)
s = re.sub(r"window\.__showErr\('[^']*index\.html[^']*'\); \} \}, 7000\);", "window.__showErr('لم يتم تحميل اللعبة. تأكد أن ملفات three.min.js و game.js موجودة بجانب index.html.'); } }, 7000);", s)
s = re.sub(r"onerror=\"window\.__showErr\('[^']*three\.min\.js[^']*'\)\"", "onerror=\"window.__showErr('تعذر تحميل three.min.js. تأكد أن الملف موجود بجانب index.html')\"", s)
s = re.sub(r"onerror=\"window\.__showErr\('[^']*game\.js[^']*'\)\"", "onerror=\"window.__showErr('تعذر تحميل game.js. تأكد أن الملف موجود بجانب index.html')\"", s)
p.write_text(s, encoding='utf-8')
print('ok')
