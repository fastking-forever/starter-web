from pathlib import Path
import re
p = Path('adam-city/index.html')
s = p.read_text(encoding='utf-8')
# Replace the garbled menu text
s = re.sub(r'<p class="menu-text">.*?</p>', '<p class="menu-text">مدينة مفتوحة ثلاثية الأبعاد. نفّذ المهام، واجه العصابات المسلحة، اجمع المكافآت، طوّر أسلحتك، وامتلك مخبأك الخاص. تعمل على المتصفح والموبايل.</p>', s, count=1)
p.write_text(s, encoding='utf-8')
print('ok')
