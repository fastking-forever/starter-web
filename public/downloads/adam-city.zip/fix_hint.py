from pathlib import Path
import re
p = Path('adam-city/index.html')
s = p.read_text(encoding='utf-8')
s = re.sub(r'<div class="desktop-hint" id="desktopHint">.*?</div>', '<div class="desktop-hint" id="desktopHint">WASD حركة • Shift ركض • الفأرة تصويب • زر أيسر إطلاق • E تفاعل • R إعادة تعبئة • Q تبديل سلاح • P إيقاف مؤقت</div>', s, flags=re.DOTALL)
p.write_text(s, encoding='utf-8')
print('ok')
