from pathlib import Path

p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')

# Replace corrupted Arabic strings by their positions/patterns
replacements = [
    ("name: 'U.O3O_O3'", "name: 'مسدس'"),
    ("name: 'O\"U+O_U,USOc'", "name: 'بندقية'"),
    ("desc: 'O3U,OO- O3O�USO1 U.U+OO3O\" U,U,OO'O�O\"OO�OO� OU,U,O�USO\"Oc.'", "desc: 'سلاح سريع مناسب للاشتباكات القريبة.'"),
    ("name: 'O\"U+O_U,USOc O�U�O�USU�USOc', desc: 'OO�O� O�O1U,U% U^U.O_U% O�O�U^U, U,U.U�OU. OU,O1O�OO\"OO�.'", "name: 'بندقية تكتيكية', desc: 'ضرر أعلى ومدى أطول لمهام العصابات.'"),
    ("name: 'O_O�O1 OrU?USU?', desc: 'USO�USO_ OU,O-U.OUSOc O-O�U% 100.'", "name: 'درع خفيف', desc: 'يزيد الحماية حتى 100.'"),
    ("name: 'O�OrUSO�Oc O�OOU?USOc', desc: 'USO1USO_ O�O1O\"O�Oc O�OrUSO�Oc OU,O�O3U,O-Oc OU,O�US O�U.U,U�U�O.'", "name: 'ذخيرة إضافية', desc: 'يعيد تعبئة ذخيرة الأسلحة التي تملكها.'"),
    ("name: 'O�O�U,USOc OU,U.OrO\"O�', desc: 'USO-O3U+ OU,OO3O�O'U?OO� U^USO�USO_ U.U�OU?O�Oc O-U?O, OU,O�U.OU+.'", "name: 'ترقية المخبأ', desc: 'يحسن الاستشفاء ويزيد مكافأة حفظ الأمان.'"),
    ("toast('O�U. O-U?O, OU,O�U,O_U.');", "toast('تم حفظ التقدم');"),
    ("toast('O�U. O-U?O, OU,O�U,O_U.')", "toast('تم حفظ التقدم')"),
]
for old,new in replacements:
    if old in s:
        s = s.replace(old,new)
        print('ok')
    else:
        print('miss')

# generic pass: fix remaining obvious ones by regex for common toast labels
# Also fix UI labels in HTML
p.write_text(s, encoding='utf-8')
print('done')
