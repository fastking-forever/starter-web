from pathlib import Path

p = Path('adam-city/game.js')
p.write_text("""import * as THREE from 'three';

const STORAGE_KEY = 'adam_city_ops_v1';
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a, b) => a + Math.random() * (b - a);
const choice = (arr) => arr[Math.floor(Math.random() * arr.length)];

const WEAPONS = [
  { id: 'pistol', name: 'مسدس', price: 0, damage: 18, fireRate: 320, range: 70, auto: false, ammo: Infinity, color: 0xfcd34d },
  { id: 'smg', name: 'SMG', price: 450, damage: 12, fireRate: 110, range: 65, auto: true, ammo: 120, color: 0x60a5fa },
  { id: 'rifle', name: 'بندقية', price: 900, damage: 28, fireRate: 180, range: 110, auto: true, ammo: 90, color: 0xf97316 },
];
const SHOP_ITEMS = [
  { id: 'smg', kind: 'weapon', name: 'SMG', desc: 'سلاح سريع مناسب للاشتباكات القريبة.', price: 450 },
  { id: 'rifle', kind: 'weapon', name: 'بندقية تكتيكية', desc: 'ضرر أعلى ومدى أطول لمهام العصابات.', price: 900 },
  { id: 'armor', kind: 'armor', name: 'درع خفيف', desc: 'يزيد الحماية حتى 100.', price: 200 },
  { id: 'ammo', kind: 'ammo', name: 'ذخيرة إضافية', desc: 'يعيد تعبئة ذخيرة الأسلحة التي تملكها.', price: 120 },
  { id: 'house', kind: 'house', name: 'ترقية المخبأ', desc: 'يحسن الاستشفاء ويزيد مكافأة حفظ الأمان.', price: 700 },
];

const DEFAULT_SAVE = () => ({
  money: 150, health: 100, armor: 0,
  ownedWeapons: ['pistol'], equipped: 'pistol',
  ammo: { pistol: Infinity, smg: 90, rifle: 60 },
  houseLevel: 1, missionIndex: 0,
  stats: { earned: 0, kills: 0, missions: 0 },
  position: { x: 0, z: 18 },
});

let save = loadSave();
function loadSave() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SAVE();
    const p = JSON.parse(raw);
    return { ...DEFAULT_SAVE(), ...p, ammo: { ...DEFAULT_SAVE().ammo, ...(p.ammo || {}) }, stats: { ...DEFAULT_SAVE().stats, ...(p.stats || {}) }, position: { ...DEFAULT_SAVE().position, ...(p.position || {}) } };
  } catch { return DEFAULT_SAVE(); }
}
function persist(showToastMsg = false) {
  save.position = { x: player.position.x, z: player.position.z };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
  if (showToastMsg) toast('تم حفظ التقدم');
}

const ui = {
  menu: document.getElementById('menu'), hud: document.getElementById('hud'), menuStats: document.getElementById('menuStats'),
  startBtn: document.getElementById('startBtn'), resetBtn: document.getElementById('resetBtn'), respawnBtn: document.getElementById('respawnBtn'),
  healthBar: document.getElementById('healthBar'), armorBar: document.getElementById('armorBar'), healthText: document.getElementById('healthText'), armorText: document.getElementById('armorText'),
  moneyText: document.getElementById('moneyText'), weaponText: document.getElementById('weaponText'), ammoText: document.getElementById('ammoText'),
  missionTitle: document.getElementById('missionTitle'), missionDesc: document.getElementById('missionDesc'), missionProgress: document.getElementById('missionProgress'),
  toast: document.getElementById('toast'), hitMarker: document.getElementById('hitMarker'), damageOverlay: document.getElementById('damageOverlay'),
  shopModal: document.getElementById('shopModal'), houseModal: document.getElementById('houseModal'), shopItems: document.getElementById('shopItems'), shopMoney: document.getElementById('shopMoney'), houseInfo: document.getElementById('houseInfo'),
  healBtn: document.getElementById('healBtn'), saveBtn: document.getElementById('saveBtn'), minimap: document.getElementById('minimap'),
  moveZone: document.getElementById('moveZone'), moveKnob: document.getElementById('moveKnob'), lookPad: document.getElementById('lookPad'),
  shootBtn: document.getElementById('shootBtn'), reloadBtn: document.getElementById('reloadBtn'), interactBtn: document.getElementById('interactBtn'), weaponBtn: document.getElementById('weaponBtn'),
};
const mmCtx = ui.minimap.getContext('2d');

const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('game'), antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);
scene.fog = new THREE.Fog(0x87ceeb, 90, 320);
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 500);
const clock = new THREE.Clock();
scene.add(new THREE.HemisphereLight(0xdbeafe, 0x3f6212, 1.15));
const dir = new THREE.DirectionalLight(0xfff1c1, 1.35);
dir.position.set(80, 120, 40); dir.castShadow = true;
dir.shadow.mapSize.set(2048, 2048);
dir.shadow.camera.left = -140; dir.shadow.camera.right = 140; dir.shadow.camera.top = 140; dir.shadow.camera.bottom = -140; dir.shadow.camera.far = 350;
scene.add(dir);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), new THREE.MeshStandardMaterial({ color: 0x4b5563, roughness: 1 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
const grass = new THREE.Mesh(new THREE.PlaneGeometry(700, 700), new THREE.MeshStandardMaterial({ color: 0x365314, roughness: 1 }));
grass.rotation.x = -Math.PI / 2; grass.position.y = -0.02; grass.receiveShadow = true; scene.add(grass);

const city = { colliders: [], buildings: [], interactables: [], bounds: 180 };
const raycaster = new THREE.Raycaster();
const tmpVec = new THREE.Vector3();
const player = { position: new THREE.Vector3(save.position.x, 0, save.position.z), velocity: new THREE.Vector3(), yaw: 0, pitch: 0.18, radius: 0.8, speed: 12, sprint: 1, health: save.health, armor: save.armor, dead: false, lastShot: 0, invuln: 0 };
const input = { keys: {}, moveX: 0, moveY: 0, lookDX: 0, lookDY: 0, shooting: false, touchLookId: null, lastLook: null };
let gameStarted = false, paused = false;
let enemies = [], bullets = [], particles = [], mission = null;
let toastTimer = 0;
""", encoding='utf-8')
print('ok')
