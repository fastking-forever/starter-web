from pathlib import Path
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')
# The corruption happened: UTF-8 bytes were interpreted as cp1252/latin1 then re-encoded badly? 
# Or simply PowerShell wrote them wrong. Let's just replace all non-ascii-garbled sequences in known contexts.
# Simpler: replace by line patterns.
import re
lines = s.splitlines()
out = []
for line in lines:
    # weapon names
    if "id: 'pistol'" in line and 'name:' in line:
        line = re.sub(r"name: '[^']*'", "name: 'مسدس'", line, count=1)
    if "id: 'rifle'" in line and 'name:' in line and 'WEAPONS' not in line and 'SHOP' not in line and 'بندقية' not in line:
        line = re.sub(r"name: '[^']*'", "name: 'بندقية'", line, count=1)
    out.append(line)
s = '\n'.join(out)
# Direct known fixes using unicode escapes to be safe
fixes = {
    "name: 'بندقية تكتيكية', desc: 'ضرر أعلى ومدى أطول لمهام العصابات.'": "name: 'بندقية تكتيكية', desc: 'ضرر أعلى ومدى أطول لمهام العصابات.'",
}
# Better: just fix by known bad fragments
bad_good = [
    ("'U.O3O_O3'", "'مسدس'"),
    ("'O\"U+O_U,USOc'", "'بندقية'"),
]
for b,g in bad_good:
    if b in s: s=s.replace(b,g); print('r',b)
# Fix shop descriptions by reconstructing SHOP_ITEMS block
old_shop = '''const SHOP_ITEMS = [
  { id: 'smg', kind: 'weapon', name: 'SMG', desc: 'O3U,OO- O3O�USO1 U.U+OO3O" U,U,OO\'O�O"OO�OO� OU,U,O�USO"Oc.', price: 450 },
  { id: 'rifle', kind: 'weapon', name: 'بندقية تكتيكية', desc: 'OO�O� O�O1U,U% U^U.O_U% O�O�U^U, U,U.U�OU. OU,O1O�OO"OO�.', price: 900 },
  { id: 'armor', kind: 'armor', name: 'O_O�O1 OrU?USU?', desc: 'USO�USO_ OU,O-U.OUSOc O-O�U% 100.', price: 200 },
  { id: 'ammo', kind: 'ammo', name: 'O�OrUSO�Oc O�OOU?USOc', desc: 'USO1USO_ O�O1O"O�Oc O�OrUSO�Oc OU,O�O3U,O-Oc OU,O�US O�U.U,U�U�O.', price: 120 },
  { id: 'house', kind: 'house', name: 'O�O�U,USOc OU,U.OrO"O�', desc: 'USO-O3U+ OU,OO3O�O\'U?OO� U^USO�USO_ U.U�OU?O�Oc O-U?O, OU,O�U.OU+.', price: 700 },
];'''
new_shop = '''const SHOP_ITEMS = [
  { id: 'smg', kind: 'weapon', name: 'SMG', desc: 'سلاح سريع مناسب للاشتباكات القريبة.', price: 450 },
  { id: 'rifle', kind: 'weapon', name: 'بندقية تكتيكية', desc: 'ضرر أعلى ومدى أطول لمهام العصابات.', price: 900 },
  { id: 'armor', kind: 'armor', name: 'درع خفيف', desc: 'يزيد الحماية حتى 100.', price: 200 },
  { id: 'ammo', kind: 'ammo', name: 'ذخيرة إضافية', desc: 'يعيد تعبئة ذخيرة الأسلحة التي تملكها.', price: 120 },
  { id: 'house', kind: 'house', name: 'ترقية المخبأ', desc: 'يحسن الاستشفاء ويزيد مكافأة حفظ الأمان.', price: 700 },
];'''
if old_shop in s:
    s = s.replace(old_shop, new_shop); print('shop ok')
else:
    print('shop miss')
# toast save
s = s.replace("toast('O�U. O-U?O, OU,O�U,O_U.');", "toast('تم حفظ التقدم');")
s = s.replace("toast('O�U. O-U?O, OU,O�U,O_U.')", "toast('تم حفظ التقدم')")
p.write_text(s, encoding='utf-8')
print('done')
