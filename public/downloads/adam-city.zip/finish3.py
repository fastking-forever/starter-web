from pathlib import Path
rest = r'''
// Input
window.addEventListener('keydown', e => {
  input.keys[e.code] = true;
  if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.code === 'KeyE') tryInteract();
  if (e.code === 'KeyR') reload();
  if (e.code === 'KeyQ') cycleWeapon();
  if (e.code === 'Escape') { closeModal('shopModal'); closeModal('houseModal'); }
});
window.addEventListener('keyup', e => { input.keys[e.code] = false; });

function reload() {
  const w = currentWeapon();
  if (w.id === 'pistol') { toast('مسدس - ذخيرة غير محدودة'); return; }
  save.ammo[w.id] = w.ammo;
  updateHUD(); persist(); toast('تمت إعادة التعبئة');
}
function cycleWeapon() {
  const owned = save.ownedWeapons;
  const idx = owned.indexOf(save.equipped);
  equipWeapon(owned[(idx + 1) % owned.length]);
  toast('السلاح: ' + currentWeapon().name);
}

document.addEventListener('mousedown', e => {
  if (!gameStarted) return;
  if (e.button === 0) { input.shooting = true; shoot(); }
});
document.addEventListener('mouseup', e => { if (e.button === 0) input.shooting = false; });
document.addEventListener('mousemove', e => {
  if (!gameStarted) return;
  if (document.pointerLockElement === renderer.domElement) {
    input.lookDX += e.movementX; input.lookDY += e.movementY;
  }
});
renderer.domElement.addEventListener('click', () => {
  if (!gameStarted) return;
  if (window.matchMedia('(pointer: fine)').matches) renderer.domElement.requestPointerLock?.();
});

ui.startBtn.onclick = startGame;
ui.resetBtn.onclick = resetSave;
ui.respawnBtn.onclick = respawn;
ui.healBtn.onclick = () => {
  if (save.money < 50) { toast('تحتاج $50 للاستشفاء'); return; }
  save.money -= 50; player.health = Math.min(100, player.health + 50 + (save.houseLevel-1)*10); save.health = player.health;
  persist(); updateHUD(); renderHouse(); toast('تم الاستشفاء');
};
ui.saveBtn.onclick = () => persist(true);

// Mobile controls
function setMoveFromTouch(t) {
  const rect = ui.moveZone.getBoundingClientRect();
  const cx = rect.left + rect.width/2, cy = rect.top + rect.height/2;
  const dx = t.clientX - cx, dy = t.clientY - cy;
  const max = rect.width * 0.28;
  const d = Math.hypot(dx,dy); const k = d > max ? max/d : 1;
  const nx = dx*k, ny = dy*k;
  ui.moveKnob.style.left = (rect.width/2 - 32 + nx) + 'px';
  ui.moveKnob.style.top = (rect.height/2 - 32 + ny) + 'px';
  input.moveX = clamp(nx/max, -1, 1);
  input.moveY = clamp(ny/max, -1, 1);
}
function resetMove() { ui.moveKnob.style.left = 'calc(50% - 32px)'; ui.moveKnob.style.top = 'calc(50% - 32px)'; input.moveX=0; input.moveY=0; }

ui.moveZone.addEventListener('touchstart', e => { e.preventDefault(); setMoveFromTouch(e.changedTouches[0]); }, {passive:false});
ui.moveZone.addEventListener('touchmove', e => { e.preventDefault(); setMoveFromTouch(e.changedTouches[0]); }, {passive:false});
ui.moveZone.addEventListener('touchend', e => { e.preventDefault(); resetMove(); }, {passive:false});
ui.moveZone.addEventListener('touchcancel', resetMove);

ui.lookPad.addEventListener('touchstart', e => { e.preventDefault(); const t=e.changedTouches[0]; input.touchLookId=t.identifier; input.lastLook={x:t.clientX,y:t.clientY}; }, {passive:false});
ui.lookPad.addEventListener('touchmove', e => {
  e.preventDefault();
  for (const t of e.changedTouches) {
    if (t.identifier === input.touchLookId && input.lastLook) {
      input.lookDX += (t.clientX - input.lastLook.x) * 1.3;
      input.lookDY += (t.clientY - input.lastLook.y) * 1.3;
      input.lastLook = {x:t.clientX,y:t.clientY};
    }
  }
}, {passive:false});
ui.lookPad.addEventListener('touchend', e => { for (const t of e.changedTouches) if (t.identifier===input.touchLookId){ input.touchLookId=null; input.lastLook=null; } });

ui.shootBtn.addEventListener('touchstart', e=>{ e.preventDefault(); input.shooting=true; shoot(); }, {passive:false});
ui.shootBtn.addEventListener('touchend', e=>{ e.preventDefault(); input.shooting=false; }, {passive:false});
ui.shootBtn.addEventListener('mousedown', ()=>{ input.shooting=true; shoot(); });
ui.shootBtn.addEventListener('mouseup', ()=>{ input.shooting=false; });
ui.reloadBtn.onclick = reload;
ui.interactBtn.onclick = tryInteract;
ui.weaponBtn.onclick = cycleWeapon;

window.addEventListener('resize', () => {
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
});

buildCity();
spawnMission(save.missionIndex);
updateHUD(); updateMissionUI(); renderShop(); renderHouse(); showMenu();
animate();

window.addEventListener('beforeunload', () => persist());
setInterval(() => { if (gameStarted) persist(); }, 10000);
'''
Path('adam-city/game.js').write_text(Path('adam-city/game.js').read_text(encoding='utf-8') + rest, encoding='utf-8')
print('ok')
