from pathlib import Path
p = Path('adam-city/index.html')
s = p.read_text(encoding='utf-8')
pairs = [
    ('>???? ?????</button>','>ابدأ اللعب</button>'),
    ('?????? ???? ??? ???? ???? ?? ????? ?????/?????? ???.','اللعبة تركز على مهام أكشن ضد أهداف مسلحة/عصابات فقط.'),
    ('<h2>??????</h2>','<h2>المتجر</h2>'),
    ('<h2>?????? ?????</h2>','<h2>المخبأ الآمن</h2>'),
    ('<button class="close-btn" data-close="shopModal">?????</button>','<button class="close-btn" data-close="shopModal">إغلاق</button>'),
    ('<button class="close-btn" data-close="houseModal">?????</button>','<button class="close-btn" data-close="houseModal">إغلاق</button>'),
    ('>??????? ($50)</button>','>استشفاء ($50)</button>'),
    ('<button id="saveBtn" class="secondary-btn">??? ??????</button>','<button id="saveBtn" class="secondary-btn">حفظ التقدم</button>'),
    ('<h2>???? ?? ??????</h2>','<h2>سقطت في المهمة</h2>'),
    ('?? ???? ?????? ?????. ???? ????? ?????? ?? ???????? ??? ?????? ??????.','تم نقلك للمخبأ الآمن. خسرت جزءًا بسيطًا من المكافأة لكن معداتك محفوظة.'),
    ('>?????? ??????</button>','>العودة للمخبأ</button>'),
    ('<button class="action-btn shoot" id="shootBtn">?????</button>','<button class="action-btn shoot" id="shootBtn">إطلاق</button>'),
    ('<button class="action-btn" id="reloadBtn">?????</button>','<button class="action-btn" id="reloadBtn">ذخيرة</button>'),
    ('<button class="action-btn" id="interactBtn">?????</button>','<button class="action-btn" id="interactBtn">تفاعل</button>'),
    ('<button class="action-btn" id="weaponBtn">????</button>','<button class="action-btn" id="weaponBtn">سلاح</button>'),
    ('<div id="weaponText" class="stat-value">????</div>','<div id="weaponText" class="stat-value">مسدس</div>'),
    ('<div class="panel-title">?????? ???????</div>','<div class="panel-title">المهمة الحالية</div>'),
    ('<div class="panel-title">???????</div>','<div class="panel-title">الخريطة</div>'),
]
for a,b in pairs:
    s = s.replace(a,b)
# labels by surrounding context
s = s.replace('<div class="stat-label">?????</div>\n          <div class="bar"><div id="healthBar"', '<div class="stat-label">الصحة</div>\n          <div class="bar"><div id="healthBar"')
s = s.replace('<div class="stat-label">?????</div>\n          <div class="bar"><div id="armorBar"', '<div class="stat-label">الدرع</div>\n          <div class="bar"><div id="armorBar"')
s = s.replace('<div class="stat-label">??????</div>\n          <div id="moneyText"', '<div class="stat-label">الفلوس</div>\n          <div id="moneyText"')
s = s.replace('<div class="stat-label">??????</div>\n          <div id="weaponText"', '<div class="stat-label">السلاح</div>\n          <div id="weaponText"')
# menu buttons
s = s.replace('<button id="resetBtn" class="secondary-btn">??? ??????</button>', '<button id="resetBtn" class="secondary-btn">مسح التقدم</button>')
p.write_text(s, encoding='utf-8')
print('ok')
