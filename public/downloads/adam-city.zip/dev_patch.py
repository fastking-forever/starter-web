from pathlib import Path
import re

# HTML: add pause overlay and pause button
p = Path('adam-city/index.html')
s = p.read_text(encoding='utf-8')
if 'pauseOverlay' not in s:
    s = s.replace('    <div id="gameOver" class="overlay hidden">', '''    <div id="pauseOverlay" class="overlay hidden">
      <div class="menu-card">
        <h2>إيقاف مؤقت</h2>
        <p class="menu-text">اللعبة متوقفة. يمكنك استكمال اللعب أو العودة للمخبأ.</p>
        <div class="menu-actions">
          <button id="resumeBtn" class="primary-btn">استكمال</button>
          <button id="pauseHomeBtn" class="secondary-btn">العودة للمخبأ</button>
        </div>
      </div>
    </div>

    <div id="gameOver" class="overlay hidden">''', 1)
    # add pause button in HUD top area? easier add small button in action zone for mobile
    s = s.replace('<button class="action-btn" id="weaponBtn">سلاح</button>', '<button class="action-btn" id="weaponBtn">سلاح</button>\n            <button class="action-btn" id="pauseBtn">إيقاف</button>', 1)
    p.write_text(s, encoding='utf-8')
    print('html ok')
else:
    print('html skip')

# CSS: style for pauseBtn
pc = Path('adam-city/style.css')
cs = pc.read_text(encoding='utf-8')
if '#pauseBtn' not in cs:
    cs += '\n#pauseBtn { background: rgba(255,255,255,.12); }\n'
    pc.write_text(cs, encoding='utf-8')
    print('css ok')
else:
    print('css skip')
