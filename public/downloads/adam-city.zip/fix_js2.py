from pathlib import Path
p = Path('adam-city/game.js')
s = p.read_text(encoding='utf-8')
repls = {
    "ui.missionDesc.textContent = mission.desc + ' (O�O1O_OO� U.O3U,O-U^U+ U?U,O�)';": "ui.missionDesc.textContent = mission.desc + ' (أعداء مسلحون فقط)';",
    "ui.missionProgress.textContent = mission.done ? 'U.U�O�U.U,Oc! +$' + mission.reward : 'OU,O�U,O_U.: ' + mission.killed + '/' + mission.count + ' | OU,U.U�OU?O�Oc: $' + mission.reward;": "ui.missionProgress.textContent = mission.done ? 'مكتملة! +$' + mission.reward : 'التقدم: ' + mission.killed + '/' + mission.count + ' | المكافأة: $' + mission.reward;",
    "ui.ammoText.textContent = ammo === Infinity ? '�^z' : '' + ammo;": "ui.ammoText.textContent = ammo === Infinity ? '∞' : '' + ammo;",
}
for k,v in repls.items():
    if k in s: s=s.replace(k,v); print('ok')
    else: print('miss')
# line-based safer replaces
s=s.replace('OU,U?U,U^O3','الفلوس')
s=s.replace('OU,U.U�U.OO�','المهمات')
s=s.replace('OU,U.OrO"O�','المخبأ')
s=s.replace("toast('U,O USU^O�O_ O'USO� U,U,O�U?OO1U, U.O1U� U�U+O')","toast('لا يوجد شيء للتفاعل معه هنا')")
s=s.replace("toast('U,O O�U^O�O_ O�OrUSO�Oc')","toast('لا توجد ذخيرة')")
p.write_text(s,encoding='utf-8')
print('done')
