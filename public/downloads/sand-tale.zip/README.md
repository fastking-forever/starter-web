# حكاية الرمال — لعبة مغامرة RPG

لعبة مغامرة كاملة تعمل داخل المتصفح، مبنية بـ HTML/CSS/JS خالص بدون مكتبات أو ملفات خارجية.
مصممة لتُحوّل إلى تطبيق أندرويد (APK) لاحقًا بسهولة.

## التشغيل
افتح `index.html` في أي متصفح حديث. أو شغّل خادم محلي:

```bash
cd sand-tale
python -m http.server 8080
# ثم افتح http://localhost:8080
```

## التحكم
| الفعل | لوحة المفاتيح | الموبايل |
|---|---|---|
| التحرك | WASD / الأسهم | عصا التحرك يسار |
| الضرب | مسافة / J | زر ⚔ |
| السحر | K | زر ✨ |
| تحدث / افتح صندوق | E | زر 💬 |
| شرب جرعة | P | زر 🧪 |
| الحقيبة | I | — |
| إيقاف / حفظ | Esc | — |
| كتم الصوت | M | — |

## المحتوى
- 3 مناطق: القرية، الصحراء، الأطلال القديمة.
- أعداء: عقارب، قطاع طريق، سحرة، وزعيم (ساحر الرمال).
- نظام قتال، سحر، مستويات، خبرة، ذهب، جرعات، وحفظ تلقائي.
- مهمة متعددة المراحل + تاجر + صناديق كنز + حواراختيارات.
- مؤثرات صوتية وموسيقى مولّدة برمجيًا (بدون ملفات صوت).
- شاشة لمس للجوال + خريطة مصغّرة.

## هيكل الملفات
```
sand-tale/
├── index.html
├── manifest.json
├── css/style.css
├── js/
│   ├── utils.js      أدوات مساعدة
│   ├── audio.js      الصوت والموسيقى
│   ├── world.js      الخرائط والبلاطات
│   ├── entities.js   اللاعب، الأعداء، المقذوفات
│   ├── game.js       المحرك والواجهة والقصة
│   └── main.js       بدء التشغيل
└── README.md
```

## تحويلها إلى APK (Capacitor)
```bash
# من مجلد المشروع
npm init -y
npm i @capacitor/core @capacitor/cli
npx cap init "حكاية الرمال" com.example.sandtale --web-dir=.

npm i @capacitor/android
npx cap add android

# بعد أي تعديل في الملفات:
npx cap sync android

# بناء الـ APK (يحتاج Android Studio / Gradle):
cd android && ./gradlew assembleDebug
# الملف: android/app/build/outputs/apk/debug/app-debug.apk
```

> ملاحظة: تأكد من أن `webDir` يشير إلى المجلد الذي يحتوي `index.html` (هنا `.`).
> إذا نقلت الملفات إلى مجلد `www` غيّر `--web-dir=www` وانقل الملفات هناك.

## تخصيص اللعبة
- تعديل الخرائط: `js/world.js` في دوال `buildVillage/buildDesert/buildRuins`.
- تعديل الأعداء وأرقامهم: `ENEMY_TYPES` في `js/entities.js`.
- تعديل القصة والحوار: `talkTo()` و `questText()` في `js/game.js`.
- تعديل الألوان والواجهة: `css/style.css`.
