/* ================= Sound manager (Web Audio, no assets) ================= */
class SoundManager {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this.musicOn = true;
    this.musicTimer = null;
    this.step = 0;
    this.master = null;
  }

  init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }

  tone(freq, dur, type = 'sine', vol = 0.12, slide = 0, delay = 0) {
    if (!this.ctx || this.muted) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(gain); gain.connect(this.master);
    osc.start(t); osc.stop(t + dur + 0.02);
  }

  noise(dur, vol = 0.1) {
    if (!this.ctx || this.muted) return;
    const len = Math.floor(this.ctx.sampleRate * dur);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource(); src.buffer = buf;
    const gain = this.ctx.createGain(); gain.gain.value = vol;
    src.connect(gain); gain.connect(this.master); src.start();
  }

  play(name) {
    if (!this.ctx || this.muted) return;
    switch (name) {
      case 'swing':   this.noise(0.12, 0.09); this.tone(320, 0.1, 'triangle', 0.06, -180); break;
      case 'hit':     this.noise(0.09, 0.14); this.tone(150, 0.12, 'square', 0.07, -70); break;
      case 'hurt':    this.tone(220, 0.25, 'sawtooth', 0.12, -120); break;
      case 'magic':   this.tone(520, 0.25, 'sine', 0.1, 500); this.tone(780, 0.2, 'triangle', 0.05, 300, 0.03); break;
      case 'pickup':  this.tone(660, 0.09, 'sine', 0.1); this.tone(990, 0.12, 'sine', 0.08, 0, 0.07); break;
      case 'levelup': [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.22, 'triangle', 0.1, 0, i * 0.09)); break;
      case 'talk':    this.tone(440, 0.05, 'square', 0.04); this.tone(550, 0.05, 'square', 0.03, 0, 0.06); break;
      case 'portal':  this.tone(300, 0.5, 'sine', 0.1, 600); break;
      case 'potion':  this.tone(400, 0.3, 'sine', 0.1, 400); break;
      case 'die':     this.tone(300, 0.6, 'sawtooth', 0.12, -240); break;
      case 'victory': [523, 659, 784, 1046, 1318].forEach((f, i) => this.tone(f, 0.4, 'triangle', 0.12, 0, i * 0.14)); break;
    }
  }

  startMusic() {
    if (!this.ctx || this.musicTimer) return;
    const scale = [220, 261.63, 293.66, 329.63, 392, 440, 523.25];
    const melody = [0, 2, 4, 2, 3, 1, 0, 4, 5, 4, 2, 0, 1, 3, 2, 0];
    this.musicTimer = setInterval(() => {
      if (!this.musicOn || this.muted || !this.ctx) return;
      const n = melody[this.step % melody.length];
      this.tone(scale[n], 0.35, 'sine', 0.022);
      if (this.step % 4 === 0) this.tone(scale[0] / 2, 0.5, 'triangle', 0.025);
      this.step++;
    }, 420);
  }

  stopMusic() { if (this.musicTimer) { clearInterval(this.musicTimer); this.musicTimer = null; } }

  toggleMute() { this.muted = !this.muted; return this.muted; }
  toggleMusic() { this.musicOn = !this.musicOn; return this.musicOn; }
}
