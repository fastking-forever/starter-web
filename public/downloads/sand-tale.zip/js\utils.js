/* ================= Utilities ================= */
const U = {
  clamp(v, a, b) { return Math.max(a, Math.min(b, v)); },
  lerp(a, b, t) { return a + (b - a) * t; },
  rand(a, b) { return a + Math.random() * (b - a); },
  randInt(a, b) { return Math.floor(this.rand(a, b + 1)); },
  choice(arr) { return arr[Math.floor(Math.random() * arr.length)]; },
  dist(ax, ay, bx, by) { return Math.hypot(ax - bx, ay - by); },
  aabb(a, b) {
    return Math.abs(a.x - b.x) * 2 < (a.w + b.w) &&
           Math.abs(a.y - b.y) * 2 < (a.h + b.h);
  },
  hash(x, y) {
    let n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
    return n - Math.floor(n);
  },
  fmt(n) { return Math.round(n).toString(); },
};
