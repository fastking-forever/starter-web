/* ================= Main game controller ================= */
const SAVE_KEY = 'sand-tale-save-v1';

class Game {
  constructor() {
    this.canvas = document.getElementById('game');
    this.ctx = this.canvas.getContext('2d');
    this.W = this.canvas.width; this.H = this.canvas.height;
    this.mini = document.getElementById('minimap');
    this.mctx = this.mini.getContext('2d');
    this.audio = new SoundManager();

    this.state = 'start';
    this.time = 0;
    this.cam = { x: 0, y: 0 };
    this.shake = 0;
    this.portalCd = 0;
    this.saveTimer = 0;
    this.toastTimer = null;

    this.input = { keys: {}, dx: 0, dy: 0, attack: false, magic: false, interact: false, potion: false, touchX: 0, touchY: 0 };

    this.currentMapKey = 'village';
    this.player = new Player(0, 0);
    this.enemies = []; this.respawns = []; this.projectiles = [];
    this.particles = []; this.slashes = []; this.damageNumbers = [];
    this.pickups = []; this.chests = [];
    this.quest = { stage: 0 };
    this.bossDefeated = false;
    this.dialogue = null;

    this.dom = {
      hud: document.getElementById('hud'),
      start: document.getElementById('start'),
      menu: document.getElementById('menu'),
      inventory: document.getElementById('inventory'),
      dialogue: document.getElementById('dialogue'),
      end: document.getElementById('end'),
      touch: document.getElementById('touch'),
      toast: document.getElementById('toast'),
      continueBtn: document.getElementById('continueBtn'),
    };

    this.bindEvents();
    this.loadMap('village', 'start');
    this.updateHUD();
    this.refreshContinueButton();
  }

  map() { return MAPS[this.currentMapKey]; }

  /* ---------------- Events ---------------- */
  bindEvents() {
    const unlock = () => { this.audio.init(); if (this.state !== 'start') this.audio.startMusic(); };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });

    window.addEventListener('keydown', (e) => {
      const k = e.key.toLowerCase();
      if (['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k)) e.preventDefault();
      if (this.input.keys[k]) { if (['arrowup','arrowdown','arrowleft','arrowright'].includes(k)) e.preventDefault(); return; }
      this.input.keys[k] = true;

      if (this.state === 'dialogue') {
        if (k === 'e' || k === 'enter') e.preventDefault();
        if (k === 'escape') { this.setState('play'); return; }
        if (/^[1-9]$/.test(k)) this.choose(parseInt(k, 10) - 1);
        else if (k === 'e' || k === 'enter') this.advanceDialogue();
        return;
      }
      if (k === 'escape') { e.preventDefault(); this.togglePause(); return; }
      if (k === 'i') { this.toggleInventory(); return; }
      if (k === 'm') { const m = this.audio.toggleMute(); this.toast(m ? '🔇 الصوت مقفول' : '🔊 الصوت شغّال'); return; }
      if (this.state !== 'play') return;
      if (k === ' ' || k === 'j') { e.preventDefault(); this.input.attack = true; }
      if (k === 'k') { e.preventDefault(); this.input.magic = true; }
      if (k === 'e' || k === 'enter') { e.preventDefault(); this.input.interact = true; }
      if (k === 'p') this.input.potion = true;
    });

    window.addEventListener('keyup', (e) => { this.input.keys[e.key.toLowerCase()] = false; });
    window.addEventListener('blur', () => { this.input.keys = {}; this.input.touchX = this.input.touchY = 0; });

    document.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (btn) { this.handleAction(btn.dataset.action); return; }
      const choice = e.target.closest('.choice');
      if (choice) { this.choose(parseInt(choice.dataset.index, 10)); return; }
      if (e.target.id === 'dialogueText') this.advanceDialogue();
    });

    // Touch buttons
    document.querySelectorAll('[data-touch]').forEach((b) => {
      const action = b.dataset.touch;
      b.addEventListener('pointerdown', (ev) => {
        ev.preventDefault(); this.audio.init();
        if (this.state !== 'play') return;
        if (action === 'attack') this.input.attack = true;
        if (action === 'magic') this.input.magic = true;
        if (action === 'interact') this.input.interact = true;
        if (action === 'potion') this.input.potion = true;
      });
    });

    // Virtual joystick
    const stick = document.getElementById('stick');
    const knob = document.getElementById('knob');
    let active = false;
    const updateStick = (e) => {
      const r = stick.getBoundingClientRect();
      let dx = e.clientX - (r.left + r.width / 2);
      let dy = e.clientY - (r.top + r.height / 2);
      const d = Math.hypot(dx, dy), max = r.width * .38;
      if (d > max) { dx = dx / d * max; dy = dy / d * max; }
      this.input.touchX = dx / max; this.input.touchY = dy / max;
      knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    };
    stick.addEventListener('pointerdown', (e) => { active = true; stick.setPointerCapture(e.pointerId); updateStick(e); this.audio.init(); });
    stick.addEventListener('pointermove', (e) => { if (active) updateStick(e); });
    const endStick = () => { active = false; this.input.touchX = this.input.touchY = 0; knob.style.transform = 'translate(-50%,-50%)'; };
    stick.addEventListener('pointerup', endStick);
    stick.addEventListener('pointercancel', endStick);

    if (window.matchMedia('(pointer: coarse)').matches) this.dom.touch.classList.remove('hidden');
  }

  handleAction(a) {
    this.audio.init();
    switch (a) {
      case 'new-game': this.startNewGame(); break;
      case 'continue-game': this.loadSave(); break;
      case 'resume': this.togglePause(); break;
      case 'save': this.saveGame(); this.toast('💾 تم حفظ اللعبة'); break;
      case 'mute': {
        const m = this.audio.toggleMute();
        document.querySelector('[data-action="mute"]').textContent = m ? '🔇 الصوت: مقفول' : '🔊 الصوت: مفعّل';
        break;
      }
      case 'music': {
        const on = this.audio.toggleMusic();
        document.querySelector('[data-action="music"]').textContent = on ? '🎵 الموسيقى: مفعّلة' : '🎵 الموسيقى: مقفولة';
        break;
      }
      case 'restart': this.startNewGame(); break;
      case 'close-inventory': this.toggleInventory(); break;
    }
  }

  /* ---------------- Flow ---------------- */
  startNewGame() {
    // rebuild maps to reset collected items / chests
    MAPS.village = buildVillage(); MAPS.desert = buildDesert(); MAPS.ruins = buildRuins();
    this.player = new Player(0, 0);
    this.quest = { stage: 0 }; this.bossDefeated = false;
    this.loadMap('village', 'start');
    this.setState('play');
    this.audio.startMusic();
    this.toast('تكلّم مع الشيخ سالم أولًا 🧓');
  }

  setState(s) {
    this.state = s;
    this.dom.start.classList.toggle('hidden', s !== 'start');
    this.dom.menu.classList.toggle('hidden', s !== 'pause');
    this.dom.inventory.classList.toggle('hidden', s !== 'inventory');
    this.dom.dialogue.classList.toggle('hidden', s !== 'dialogue');
    this.dom.end.classList.toggle('hidden', s !== 'end');
    this.dom.hud.classList.toggle('hidden', s === 'start');
  }

  togglePause() {
    if (this.state === 'play') this.setState('pause');
    else if (this.state === 'pause') this.setState('play');
  }

  toggleInventory() {
    if (this.state === 'play') { this.renderInventory(); this.setState('inventory'); }
    else if (this.state === 'inventory') this.setState('play');
  }

  loadMap(key, spawnName, coords) {
    this.currentMapKey = key;
    const m = this.map();
    const pos = (spawnName && m.spawns[spawnName]) || coords || m.spawns.start || { x: TILE * 2, y: TILE * 2 };
    this.player.x = pos.x; this.player.y = pos.y;
    this.enemies = m.enemySpawns
      .filter((s) => s.type !== 'boss' || !this.bossDefeated)
      .map((s) => new Enemy(s.type, s.x, s.y));
    this.respawns = []; this.projectiles = []; this.particles = [];
    this.slashes = []; this.damageNumbers = [];
    this.pickups = m.items.map((it) => new Pickup(it.type, it.x, it.y));
    this.chests = m.chests.map((c) => {
      const ch = new Chest(c.x, c.y, c.item); ch.opened = !!c.opened; return ch;
    });
    this.portalCd = 1.0;
    if (this.state !== 'start') this.audio.play('portal');
    this.updateHUD();
  }

  checkPortals(dt) {
    this.portalCd = Math.max(0, this.portalCd - dt);
    if (this.portalCd > 0) return;
    const p = this.player;
    for (const portal of this.map().portals) {
      if (p.x > portal.x && p.x < portal.x + portal.w && p.y > portal.y && p.y < portal.y + portal.h) {
        if (portal.to === 'ruins' && this.quest.stage < 3) {
          this.toast('الشيخ لم يأذن لك بدخول الأطلال بعد ❌');
          this.portalCd = 2.5;
        } else {
          this.saveGame(true);
          this.loadMap(portal.to, portal.spawn);
          this.toast(`📍 ${this.map().name}`);
        }
        return;
      }
    }
  }

  /* ---------------- Update ---------------- */
  update(dt) {
    this.time += dt;
    this.shake = Math.max(0, this.shake - dt * 24);
    if (this.state !== 'play') { this.input.dx = this.input.dy = 0; return; }

    this.readInput();
    this.player.update(dt, this);
    this.processActions();
    this.checkPortals(dt);

    for (let i = this.enemies.length - 1; i >= 0; i--) this.enemies[i].update(dt, this);

    // respawns
    for (let i = this.respawns.length - 1; i >= 0; i--) {
      const r = this.respawns[i]; r.t -= dt;
      if (r.t <= 0) {
        if (this.currentMapKey === (r.map || this.currentMapKey)) this.enemies.push(new Enemy(r.type, r.x, r.y));
        this.respawns.splice(i, 1);
      }
    }

    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i]; p.update(dt, this);
      if (p.life <= 0) this.projectiles.splice(i, 1);
    }
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i]; p.update(dt);
      if (p.life <= 0) this.particles.splice(i, 1);
    }
    for (let i = this.slashes.length - 1; i >= 0; i--) {
      const s = this.slashes[i]; s.update(dt);
      if (s.life <= 0) this.slashes.splice(i, 1);
    }
    for (let i = this.damageNumbers.length - 1; i >= 0; i--) {
      const d = this.damageNumbers[i]; d.update(dt);
      if (d.life <= 0) this.damageNumbers.splice(i, 1);
    }
    for (const pk of this.pickups) pk.update(dt, this);
    for (const ch of this.chests) ch.update(dt, this);

    // quest auto-advance
    if (this.quest.stage === 1 && this.player.scarabs >= 5) this.setQuest(2);

    // camera
    const targetX = U.clamp(this.player.x - this.W / 2, 0, Math.max(0, this.map().w * TILE - this.W));
    const targetY = U.clamp(this.player.y - this.H / 2, 0, Math.max(0, this.map().h * TILE - this.H));
    this.cam.x = U.lerp(this.cam.x, targetX, Math.min(1, dt * 7));
    this.cam.y = U.lerp(this.cam.y, targetY, Math.min(1, dt * 7));

    // autosave
    this.saveTimer += dt;
    if (this.saveTimer > 25) { this.saveTimer = 0; this.saveGame(true); }

    this.updateHUD();
  }

  readInput() {
    const k = this.input.keys;
    let dx = 0, dy = 0;
    if (k['arrowleft'] || k['a']) dx -= 1;
    if (k['arrowright'] || k['d']) dx += 1;
    if (k['arrowup'] || k['w']) dy -= 1;
    if (k['arrowdown'] || k['s']) dy += 1;
    dx += this.input.touchX; dy += this.input.touchY;
    this.input.dx = U.clamp(dx, -1, 1); this.input.dy = U.clamp(dy, -1, 1);
  }

  processActions() {
    const inp = this.input;
    if (inp.potion) { this.player.usePotion(this); inp.potion = false; }
    if (inp.attack) { this.player.attack(this); inp.attack = false; }
    if (inp.magic) { this.player.cast(this); inp.magic = false; }
    if (inp.interact) {
      inp.interact = false;
      let best = null, bestD = 48;
      for (const npc of this.map().npcs) {
        const d = U.dist(this.player.x, this.player.y, npc.x, npc.y);
        if (d < bestD) { best = { kind: 'npc', obj: npc }; bestD = d; }
      }
      for (const ch of this.chests) {
        if (ch.opened) continue;
        const d = U.dist(this.player.x, this.player.y, ch.x, ch.y);
        if (d < 36 && d < bestD) { best = { kind: 'chest', obj: ch }; bestD = d; }
      }
      if (best) {
        if (best.kind === 'npc') this.talkTo(best.obj);
        else {
          best.obj.opened = true;
          const idx = this.map().chests.findIndex((c) => c.x === best.obj.x && c.y === best.obj.y);
          if (idx >= 0) this.map().chests[idx].opened = true;
          this.audio.play('pickup');
          this.toast('وجدتَ تحفةً قديمة! 💎');
          this.burst(best.obj.x, best.obj.y, '#c86bff', 20);
          this.pickups.push(new Pickup(best.obj.item, best.obj.x, best.obj.y - 10));
        }
      }
    }
  }

  /* ---------------- Combat / pickups ---------------- */
  damageEnemy(e, dmg, dir) {
    if (!e || e.hp <= 0) return;
    e.hurt(dmg, this, dir);
    this.damageNumbers.push(new DamageNumber(e.x, e.y - e.h / 2, '-' + Math.round(dmg), '#ffe08a'));
    this.burst(e.x, e.y, e.color, 7);
    this.audio.play('hit');
    this.shake = Math.max(this.shake, 3);
    if (e.hp <= 0) {
      this.audio.play('die');
      this.player.gold += e.gold;
      this.player.gainXp(e.xp, this);
      this.damageNumbers.push(new DamageNumber(e.x, e.y - 26, '+' + e.gold + ' 🪙', '#f5c451',));
      if (e.drop === 'scarab') {
        this.pickups.push(new Pickup('scarab', e.x, e.y));
        if (Math.random() < .4) this.pickups.push(new Pickup('gold', e.x + 10, e.y + 6));
      } else if (e.drop === 'gold') {
        this.pickups.push(new Pickup('gold', e.x, e.y));
      } else if (e.drop === 'potion') {
        this.pickups.push(new Pickup('potion', e.x, e.y));
        if (Math.random() < .5) this.pickups.push(new Pickup('gold', e.x + 8, e.y));
      }
      const i = this.enemies.indexOf(e);
      if (i >= 0) this.enemies.splice(i, 1);
      if (e.boss) {
        this.bossDefeated = true;
        this.setQuest(4);
        this.toast('🏆 سقط ساحر الرمال! عد إلى الشيخ');
        this.audio.play('victory');
        this.burst(e.x, e.y, '#f5c451', 50);
        this.pickups.push(new Pickup('artifact', e.x, e.y));
      } else {
        this.respawns.push({ type: e.type, x: e.home.x, y: e.home.y, t: 13, map: this.currentMapKey });
      }
    }
  }

  collect(p) {
    const i = this.pickups.indexOf(p);
    if (i >= 0) this.pickups.splice(i, 1);
    // remove from map's initial items if present
    const mi = this.map().items.findIndex((it) => it.x === p.x && it.y === p.y);
    if (mi >= 0) this.map().items.splice(mi, 1);
    this.audio.play('pickup');
    switch (p.type) {
      case 'gold': this.player.gold += U.randInt(4, 9); break;
      case 'potion': this.player.potions += 1; this.toast('🧪 جرعة شفاء +1'); break;
      case 'scarab': this.player.scarabs += 1; this.toast(`🪲 خنفساء ذهبية ${this.player.scarabs}/5`); break;
      case 'key': this.player.keys += 1; break;
      case 'artifact': this.player.artifact = true; this.toast('💎 تحفة قديمة!'); break;
    }
  }

  burst(x, y, color, n = 10) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = U.rand(30, 130);
      this.particles.push(new Particle(x, y, Math.cos(a) * s, Math.sin(a) * s, color, U.rand(2, 5), U.rand(.25, .6)));
    }
  }

  onPlayerDeath() {
    this.audio.play('die');
    this.setState('end');
    document.getElementById('endTitle').textContent = '💀 سقطتَ في الرمال';
    document.getElementById('endText').textContent = `وصلتَ إلى المستوى ${this.player.level} وجمعتَ ${this.player.gold} ذهبًا. لا بأس، جرّب مرة أخرى!`;
  }

  win() {
    this.setQuest(5);
    this.audio.play('victory');
    this.setState('end');
    document.getElementById('endTitle').textContent = '🏆 انتصرتَ!';
    document.getElementById('endText').textContent =
      `أعدتَ السلام إلى الوادي. المستوى ${this.player.level} · الذهب ${this.player.gold} · الخنافس ${this.player.scarabs}. شكرًا لك أيها البطل!`;
    this.saveGame(true);
  }

  /* ---------------- Dialogue & quests ---------------- */
  questText() {
    switch (this.quest.stage) {
      case 0: return 'تكلّم مع الشيخ سالم في القرية 🧓';
      case 1: return `اجمع 5 خنافس ذهبية من عقارب الصحراء (${this.player.scarabs}/5) 🪲`;
      case 2: return 'ارجع إلى الشيخ سالم في القرية 🏡';
      case 3: return 'ادخل الأطلال واقهر ساحر الرمال 🔴';
      case 4: return 'عد إلى الشيخ لتستلم مكافأتك 🎁';
      default: return 'اكتملت المهمة — تştur بالحرية! 🌙';
    }
  }

  setQuest(stage) {
    this.quest.stage = stage;
    this.toast('📜 ' + this.questText());
    this.updateHUD();
  }

  openDialogue(name, text, choices = []) {
    this.dialogue = { name, text, choices };
    document.getElementById('speaker').textContent = name;
    document.getElementById('dialogueText').textContent = text;
    const box = document.getElementById('choices');
    box.innerHTML = '';
    choices.forEach((c, i) => {
      const b = document.createElement('button');
      b.className = 'choice'; b.dataset.index = i;
      b.textContent = `${i + 1}. ${c.label}`;
      box.appendChild(b);
    });
    document.getElementById('dialogueHint').textContent = choices.length ? 'اختر رقمًا أو اضغط على الخيار' : 'اضغط E للمتابعة';
    this.audio.play('talk');
    this.setState('dialogue');
  }

  advanceDialogue() {
    if (this.state !== 'dialogue') return;
    if (this.dialogue.choices.length) return;
    this.setState('play');
  }

  choose(i) {
    if (this.state !== 'dialogue' || !this.dialogue.choices[i]) return;
    const c = this.dialogue.choices[i];
    this.setState('play');
    if (c.action) c.action();
  }

  talkTo(npc) {
    const q = this.quest.stage, p = this.player;
    if (npc.id === 'elder') {
      if (q === 0) {
        this.openDialogue(npc.name,
          'يا بطل، ظهر ساحر الرمال من الأطلال القديمة ويخيف أهل القرية. اذهب إلى الصحراء واجمع لي خمس خنافس ذهبية من العقارب، وسأمنحك مفتاح الأطلال.',
          [{ label: 'أنا مستعد! ⚔', action: () => this.setQuest(1) }, { label: 'سأفكر في الأمر', action: null }]);
      } else if (q === 1) {
        this.openDialogue(npc.name, `جمعتَ ${p.scarabs} من أصل 5 خنافس. لا تستسلم! العقارب تنتشر شرق القرية.`);
      } else if (q === 2) {
        if (p.scarabs >= 5) {
          this.openDialogue(npc.name, 'أحسنت! هذه مفاتيح الأطلال. اقهر ساحر الرمال وأعد الأمن إلينا.',
            [{ label: 'خذ المفتاح 🗝️', action: () => { p.keys++; p.scarabs -= 5; this.setQuest(3); } }]);
        } else this.openDialogue(npc.name, `ما زلت تحتاج ${5 - p.scarabs} خنافس أخرى.`);
      } else if (q === 3) {
        this.openDialogue(npc.name, 'الأطلال إلى شمال الصحراء. كن حذرًا، الساحر يطلق كرات سحرية!');
      } else if (q === 4) {
        this.openDialogue(npc.name, 'عدتَ منتصرًا! لقد أنقذتَ القرية كلها. خذ مكافأتك أيها البطل.',
          [{ label: 'استلم المكافأة 🎁', action: () => { p.gold += 100; p.potions += 3; this.win(); } }]);
      } else this.openDialogue(npc.name, 'السلام يعود إلى الوادي بفضل شجاعتك. مرحبًا بك في أي وقت 🌙');
    } else if (npc.id === 'merchant') {
      this.openDialogue(npc.name, 'مرحبًا! عندي جرعات شفاء وخدمات للابطال الشجعان.', [
        { label: 'اشترِ جرعة (10 🪙)', action: () => {
          if (p.gold >= 10) { p.gold -= 10; p.potions++; this.toast('🧪 اشتريتَ جرعة'); this.audio.play('pickup'); }
          else this.toast('الذهب غير كافٍ 💰');
        } },
        { label: 'شفاء كامل (15 🪙)', action: () => {
          if (p.gold >= 15 && p.hp < p.maxHp) { p.gold -= 15; p.hp = p.maxHp; this.toast('✨ شُفيتَ تمامًا'); this.audio.play('potion'); }
          else this.toast('لا تحتاج شفاءً أو الذهب غير كافٍ');
        } },
        { label: 'الى اللقاء', action: null },
      ]);
    } else if (npc.id === 'villager1') {
      this.openDialogue(npc.name, q === 3 ? 'سمعتُ أن الساحر يخاف من السحر الأزرق... استخدم K في القتال!'
        : 'الصحراء جميلة لكنها خطرة. احمل جرعات كافية دائمًا!');
    } else {
      this.openDialogue(npc.name, q >= 4 ? 'جميع أهل القرية يتحدثون عن شجاعتك! 🌟'
        : 'الشيخ ينتظر عند بئر القرية. ابدأ هناك.');
    }
  }

  /* ---------------- Save ---------------- */
  saveGame(silent = false) {
    try {
      const p = this.player;
      const data = {
        v: 1, map: this.currentMapKey, stage: this.quest.stage, boss: this.bossDefeated,
        x: p.x, y: p.y, hp: p.hp, maxHp: p.maxHp, mp: p.mp, maxMp: p.maxMp,
        level: p.level, xp: p.xp, xpNeed: p.xpNeed, gold: p.gold, atk: p.atk, def: p.def,
        potions: p.potions, keys: p.keys, scarabs: p.scarabs, artifact: p.artifact,
        chests: MAPS.ruins.chests.map((c) => !!c.opened),
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      if (!silent) this.refreshContinueButton();
    } catch (e) { if (!silent) this.toast('تعذّر الحفظ'); }
  }

  hasSave() { try { return !!localStorage.getItem(SAVE_KEY); } catch (e) { return false; } }

  refreshContinueButton() { this.dom.continueBtn.classList.toggle('hidden', !this.hasSave()); }

  loadSave() {
    let d;
    try { d = JSON.parse(localStorage.getItem(SAVE_KEY)); } catch (e) { d = null; }
    if (!d || d.v !== 1) { this.toast('لا يوجد حفظ صالح'); return; }
    MAPS.ruins.chests.forEach((c, i) => { c.opened = !!d.chests?.[i]; });
    this.bossDefeated = !!d.boss;
    this.quest = { stage: d.stage || 0 };
    this.player = new Player(d.x, d.y);
    Object.assign(this.player, {
      maxHp: d.maxHp, hp: d.hp, maxMp: d.maxMp, mp: d.mp, level: d.level,
      xp: d.xp, xpNeed: d.xpNeed, gold: d.gold, atk: d.atk, def: d.def,
      potions: d.potions, keys: d.keys, scarabs: d.scarabs, artifact: !!d.artifact,
    });
    this.loadMap(d.map || 'village', null, { x: d.x, y: d.y });
    this.setState('play');
    this.audio.startMusic();
    this.toast('📂 تم تحميل الحفظ');
  }

  /* ---------------- UI ---------------- */
  updateHUD() {
    const p = this.player;
    document.getElementById('lvl').textContent = p.level;
    document.getElementById('hpFill').style.width = (p.hp / p.maxHp * 100) + '%';
    document.getElementById('mpFill').style.width = (p.mp / p.maxMp * 100) + '%';
    document.getElementById('hpText').textContent = `${U.fmt(p.hp)}/${p.maxHp}`;
    document.getElementById('mpText').textContent = `${U.fmt(p.mp)}/${p.maxMp}`;
    document.getElementById('gold').textContent = p.gold;
    document.getElementById('questText').textContent = this.questText();
    document.getElementById('areaName').textContent = this.map().name;
  }

  renderInventory() {
    const p = this.player;
    document.getElementById('invStats').innerHTML = `
      <div>❤️ <b>${U.fmt(p.hp)}</b> / ${p.maxHp}</div>
      <div>✨ <b>${U.fmt(p.mp)}</b> / ${p.maxMp}</div>
      <div>⭐ المستوى <b>${p.level}</b></div>
      <div>⚔️ الهجوم <b>${p.atk}</b></div>
      <div>🛡️ الدفاع <b>${p.def}</b></div>
      <div>🪙 الذهب <b>${p.gold}</b></div>`;
    document.getElementById('invItems').innerHTML = `
      <div class="inv-item"><div class="emoji">🧪</div>جرعات <span class="count">${p.potions}</span></div>
      <div class="inv-item"><div class="emoji">🗝️</div>مفاتيح <span class="count">${p.keys}</span></div>
      <div class="inv-item"><div class="emoji">🪲</div>خنافس <span class="count">${p.scarabs}</span></div>
      <div class="inv-item"><div class="emoji">💎</div>تحفة <span class="count">${p.artifact ? 'نعم' : 'لا'}</span></div>`;
  }

  toast(msg) {
    this.dom.toast.textContent = msg;
    this.dom.toast.classList.add('show');
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => this.dom.toast.classList.remove('show'), 2200);
  }

  /* ---------------- Render ---------------- */
  render() {
    const ctx = this.ctx;
    ctx.imageSmoothingEnabled = false;
    ctx.fillStyle = '#1b1230';
    ctx.fillRect(0, 0, this.W, this.H);

    const sx = this.shake ? U.rand(-this.shake, this.shake) : 0;
    const sy = this.shake ? U.rand(-this.shake, this.shake) : 0;
    ctx.save();
    ctx.translate(Math.round(-this.cam.x + sx), Math.round(-this.cam.y + sy));

    this.map().draw(ctx, this.cam, this.time);

    // torches
    for (const t of this.map().torches) {
      const f = 0.5 + 0.5 * Math.sin(this.time * 8 + t.x);
      ctx.save();
      ctx.fillStyle = `rgba(255,150,40,${.10 + f * .08})`;
      ctx.beginPath(); ctx.arc(t.x, t.y, 46 + f * 8, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffb038';
      ctx.beginPath(); ctx.arc(t.x, t.y - 2, 4 + f * 2, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff0a0';
      ctx.beginPath(); ctx.arc(t.x, t.y - 3, 2, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }

    for (const ch of this.chests) ch.draw(ctx, this.cam);
    for (const pk of this.pickups) pk.draw(ctx, this.cam);

    const drawables = [...this.enemies, this.player].sort((a, b) => a.y - b.y);
    for (const d of drawables) d.draw(ctx, this.cam);

    for (const s of this.slashes) s.draw(ctx, this.cam);
    for (const pr of this.projectiles) pr.draw(ctx, this.cam);
    for (const pa of this.particles) pa.draw(ctx, this.cam);
    for (const d of this.damageNumbers) d.draw(ctx, this.cam);
    ctx.restore();

    // vignette
    const g = ctx.createRadialGradient(this.W / 2, this.H / 2, this.H * .35, this.W / 2, this.H / 2, this.H * .85);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, 'rgba(10,5,20,.45)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, this.W, this.H);

    this.drawMinimap();
  }

  drawMinimap() {
    const m = this.map(), c = this.mctx;
    const sw = this.mini.width / m.w, sh = this.mini.height / m.h;
    const colors = ['#d9b26f','#b99a63','#9b8d78','#5d4d3d','#2b6f8f','#3f7a3f','#847d72','#5d566b','#40394f'];
    c.clearRect(0, 0, this.mini.width, this.mini.height);
    for (let y = 0; y < m.h; y++) {
      for (let x = 0; x < m.w; x++) {
        c.fillStyle = colors[m.get(x, y)] || '#000';
        c.fillRect(x * sw, y * sh, Math.ceil(sw), Math.ceil(sh));
      }
    }
    for (const p of m.portals) {
      c.fillStyle = '#f5c451';
      c.fillRect(p.x / TILE * sw, p.y / TILE * sh, p.w / TILE * sw, p.h / TILE * sh);
    }
    for (const e of this.enemies) {
      c.fillStyle = e.boss ? '#c86bff' : '#e05252';
      c.fillRect(e.x / TILE * sw - 1, e.y / TILE * sh - 1, 3, 3);
    }
    c.fillStyle = '#fff';
    c.fillRect(this.player.x / TILE * sw - 2, this.player.y / TILE * sh - 2, 4, 4);
  }
}
