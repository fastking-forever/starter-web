/* ================= Bootstrap ================= */
window.addEventListener('DOMContentLoaded', () => {
  const game = new Game();
  window.game = game; // handy while tweaking from console

  let last = performance.now();
  function loop(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    game.update(dt);
    game.render();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
});
