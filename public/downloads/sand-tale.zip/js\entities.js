/* ================= Entities ================= */
const ENEMY_TYPES = {
  scorpion: { name: 'عقرب صحراوي', hp: 26, speed: 58, dmg: 8, xp: 12, gold: 6, color: '#b5652b', w: 24, h: 18, aggro: 190, drop: 'scarab' },
  bandit:   { name: 'قطّاع طريق', hp: 46, speed: 68, dmg: 13, xp: 24, gold: 14, color: '#a04a45', w: 24, h: 28, aggro: 240, drop: 'gold' },
  mage:     { name: 'ساحر صحراوي', hp: 34, speed: 48, dmg: 14, xp: 30, gold: 16, color: '#6d4bb0', w: 24, h: 28, aggro: 270, ranged: true, drop: 'potion' },
  boss:     { name: 'ساحر الرمال', hp: 280, speed: 62, dmg: 22, xp: 250, gold: 200, color: '#8b2ff7', w: 40, h: 46, aggro: 420, ranged: true, boss: true, drop: 'artifact' },
};

class Player {
  constructor(x, y) {
    this.x = x; this.y = y; this.w = 22; this.h = 26;
    this.speed = 158;
    this.maxHp = 100; this.hp = 100;
    this.maxMp = 40; this.mp = 40;
    this.level = 1; this.xp = 0; this.xpNeed = 60;
    this.gold = 20; this.atk = 12; this.def = 2;
    this.potions = 2; this.keys = 0; this.scarabs = 0; this.artifact = false;
    this.facing = { x: 0, y: 1 };
    this.anim = 0; this.moving = false;
    this.attackCd = 0; this.magicCd = 0; this.hurtCd = 0;
    this.kb = { x: 0, y: 0 };
  }

  update(dt, game) {
    const inp = game.input;
    let dx = inp.dx, dy = inp.dy;
    const len = Math.hypot(dx, dy);
    if (len > 0) { dx /= len; dy /= len; this.facing = { x: dx, y: dy }; }
    this.moving = len > 0;
    if (this.moving) this.anim += dt * 9;

    let mx = dx * this.speed * dt + this.kb.x * dt;
    let my = dy * this.speed * dt + this.kb.y * dt;
    this.kb.x *= Math.pow(0.001, dt); this.kb.y *= Math.pow(0.001, dt);
    const map = game.map();
    if (!map.isSolidAt(this.x + mx, this.y, 9)) this.x += mx;
    if (!map.isSolidAt(this.x, this.y + my, 9)) this.y += my;
    this.x = U.clamp(this.x, 16, map.w * TILE - 16);
    this.y = U.clamp(this.y, 16, map.h * TILE - 16);

    this.attackCd = Math.max(0, this.attackCd - dt);
    this.magicCd = Math.max(0, this.magicCd - dt);
    this.hurtCd = Math.max(0, this.hurtCd - dt);
    this.mp = Math.min(this.maxMp, this.mp + dt * 2.5);
  }

  attack(game) {
    if (this.attackCd > 0) return;
    this.attackCd = 0.30;
    game.audio.play('swing');
    const reach = 27;
    const box = { x: this.x + this.facing.x * reach, y: this.y + this.facing.y * reach, w: 36, h: 36 };
    game.slashes.push(new Slash(box, this.facing));
    for (const e of game.enemies.slice()) {
      if (U.aabb(box, e)) game.damageEnemy(e, this.atk + U.randInt(-2, 4), this.facing);
    }
  }

  cast(game) {
    if (this.magicCd > 0 || this.mp < 12) { if (this.mp < 12) game.toast('المانا غير كافية ✨'); return; }
    this.magicCd = 0.45; this.mp -= 12;
    game.audio.play('magic');
    const s = 300;
    game.projectiles.push(new Projectile(this.x + this.facing.x * 14, this.y + this.facing.y * 14,
      this.facing.x * s, this.facing.y * s, 18 + this.level * 3, 'player', '#7fc4ff'));
  }

  usePotion(game) {
    if (this.potions <= 0) { game.toast('لا توجد جرعات 🧪'); return; }
    if (this.hp >= this.maxHp) { game.toast('الصحة ممتلئة بالفعل'); return; }
    this.potions--;
    this.hp = Math.min(this.maxHp, this.hp + 45);
    game.audio.play('potion');
    game.toast('+45 صحة 🧪');
    game.burst(this.x, this.y, '#ff8fb0', 12);
  }

  hurt(dmg, game, fromX, fromY) {
    if (this.hurtCd > 0) return;
    const real = Math.max(2, dmg - this.def);
    this.hp -= real;
    this.hurtCd = 0.55;
    const a = Math.atan2(this.y - fromY, this.x - fromX);
    this.kb.x = Math.cos(a) * 170; this.kb.y = Math.sin(a) * 170;
    game.audio.play('hurt');
    game.damageNumbers.push(new DamageNumber(this.x, this.y - 16, '-' + real, '#ff7676'));
    game.shake = 6;
    if (this.hp <= 0) { this.hp = 0; game.onPlayerDeath(); }
  }

  gainXp(n, game) {
    this.xp += n;
    while (this.xp >= this.xpNeed) {
      this.xp -= this.xpNeed;
      this.level++;
      this.xpNeed = Math.floor(this.xpNeed * 1.45);
      this.maxHp += 18; this.hp = this.maxHp;
      this.maxMp += 8; this.mp = this.maxMp;
      this.atk += 3; this.def += 1; this.potions += 1;
      game.audio.play('levelup');
      game.toast(`🎆 مستوى ${this.level}! زادات قوتك`);
      game.burst(this.x, this.y, '#f5c451', 30);
    }
  }

  draw(ctx, cam) {
    const px = this.x - cam.x, py = this.y - cam.y;
    const bob = this.moving ? Math.sin(this.anim) * 2 : Math.sin(Date.now() / 400) * 0.8;
    ctx.save();
    // shadow
    ctx.fillStyle = 'rgba(0,0,0,.3)';
    ctx.beginPath(); ctx.ellipse(px, py + 11, 12, 5, 0, 0, Math.PI * 2); ctx.fill();
    // cloak
    ctx.fillStyle = this.hurtCd > 0 && Math.floor(Date.now() / 60) % 2 ? '#fff' : '#3f5aa8';
    ctx.beginPath();
    ctx.moveTo(px - 9, py + 12 + bob); ctx.lineTo(px - 6, py - 4 + bob);
    ctx.lineTo(px + 6, py - 4 + bob); ctx.lineTo(px + 9, py + 12 + bob);
    ctx.closePath(); ctx.fill();
    // scarf
    ctx.fillStyle = '#f5c451'; ctx.fillRect(px - 7, py - 4 + bob, 14, 4);
    // head
    ctx.fillStyle = '#e8b98c';
    ctx.beginPath(); ctx.arc(px, py - 9 + bob, 7, 0, Math.PI * 2); ctx.fill();
    // hood
    ctx.fillStyle = '#2e427f';
    ctx.beginPath(); ctx.arc(px, py - 10 + bob, 8, Math.PI, Math.PI * 2); ctx.fill();
    // eyes based on facing
    ctx.fillStyle = '#251a12';
    const ex = this.facing.x * 2, ey = this.facing.y * 1.5;
    ctx.fillRect(px - 4 + ex, py - 10 + ey + bob, 2, 2);
    ctx.fillRect(px + 2 + ex, py - 10 + ey + bob, 2, 2);
    // sword
    ctx.strokeStyle = '#dfe6ef'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(px + 8, py + 4 + bob); ctx.lineTo(px + 8 + this.facing.x * 12, py + 4 + this.facing.y * 12 + bob); ctx.stroke();
    ctx.strokeStyle = '#8b5a2b'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(px + 6, py + 3 + bob); ctx.lineTo(px + 10, py + 5 + bob); ctx.stroke();
    ctx.restore();
  }
}

class Enemy {
  constructor(type, x, y) {
    const c = ENEMY_TYPES[type];
    this.type = type; this.name = c.name; this.color = c.color;
    this.x = x; this.y = y; this.w = c.w; this.h = c.h;
    this.maxHp = c.hp; this.hp = c.hp;
    this.speed = c.speed; this.dmg = c.dmg; this.xp = c.xp; this.gold = c.gold;
    this.aggro = c.aggro; this.ranged = !!c.ranged; this.boss = !!c.boss; this.drop = c.drop;
    this.attackCd = U.rand(0, .6); this.castCd = U.rand(1, 2.5);
    this.hurtCd = 0; this.anim = U.rand(0, 10); this.kb = { x: 0, y: 0 };
    this.home = { x, y };
  }

  update(dt, game) {
    this.attackCd -= dt; this.castCd -= dt; this.hurtCd -= dt;
    this.anim += dt * 6;
    const p = game.player;
    const d = U.dist(this.x, this.y, p.x, p.y);
    if (d < this.aggro) {
      if (d > (this.ranged ? 120 : 22)) {
        const dx = (p.x - this.x) / d, dy = (p.y - this.y) / d;
        const map = game.map();
        const mx = dx * this.speed * dt + this.kb.x * dt;
        const my = dy * this.speed * dt + this.kb.y * dt;
        if (!map.isSolidAt(this.x + mx, this.y, this.w / 2 - 3)) this.x += mx;
        if (!map.isSolidAt(this.x, this.y + my, this.h / 2 - 3)) this.y += my;
      } else if (this.attackCd <= 0 && !this.ranged) {
        this.attackCd = 1.0;
        p.hurt(this.dmg, game, this.x, this.y);
        game.burst(p.x, p.y, '#ff7766', 6);
      }
      if (this.ranged && this.castCd <= 0 && d < 300) {
        this.castCd = this.boss ? 1.35 : 2.3;
        const dx = (p.x - this.x) / d, dy = (p.y - this.y) / d;
        game.projectiles.push(new Projectile(this.x, this.y, dx * 190, dy * 190, this.dmg, 'enemy', this.boss ? '#c86bff' : '#a06bff'));
        game.audio.play('magic');
      }
    } else if (U.dist(this.x, this.y, this.home.x, this.home.y) > 40) {
      const dx = (this.home.x - this.x) / 40, dy = (this.home.y - this.y) / 40;
      this.x += dx * this.speed * .4 * dt; this.y += dy * this.speed * .4 * dt;
    }
    this.kb.x *= Math.pow(0.002, dt); this.kb.y *= Math.pow(0.002, dt);
  }

  hurt(dmg, game, dir) {
    this.hp -= dmg;
    this.hurtCd = 0.18;
    if (dir) { this.kb.x = dir.x * 170; this.kb.y = dir.y * 170; }
  }

  draw(ctx, cam) {
    const px = this.x - cam.x, py = this.y - cam.y;
    const flash = this.hurtCd > 0 ? '#fff' : null;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.3)';
    ctx.beginPath(); ctx.ellipse(px, py + this.h / 2, this.w / 2, 5, 0, 0, Math.PI * 2); ctx.fill();
    const c = flash || this.color;
    if (this.boss) {
      const glow = 0.5 + 0.5 * Math.sin(Date.now() / 250);
      ctx.shadowColor = '#b45cff'; ctx.shadowBlur = 12 + glow * 10;
      ctx.fillStyle = '#3a1a5e';
      ctx.beginPath(); ctx.moveTo(px - 18, py + 20); ctx.lineTo(px - 12, py - 10);
      ctx.lineTo(px + 12, py - 10); ctx.lineTo(px + 18, py + 20); ctx.closePath(); ctx.fill();
      ctx.fillStyle = c;
      ctx.beginPath(); ctx.arc(px, py - 14, 12, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffd76b';
      ctx.beginPath(); ctx.moveTo(px - 12, py - 22); ctx.lineTo(px - 8, py - 32);
      ctx.lineTo(px, py - 24); ctx.lineTo(px + 8, py - 32); ctx.lineTo(px + 12, py - 22); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.fillRect(px - 6, py - 15, 3, 3); ctx.fillRect(px + 3, py - 15, 3, 3);
      ctx.shadowBlur = 0;
    } else if (this.type === 'scorpion') {
      const wig = Math.sin(this.anim) * 3;
      ctx.fillStyle = c;
      ctx.beginPath(); ctx.ellipse(px, py + 2, 11, 7, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = c; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(px + 8, py); ctx.quadraticCurveTo(px + 18, py - 14, px + 10 + wig, py - 12); ctx.stroke();
      ctx.fillStyle = '#3a1e0e';
      ctx.fillRect(px - 9, py + 5, 3, 5); ctx.fillRect(px + 6, py + 5, 3, 5);
      ctx.fillStyle = '#ffd36b';
      ctx.beginPath(); ctx.arc(px + 10 + wig, py - 12, 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.fillRect(px - 4, py - 1, 2, 2); ctx.fillRect(px + 2, py - 1, 2, 2);
    } else {
      ctx.fillStyle = c;
      ctx.beginPath(); ctx.moveTo(px - 9, py + 13); ctx.lineTo(px - 7, py - 4);
      ctx.lineTo(px + 7, py - 4); ctx.lineTo(px + 9, py + 13); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#e8b98c';
      ctx.beginPath(); ctx.arc(px, py - 9, 7, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = this.ranged ? '#3a2568' : '#6b2f2c';
      ctx.beginPath(); ctx.arc(px, py - 10, 8, Math.PI, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.fillRect(px - 4, py - 10, 2, 2); ctx.fillRect(px + 2, py - 10, 2, 2);
      if (this.ranged) {
        ctx.strokeStyle = '#c9a2ff'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(px + 8, py + 2); ctx.lineTo(px + 13, py + 12); ctx.stroke();
        ctx.fillStyle = '#c9a2ff';
        ctx.beginPath(); ctx.arc(px + 13, py + 12, 3, 0, Math.PI * 2); ctx.fill();
      }
    }
    ctx.restore();
    // health bar
    if (this.hp < this.maxHp || this.boss) {
      const bw = this.boss ? 46 : 28;
      ctx.fillStyle = '#1a1024'; ctx.fillRect(px - bw / 2, py - this.h / 2 - 12, bw, 5);
      ctx.fillStyle = this.boss ? '#c86bff' : '#e05252';
      ctx.fillRect(px - bw / 2 + 1, py - this.h / 2 - 11, (bw - 2) * (this.hp / this.maxHp), 3);
    }
  }
}

class Projectile {
  constructor(x, y, vx, vy, dmg, owner, color) {
    this.x = x; this.y = y; this.vx = vx; this.vy = vy;
    this.dmg = dmg; this.owner = owner; this.color = color;
    this.r = 7; this.life = 2.5; this.trail = 0;
  }
  update(dt, game) {
    this.life -= dt; this.trail -= dt;
    const map = game.map();
    const nx = this.x + this.vx * dt, ny = this.y + this.vy * dt;
    if (map.isSolidAt(nx, ny, this.r)) { this.life = 0; game.burst(this.x, this.y, this.color, 8); return; }
    this.x = nx; this.y = ny;
    if (this.trail <= 0) { this.trail = .03; game.particles.push(new Particle(this.x, this.y, 0, 0, this.color, 4, .3)); }
    const box = { x: this.x, y: this.y, w: 12, h: 12 };
    if (this.owner === 'player') {
      for (const e of game.enemies) {
        if (U.aabb(box, e)) {
          game.damageEnemy(e, this.dmg, { x: Math.sign(this.vx), y: Math.sign(this.vy) });
          this.life = 0; game.burst(this.x, this.y, this.color, 12); break;
        }
      }
    } else if (U.aabb(box, game.player)) {
      game.player.hurt(this.dmg, game, this.x - this.vx * .05, this.y - this.vy * .05);
      this.life = 0; game.burst(this.x, this.y, this.color, 10);
    }
  }
  draw(ctx, cam) {
    const px = this.x - cam.x, py = this.y - cam.y;
    ctx.save();
    ctx.shadowColor = this.color; ctx.shadowBlur = 14;
    ctx.fillStyle = this.color;
    ctx.beginPath(); ctx.arc(px, py, this.r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(px - 1, py - 1, 2.5, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}

class Particle {
  constructor(x, y, vx, vy, color, size = 4, life = .5, gravity = 60) {
    this.x = x; this.y = y; this.vx = vx; this.vy = vy;
    this.color = color; this.size = size; this.life = life; this.maxLife = life; this.gravity = gravity;
  }
  update(dt) { this.vy += this.gravity * dt; this.x += this.vx * dt; this.y += this.vy * dt; this.life -= dt; }
  draw(ctx, cam) {
    ctx.globalAlpha = Math.max(0, this.life / this.maxLife);
    ctx.fillStyle = this.color;
    ctx.fillRect(this.x - cam.x - this.size / 2, this.y - cam.y - this.size / 2, this.size, this.size);
    ctx.globalAlpha = 1;
  }
}

class DamageNumber {
  constructor(x, y, text, color) {
    this.x = x; this.y = y; this.text = text; this.color = color; this.life = .8;
  }
  update(dt) { this.y -= 34 * dt; this.life -= dt; }
  draw(ctx, cam) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, this.life / .8);
    ctx.font = 'bold 15px sans-serif'; ctx.textAlign = 'center';
    ctx.lineWidth = 3; ctx.strokeStyle = '#1a0e24';
    ctx.strokeText(this.text, this.x - cam.x, this.y - cam.y);
    ctx.fillStyle = this.color;
    ctx.fillText(this.text, this.x - cam.x, this.y - cam.y);
    ctx.restore();
  }
}

class Slash {
  constructor(box, dir) {
    this.box = box; this.dir = dir; this.life = .16; this.maxLife = .16;
  }
  update(dt) { this.life -= dt; }
  draw(ctx, cam) {
    const a = Math.max(0, this.life / this.maxLife);
    const px = this.box.x - cam.x, py = this.box.y - cam.y;
    const ang = Math.atan2(this.dir.y, this.dir.x);
    ctx.save();
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#fff4c2'; ctx.lineWidth = 5; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(px, py, 18, ang - 1, ang + 1); ctx.stroke();
    ctx.strokeStyle = '#f5c451'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(px, py, 22, ang - .8, ang + .8); ctx.stroke();
    ctx.restore();
  }
}

const PICKUP_INFO = {
  gold:    { emoji: '🪙', color: '#f5c451' },
  potion:  { emoji: '🧪', color: '#ff8fb0' },
  scarab:  { emoji: '🪲', color: '#7fe0a0' },
  artifact:{ emoji: '💎', color: '#c86bff' },
  key:     { emoji: '🗝️', color: '#ffe6a8' },
};

class Pickup {
  constructor(type, x, y) { this.type = type; this.x = x; this.y = y; this.phase = U.rand(0, 6); this.life = 22; }
  update(dt, game) {
    this.phase += dt * 3; this.life -= dt;
    if (U.dist(this.x, this.y, game.player.x, game.player.y) < 22) {
      game.collect(this);
    }
  }
  draw(ctx, cam) {
    const info = PICKUP_INFO[this.type] || PICKUP_INFO.gold;
    const px = this.x - cam.x, py = this.y - cam.y + Math.sin(this.phase) * 3;
    ctx.save();
    ctx.shadowColor = info.color; ctx.shadowBlur = 10;
    ctx.font = '18px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(info.emoji, px, py);
    ctx.restore();
  }
}

class Chest {
  constructor(x, y, item) { this.x = x; this.y = y; this.item = item; this.opened = false; }
  update(dt, game) {
    if (!this.opened && U.dist(this.x, this.y, game.player.x, game.player.y) < 30 && game.input.interact) {
      game.input.interact = false;
      this.opened = true;
      game.audio.play('pickup');
      game.toast('وجدتَ تحفةً قديمة! 💎');
      game.burst(this.x, this.y, '#c86bff', 18);
      game.map().items.push({ type: this.item, x: this.x, y: this.y - 10 });
    }
  }
  draw(ctx, cam) {
    const px = this.x - cam.x, py = this.y - cam.y;
    ctx.fillStyle = 'rgba(0,0,0,.3)';
    ctx.beginPath(); ctx.ellipse(px, py + 10, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#6b4426'; ctx.fillRect(px - 12, py - 4, 24, 14);
    ctx.fillStyle = this.opened ? '#5a3a20' : '#8b5c30';
    ctx.fillRect(px - 12, py - 10, 24, 8);
    ctx.fillStyle = '#f5c451'; ctx.fillRect(px - 2, py - 4, 4, 8);
    if (!this.opened) {
      ctx.save(); ctx.shadowColor = '#f5c451'; ctx.shadowBlur = 8 + Math.sin(Date.now()/200)*4;
      ctx.strokeStyle = '#f5c451'; ctx.strokeRect(px - 12, py - 10, 24, 18); ctx.restore();
    }
  }
}
