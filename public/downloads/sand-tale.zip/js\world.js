/* ================= World / maps ================= */
const T = { SAND: 0, PATH: 1, STONE: 2, WALL: 3, WATER: 4, TREE: 5, ROCK: 6, FLOOR: 7, BRICK: 8 };
const TILE = 32;
const SOLID = new Set([T.WALL, T.WATER, T.TREE, T.ROCK, T.BRICK]);

class GameMap {
  constructor(name, w, h, fill) {
    this.name = name;
    this.w = w; this.h = h;
    this.tiles = new Uint8Array(w * h).fill(fill);
    this.portals = [];
    this.spawns = {};
    this.enemySpawns = [];
    this.npcs = [];
    this.items = [];
    this.chests = [];
    this.torches = [];
  }
  inBounds(x, y) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }
  set(x, y, t) { if (this.inBounds(x, y)) this.tiles[y * this.w + x] = t; }
  get(x, y) { return this.inBounds(x, y) ? this.tiles[y * this.w + x] : T.WALL; }
  rect(x, y, w, h, t) {
    for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) this.set(i, j, t);
  }
  solidTile(tx, ty) { return SOLID.has(this.get(tx, ty)); }
  isSolidAt(px, py, r = 9) {
    return this.solidTile(Math.floor((px - r) / TILE), Math.floor((py - r) / TILE)) ||
           this.solidTile(Math.floor((px + r) / TILE), Math.floor((py - r) / TILE)) ||
           this.solidTile(Math.floor((px - r) / TILE), Math.floor((py + r) / TILE)) ||
           this.solidTile(Math.floor((px + r) / TILE), Math.floor((py + r) / TILE));
  }
  house(x, y, w, h) {
    this.rect(x, y, w, h, T.WALL);
    this.rect(x + 1, y + 1, w - 2, h - 2, T.FLOOR);
    this.rect(x + Math.floor(w / 2) - 1, y + h - 1, 2, 1, T.PATH);
  }
  addPortal(x, y, w, h, to, spawn, label) {
    this.portals.push({ x: x * TILE, y: y * TILE, w: w * TILE, h: h * TILE, to, spawn, label });
  }

  draw(ctx, cam, time) {
    const x0 = Math.max(0, Math.floor(cam.x / TILE));
    const y0 = Math.max(0, Math.floor(cam.y / TILE));
    const x1 = Math.min(this.w, Math.ceil((cam.x + ctx.canvas.width) / TILE) + 1);
    const y1 = Math.min(this.h, Math.ceil((cam.y + ctx.canvas.height) / TILE) + 1);

    for (let y = y0; y < y1; y++) {
      for (let x = x0; x < x1; x++) {
        drawTile(ctx, this.get(x, y), x * TILE - cam.x, y * TILE - cam.y, x, y, time);
      }
    }
    // Portals glow
    for (const p of this.portals) {
      const px = p.x - cam.x, py = p.y - cam.y;
      if (px > ctx.canvas.width + 40 || py > ctx.canvas.height + 40 || px + p.w < -40 || py + p.h < -40) continue;
      const pulse = 0.5 + 0.5 * Math.sin(time * 3);
      ctx.save();
      ctx.fillStyle = `rgba(245,196,81,${0.12 + pulse * 0.16})`;
      ctx.fillRect(px, py, p.w, p.h);
      ctx.strokeStyle = `rgba(255,225,150,${0.5 + pulse * 0.4})`;
      ctx.lineWidth = 2;
      ctx.strokeRect(px + 2, py + 2, p.w - 4, p.h - 4);
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffe6a8';
      ctx.shadowColor = '#000'; ctx.shadowBlur = 6;
      ctx.fillText(p.label, px + p.w / 2, py - 6);
      ctx.restore();
    }
  }
}

function drawTile(ctx, t, px, py, x, y, time) {
  const v = U.hash(x, y);
  switch (t) {
    case T.SAND: {
      const c = Math.floor(214 + v * 22);
      ctx.fillStyle = `rgb(${c},${Math.floor(c * 0.79)},${Math.floor(c * 0.5)})`;
      ctx.fillRect(px, py, TILE, TILE);
      ctx.fillStyle = 'rgba(255,255,255,.10)';
      ctx.fillRect(px + 4 + v * 18, py + 6 + U.hash(y, x) * 16, 2, 2);
      break;
    }
    case T.PATH: {
      ctx.fillStyle = v > .5 ? '#c2a36b' : '#b99a63';
      ctx.fillRect(px, py, TILE, TILE);
      ctx.fillStyle = 'rgba(90,60,30,.18)';
      ctx.fillRect(px + 3, py + 7, 5, 3); ctx.fillRect(px + 19, py + 22, 6, 3);
      break;
    }
    case T.STONE:
      ctx.fillStyle = v > .5 ? '#9b8d78' : '#948671';
      ctx.fillRect(px, py, TILE, TILE);
      ctx.strokeStyle = 'rgba(60,50,35,.3)'; ctx.lineWidth = 1;
      ctx.strokeRect(px + .5, py + .5, TILE - 1, TILE - 1);
      break;
    case T.WALL: {
      ctx.fillStyle = '#5d4d3d';
      ctx.fillRect(px, py, TILE, TILE);
      ctx.fillStyle = '#7c6850';
      ctx.fillRect(px + 2, py + 2, TILE - 4, TILE - 6);
      ctx.fillStyle = 'rgba(0,0,0,.18)';
      ctx.fillRect(px + 2, py + TILE - 7, TILE - 4, 5);
      ctx.fillStyle = 'rgba(255,230,180,.09)';
      ctx.fillRect(px + 2, py + 2, TILE - 4, 3);
      break;
    }
    case T.WATER: {
      const wave = Math.sin(time * 2 + x * .6 + y * .4) * 3;
      ctx.fillStyle = '#2b6f8f'; ctx.fillRect(px, py, TILE, TILE);
      ctx.fillStyle = 'rgba(150,220,240,.25)';
      ctx.fillRect(px + 4 + wave, py + 9, 13, 2);
      ctx.fillRect(px + 15 - wave, py + 22, 10, 2);
      break;
    }
    case T.TREE: {
      ctx.fillStyle = '#c9a568'; ctx.fillRect(px, py, TILE, TILE);
      ctx.fillStyle = '#6b4a2a';
      ctx.fillRect(px + 13, py + 14, 6, 16);
      ctx.fillStyle = v > .5 ? '#3f7a3f' : '#356b38';
      ctx.beginPath(); ctx.arc(px + 16, py + 12, 13, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#528e4a';
      ctx.beginPath(); ctx.arc(px + 11, py + 9, 7, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,.15)';
      ctx.beginPath(); ctx.arc(px + 21, py + 15, 8, 0, Math.PI * 2); ctx.fill();
      break;
    }
    case T.ROCK:
      ctx.fillStyle = '#c9a568'; ctx.fillRect(px, py, TILE, TILE);
      ctx.fillStyle = '#847d72';
      ctx.beginPath(); ctx.moveTo(px + 3, py + 27); ctx.lineTo(px + 9, py + 8);
      ctx.lineTo(px + 24, py + 5); ctx.lineTo(px + 30, py + 27); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#a39b8f';
      ctx.beginPath(); ctx.moveTo(px + 9, py + 8); ctx.lineTo(px + 24, py + 5);
      ctx.lineTo(px + 19, py + 17); ctx.closePath(); ctx.fill();
      break;
    case T.FLOOR:
      ctx.fillStyle = v > .5 ? '#5d566b' : '#575063';
      ctx.fillRect(px, py, TILE, TILE);
      ctx.strokeStyle = 'rgba(20,15,30,.35)'; ctx.strokeRect(px + .5, py + .5, TILE - 1, TILE - 1);
      break;
    case T.BRICK: {
      ctx.fillStyle = '#40394f'; ctx.fillRect(px, py, TILE, TILE);
      ctx.fillStyle = '#6a5c7d';
      ctx.fillRect(px + 1, py + 1, TILE - 2, 14);
      ctx.fillRect(px + 1, py + 17, 13, 13);
      ctx.fillRect(px + 16, py + 17, 14, 13);
      ctx.fillStyle = 'rgba(255,220,150,.07)';
      ctx.fillRect(px + 1, py + 1, TILE - 2, 2);
      break;
    }
  }
}

/* ---------- Map builders ---------- */
function buildVillage() {
  const m = new GameMap('القرية', 42, 30, T.SAND);
  m.rect(0, 14, 42, 3, T.PATH);
  m.rect(19, 0, 3, 30, T.PATH);
  m.rect(8, 6, 3, 3, T.WATER);
  m.rect(7, 5, 5, 1, T.STONE); m.rect(7, 9, 5, 1, T.STONE);
  m.rect(7, 6, 1, 3, T.STONE); m.rect(11, 6, 1, 3, T.STONE);
  m.house(3, 3, 8, 6); m.house(31, 3, 8, 6);
  m.house(4, 21, 8, 6); m.house(29, 21, 9, 6);
  [[14,4],[14,9],[26,5],[25,10],[13,22],[27,23],[34,17],[6,17],[36,13]].forEach(([x,y]) => m.set(x,y,T.TREE));
  [[16,19],[24,20],[12,12],[33,12]].forEach(([x,y]) => m.set(x,y,T.ROCK));
  m.spawns = { start: { x: 6 * TILE, y: 15 * TILE }, fromDesert: { x: 38 * TILE, y: 15 * TILE } };
  m.addPortal(40, 14, 2, 3, 'desert', 'fromVillage', '🟠 الصحراء');
  m.npcs = [
    { id: 'elder', name: 'الشيخ سالم', emoji: '🧓', color: '#8b6fae', x: 21 * TILE, y: 12.5 * TILE },
    { id: 'merchant', name: 'التاجر فهد', emoji: '🧔', color: '#a86b3b', x: 27 * TILE, y: 16 * TILE },
    { id: 'villager1', name: 'فتى القرية', emoji: '👦', color: '#4a8ba8', x: 14 * TILE, y: 17 * TILE },
    { id: 'villager2', name: 'فتاة القرية', emoji: '👧', color: '#b85b7a', x: 33 * TILE, y: 14 * TILE },
  ];
  m.torches = [[19,14],[22,14]].map(([x,y]) => ({ x: x*TILE, y: y*TILE }));
  return m;
}

function buildDesert() {
  const m = new GameMap('الصحراء', 52, 38, T.SAND);
  // dunes / stone stripes
  for (let x = 0; x < 52; x++) {
    const y = 8 + Math.round(Math.sin(x * .35) * 3);
    m.rect(x, y, 1, 2, T.STONE);
  }
  // oasis
  m.rect(14, 26, 7, 5, T.WATER);
  m.rect(13, 25, 9, 1, T.PATH); m.rect(13, 31, 9, 1, T.PATH);
  m.rect(13, 26, 1, 5, T.PATH); m.rect(22, 26, 1, 5, T.PATH);
  [[12,25],[23,25],[12,31],[23,31],[16,24],[20,32]].forEach(([x,y]) => m.set(x,y,T.TREE));
  // rock fields
  for (let i = 0; i < 40; i++) {
    const x = U.randInt(2, 49), y = U.randInt(2, 35);
    if (m.get(x,y) === T.SAND) m.set(x,y,T.ROCK);
  }
  m.spawns = { fromVillage: { x: 3 * TILE, y: 18 * TILE }, fromRuins: { x: 25 * TILE, y: 4 * TILE } };
  m.addPortal(0, 17, 2, 3, 'village', 'fromDesert', '🟣 القرية');
  m.addPortal(24, 0, 4, 2, 'ruins', 'fromDesert', '🔴 الأطلال');
  const spots = [[8,12],[16,15],[24,11],[32,14],[40,10],[44,20],[36,25],[28,29],[18,19],[10,30],[46,30],[30,6],[39,32],[13,8]];
  spots.forEach(([x,y], i) => m.enemySpawns.push({ type: i % 5 === 4 ? 'bandit' : 'scorpion', x: x*TILE, y: y*TILE }));
  m.items = [
    { type: 'potion', x: 17*TILE, y: 28*TILE },
    { type: 'gold', x: 35*TILE, y: 17*TILE },
    { type: 'gold', x: 43*TILE, y: 26*TILE },
  ];
  return m;
}

function buildRuins() {
  const m = new GameMap('الأطلال القديمة', 46, 36, T.FLOOR);
  m.rect(0, 0, 46, 2, T.BRICK); m.rect(0, 34, 46, 2, T.BRICK);
  m.rect(0, 0, 2, 36, T.BRICK); m.rect(44, 0, 2, 36, T.BRICK);
  // rooms & corridors
  m.rect(10, 2, 2, 12, T.BRICK); m.rect(10, 2, 14, 2, T.BRICK);
  m.rect(22, 2, 2, 10, T.BRICK);
  m.rect(4, 12, 12, 2, T.BRICK); m.rect(4, 12, 2, 10, T.BRICK);
  m.rect(16, 18, 14, 2, T.BRICK); m.rect(16, 12, 2, 8, T.BRICK);
  m.rect(30, 8, 2, 14, T.BRICK); m.rect(30, 8, 12, 2, T.BRICK);
  m.rect(38, 8, 2, 12, T.BRICK);
  m.rect(6, 26, 16, 2, T.BRICK); m.rect(6, 26, 2, 8, T.BRICK);
  m.rect(24, 26, 2, 8, T.BRICK);
  m.rect(34, 24, 10, 2, T.BRICK);
  // boss arena top-right
  m.rect(32, 2, 2, 6, T.BRICK);
  m.rect(32, 10, 12, 2, T.BRICK);
  m.spawns = { fromDesert: { x: 23 * TILE, y: 32 * TILE } };
  m.addPortal(22, 34, 3, 2, 'desert', 'fromRuins', '🟠 العودة للصحراء');
  m.enemySpawns = [
    { type:'mage', x:7*TILE, y:6*TILE }, { type:'bandit', x:14*TILE, y:8*TILE },
    { type:'mage', x:8*TILE, y:17*TILE }, { type:'bandit', x:20*TILE, y:15*TILE },
    { type:'bandit', x:35*TILE, y:16*TILE }, { type:'mage', x:39*TILE, y:20*TILE },
    { type:'boss', x:38*TILE, y:6*TILE },
  ];
  m.chests = [{ x: 9*TILE, y: 30*TILE, item: 'artifact', opened: false }];
  m.torches = [[12,4],[20,4],[5,15],[18,20],[33,12],[41,12],[9,29],[28,30],[36,6],[42,6]]
    .map(([x,y]) => ({ x: x*TILE + 16, y: y*TILE + 16 }));
  m.items = [{ type: 'potion', x: 26*TILE, y: 22*TILE }, { type: 'gold', x: 12*TILE, y: 16*TILE }];
  return m;
}

const MAPS = { village: buildVillage(), desert: buildDesert(), ruins: buildRuins() };
